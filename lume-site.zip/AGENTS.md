# LUMÉ — Pet Atelier

A premium, editorial storefront for a pet-accessories brand (food, toys, beds, collars,
grooming and small-pet supplies). Static HTML/CSS/JS, generated from Python templates.

## Run it

```bash
python3 -m http.server 12000 --bind 0.0.0.0
# http://localhost:12000  (public preview: work-1 host on port 12000)
```

## Rebuild the site

Pages are generated, so edit the templates — never the `.html` output.

```bash
cd tools && python3 build.py        # writes all 52 pages into the repo root
```

| File | Role |
| --- | --- |
| `tools/build_lib.py` | Shared partials: `head`, `header(active)`, `footer`, `card`, `cards`, `grid`, `money`, `E` (HTML-escape), `NAV`, `SUBCAT_LABELS` |
| `tools/build.py` | `build_home`, `build_category`, PDP builder, `simple_page`, `main()` |
| `assets/data/catalogue.json` | Single source of truth: `nav`, `categories`, `products`, `reviews`, `payments`, `shipping` |
| `tools/source_images.py` | Sources product photography from Wikimedia Commons: scores candidates with an ImageNet classifier plus title relevance, picks the best crop per product, and writes `assets/img/CREDITS.md` |

## Structure

```
index.html                 home (hero, categories, bestsellers, editorial, reviews)
dogs|cats|small-pets|food|toys.html   category listings with filters + sort
product-<slug>.html        40 product detail pages (gallery, sizes, tabs, reviews)
reviews|checkout|cart.html
about|contact|faq|shipping|track|account|privacy|terms|404.html
assets/css/styles.css      design system (tokens, components, responsive)
assets/css/pages.css       page shell, header grid, prose, FAQ, info cards
assets/js/app.js           reads the shared catalogue; cart, quick view, filters, search
assets/img/*.jpg           118 images (see assets/img/CREDITS.md)
```

## Design system

- **Aesthetic**: quiet luxury / editorial atelier. Warm gallery palette, generous
  whitespace, restrained motion.
- **Type**: `Bodoni Moda` (display serif) + `Jost` (geometric sans), from Google Fonts.
- **Palette tokens** (in `:root`): bone `#F7F3EC`, sand `#EFE8DC`, ink `#1C1A17`,
  brass `#C39A5C`, espresso `#26221D`, sage `#7E8B6E`, berry `#8E4B4B`.
- **Motion**: CSS-only. Hero `rise`, scroll-reveal via IntersectionObserver (`.reveal`,
  `.reveal-img` + `data-delay`), banner parallax. All entrance animations are gated
  behind a `.js` class set inline in `<head>`, so content is visible without JavaScript.
  `prefers-reduced-motion` is fully respected.
- **Breakpoints**: 1080 / 920 / 640 / 420 px. Zero horizontal overflow at 390/768/1440.

## Catalogue model

Products live in `assets/data/catalogue.json`. Each product has:

```json
{ "id", "slug", "name", "cat", "price", "was", "cats": ["dogs","nutrition","feed"],
  "rating", "reviews", "badge", "badgeClass", "img", "gallery": ["..."], "desc", "long",
  "swatches": ["#hex"], "sizes": ["..."], "stock", "sku", "specs": {"Material": "..."} }
```

`cats` holds one or more top-level keys (`dogs`, `cats`, `small-pets`, `nutrition`,
`toys`) **plus exactly one subcategory slug as the last entry** (`sleep`, `walks`,
`play`, `feed`, `treats`, `grooming`, `apparel`, `travel`, `essentials`, `habitat`).
Listing pages render filter chips from that subcategory slug and filter on
`data-cats`. `SUBCAT_LABELS` in `build_lib.py` maps slug to display label.

`assets/js/catalogue.js` is **generated** from the JSON by `tools/build.py`
(`write_catalogue_js`); it exposes the same data as `window.LUME` for the cart,
quick view, search and sort. Never edit it by hand. Product links are static
filenames (`product-<slug>.html`), and every grid is also pre-rendered
server-side, so cards and detail pages work with JavaScript off.

## Image credits

Product photographs are openly licensed and sourced from Wikimedia Commons by
`tools/source_images.py`, which scores candidates with an ImageNet classifier
(`.agent_tmp/mobilenet.onnx`) plus title relevance, then picks the best crop.
The full attribution table is in `assets/img/CREDITS.md`. Swap in your own product
photography by replacing the files and dropping the matching rows from the credits.

**Verify subjects, don't trust the classifier on tight crops.** A crop of a
correct photo can classify as anything (a real dog bed scored "quilt"), and
scoring is noisy enough that auto-picked galleries once showed a parrot and a
goldfish on the homepage. Confirm each image with a majority vote over several
crops of the full frame, and reject any slot whose top-2 classes are the wrong
species.

The verified lifestyle pool lives in `tools/raw/pool4/`. `keep.json` holds only
candidates whose full-frame top-1 agrees with the title's species/subject, and
`pool_build.py` grows the pool from Commons searches under that rule. Building
with `--pool` runs three steps in order:

1. `install_heroes()` re-sources the nine fixed homepage filenames
   (`hero*.jpg`, `banner.jpg`, `story.jpg`, `cat-*.jpg`, `look-*.jpg`) from
   Commons and records provenance in `tools/raw/pool4/heroes.json`.
2. `install_pool()` crops every kept source to `assets/img/life-<pool>-NN.jpg`.
   `verified_crop()` re-checks the *cropped* frame against `POOL_FAMILY`, so a
   frame that only reads as an odd object once cropped is dropped rather than
   shown. Food falls back to a centred crop because biscuits and bowls often
   classify as unrelated objects while still being on-topic.
3. `assign_galleries()` gives every product its own hero plus two unique
   lifestyle frames, then prunes any pool frame no product used, so
   `assets/img/` contains only live files and CREDITS.md never lists an orphan.

```bash
python3 tools/source_images.py --pool     # rebuild heroes + lifestyle pool + galleries
python3 tools/source_images.py            # re-source every product slot (writes .agent_tmp/image_picks.json)
python3 tools/source_images.py --only p1  # one slot
python3 tools/source_images.py --install  # crop + write assets/img/ and CREDITS.md
```

After a pool rebuild, regenerate the credits table so it lists the new
`life-*.jpg` / homepage rows (the section-writing code lives in `install()`).

## Sticky-header offset

The sticky header contains the announce bar plus the nav, so it is **105px tall
(131px below 660px)** — not the 96px the anchors were originally offset by, which
left section headings tucked under the bar. `--header-h` in `styles.css` is the
single source of truth and drives `scroll-margin-top`; update it if the header
height changes. `.dbg/nav.py` fails loudly if any nav anchor lands under it.

## Navbar breakpoints

The header is a 3-column grid (`1fr auto 1fr`): nav · centred wordmark · actions.
The nav and the wordmark compete for the same horizontal band, so the nav must
never grow into the centre. Six items make the nav ~390px wide; when a seventh
item (Brands) was added it reached ~448px and overlapped the wordmark from
**921px to 1110px** while the burger only appeared at ≤920px — the glitch. The
tiers are now:

- **>1160px** — full type (12px, .16em) and 26px gap.
- **≤1160px** — compact nav: 11px type, .11em tracking, 16px gap.
- **≤980px** — nav hides, burger shows, grid becomes `auto 1fr auto`.

`.dbg/nav.py` sweeps 360–1440px and asserts a ≥12px gap between the nav and the
wordmark (and ≥8px between the wordmark and the actions) at every step. Adding a
nav item means re-running it: if the gap goes negative, tighten the compact tier
or move the burger breakpoint up.

```bash
python3 tools/source_images.py            # re-source every slot (writes .agent_tmp/image_picks.json)
python3 tools/source_images.py --only p1  # one slot
python3 tools/source_images.py --install  # crop + write assets/img/ and CREDITS.md
```

## Testing

Debug tooling lives in `.dbg/` (gitignored) and needs Playwright plus
`/usr/bin/chromium`.

```bash
python3 .dbg/verify.py       # every page renders; links + images resolve (0 problems)
python3 .dbg/functional.py   # 40 interaction tests: cart, checkout, filters, tabs, nav
python3 .dbg/layout.py       # no broken visible images or overflow at 3 breakpoints
python3 .dbg/anchors.py      # every in-page #anchor resolves to a real element
python3 .dbg/nav.py          # nav anchors clear the sticky header; no nav collision 360–1440px
python3 .dbg/content.py      # category pages list the expected product counts
python3 .dbg/prod.py         # lazy images all load; quick view opens with an image
python3 .dbg/newpages.py     # wishlist, size guide, compare, gift guide interactions
```

## Customer tools (wishlist, size guide, compare, gift guide)

The runtime catalogue (`assets/js/catalogue.js`) is generated from
`assets/data/catalogue.json` by `write_catalogue_js`, so the static HTML and the
browser catalogue stay in lockstep. Keys: `nav`, `categories`, `products`,
`reviews`, `payments`, `shipping`.

- `wishlist.html` — renders the `lume.wish` localStorage list the card hearts
  write to; add-all and clear-all. Reachable from the header heart and the mobile
  nav.
- `size-guide.html` — charts plus a finder that recommends a size from a real
  measurement (`#sizeCharts` JSON drives it).
- `compare.html` — up to four pieces side by side, best value/rating flagged,
  kept in `lume.compare`.
- `gift-guide.html` — filters by recipient, budget band and occasion.

Home page has a `#tools` section (`.helprow`) so these are reachable without the
nav. Sprite icons `i-ruler`, `i-gift` and `i-scale` back it.

## Welcome offer popup

`#offer` (built by `overlays()`, styled `.offer*`, driven by `initOffer()` in
`app.js`) is a one-time discount / new-arrival modal, present on every page.

- Auto-opens ~5.2s after load, and only when the visitor has paused scrolling
  for ~0.9s, so it never cuts across an active scroll.
- Shown once per browser: dismissal writes `lume.offer.seen` to localStorage.
- Dismissed by the close button, the "No thanks" skip link, Escape, the scrim or
  a backdrop click. The email form validates inline and reveals the code
  `LUME10` on success.
- Suppressed on `checkout.html`, `cart.html` and `account.html` — never interrupt a
  purchase or a sign-in.
- Regenerated from `tools/build_lib.py`; guarded by `.dbg/offer.py`.

## Account & sign-in

`account.html` (built by `build_account()`) is a two-state page driven by
`initAccount()` in `app.js`, styled by the `.auth*` / `.account*` blocks in
`pages.css`.

- **Signed out** — a tabbed card toggles between *Sign in* and *Create account*,
  with inline validation, a show/hide password control and a strength meter on
  registration. The guest aside sells the benefits of an account.
- **Signed in** — a dashboard showing orders, a saved-pieces preview (from
  `lume.wish`), an editable delivery address and notification preferences, plus
  one-tap reorder.
- The session lives in `lume.account` (localStorage); this is a demonstration
  storefront, so no password is sent anywhere and there is no server.
- A completed checkout appends the order to `lume.account.orders`, so the
  dashboard has real data to show.
- Guarded by `.dbg/account.py`.

