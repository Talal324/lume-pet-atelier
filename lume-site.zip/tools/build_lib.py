#!/usr/bin/env python3
"""Static site generator for the LUMÉ Pet Atelier storefront.

Every page is written to disk as real HTML with its product grid already
rendered, so the site works with JavaScript disabled and is indexable.
Shared markup (head, header, footer, overlays) lives here once.
"""
import json
import os
import re
import html

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = json.load(open(os.path.join(ROOT, "assets/data/catalogue.json")))
SPRITE = open(os.path.join(ROOT, "tools/sprite.svg")).read()

PRODUCTS = DATA["products"]
REVIEWS = DATA["reviews"]
CATEGORIES = DATA["categories"]
NAV = DATA["nav"]

# Human labels for the subcategory slugs stored in each product's `cats`.
SUBCAT_LABELS = {
    "sleep": "Beds & Sleep",
    "walks": "Walks & Leads",
    "play": "Toys & Play",
    "feed": "Food & Bowls",
    "treats": "Treats",
    "grooming": "Grooming",
    "apparel": "Coats & Wear",
    "travel": "Travel",
    "essentials": "Essentials",
    "habitat": "Habitats",
}
PAYMENTS = DATA["payments"]
SHIPPING = DATA["shipping"]

E = html.escape


def money(n):
    return "$%0.2f" % n


def stars(rating):
    """Five star glyphs, filled proportionally via a CSS clip trick."""
    full = int(round(rating))
    out = []
    for i in range(5):
        cls = "star is-on" if i < full else "star"
        out.append(f'<svg class="icon icon--xs {cls}"><use href="#i-star"/></svg>')
    return "".join(out)


def price_html(p):
    if p.get("was"):
        return (f'<span class="price">{money(p["price"])}</span>'
                f'<s class="price__was">{money(p["was"])}</s>')
    return f'<span class="price">{money(p["price"])}</span>'


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


def card(p, extra_cls=""):
    """A product card. Rendered server-side so it exists without JS."""
    badges = []
    if p.get("badge"):
        badges.append(f'<span class="badge {p["badgeClass"]}">{E(p["badge"])}</span>')
    if p.get("was"):
        badges.append(f'<span class="badge badge--sale">−{round((1 - p["price"] / p["was"]) * 100)}%</span>')
    sw = "".join(f'<span class="sw" style="background:{c}"></span>' for c in p["swatches"])
    url = f"product-{p['slug']}.html"
    # `cats` holds the top-level categories plus the subcategory slug, which is
    # what listing pages filter on.
    cats = " ".join(p["cats"])
    return f"""      <article class="card {extra_cls}" data-cats="{cats}">
        <div class="card__media">
          <div class="card__badges">{''.join(badges)}</div>
          <button class="card__wish" type="button" aria-label="Save {E(p['name'])}" aria-pressed="false" data-wish="{p['id']}">
            <svg class="icon icon--sm"><use href="#i-heart"/></svg>
          </button>
          <a class="card__img-link" href="{url}" tabindex="-1" aria-hidden="true">
            <img src="{p['img']}" alt="{E(p['name'])}" loading="lazy" width="900" height="1125" data-fallback />
          </a>
          <button class="card__quick" type="button" data-quickview="{p['id']}">Quick view</button>
        </div>
        <div class="card__body">
          <a class="card__body-link" href="{url}">
            <span class="card__cat">{E(p['cat'])}</span>
            <h3 class="card__name">{E(p['name'])}</h3>
            <p class="card__desc">{E(p['desc'])}</p>
          </a>
          <div class="card__swatches">{sw}</div>
          <div class="card__row">
            <div class="card__price">{money(p['price'])}{f'<s>{money(p["was"])}</s>' if p.get('was') else ''}</div>
            <div class="card__rate"><svg class="icon icon--xs"><use href="#i-star"/></svg>{p['rating']} ({p['reviews']})</div>
          </div>
          <button class="btn btn--primary btn--sm card__add" type="button" data-add="{p['id']}">
            <svg class="icon icon--xs"><use href="#i-plus"/></svg><span>Add to bag</span>
          </button>
        </div>
      </article>"""


def cards(items, start_delay=0):
    """Just the cards, for injecting into an existing .products container."""
    return "\n".join(card(p) for p in items)


def grid(items, empty="No pieces found.", extra=""):
    if not items:
        return f'<p class="grid-empty">{empty}</p>'
    return (f'<div class="products products--grid {extra}">\n'
            + cards(items) + "\n</div>")


def product_json_ld(p):
    ld = {
        "@context": "https://schema.org", "@type": "Product",
        "name": p["name"], "description": p["desc"], "sku": p["sku"],
        "brand": {"@type": "Brand", "name": "LUMÉ Pet Atelier"},
        "offers": {"@type": "Offer", "price": p["price"], "priceCurrency": "USD",
                   "availability": "https://schema.org/InStock"},
        "aggregateRating": {"@type": "AggregateRating", "ratingValue": p["rating"],
                            "reviewCount": p["reviews"]},
    }
    return ('<script type="application/ld+json">'
            + json.dumps(ld) + "</script>")


# ---------------------------------------------------------------- partials
def head(title, desc, extra=""):
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>{E(title)}</title>
<meta name="description" content="{E(desc)}" />
<meta name="theme-color" content="#F7F3EC" />
<meta property="og:title" content="{E(title)}" />
<meta property="og:description" content="{E(desc)}" />
<meta property="og:type" content="website" />
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bodoni+Moda:ital,opsz,wght@0,6..96,400..700;1,6..96,400..600&family=Jost:wght@300;400;500;600&display=swap" />
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><rect width='32' height='32' rx='8' fill='%231C1A17'/><text x='16' y='22' font-family='Georgia' font-size='17' fill='%23F7F3EC' text-anchor='middle'>L</text></svg>" />
<link rel="stylesheet" href="assets/css/styles.css" />
<link rel="stylesheet" href="assets/css/pages.css" />
<script>document.documentElement.className += " js";</script>
{extra}</head>
<body>
{SPRITE}
<a class="skip" href="#main">Skip to content</a>
"""


def header(active=""):
    nav = []
    for n in NAV:
        cls = "nav__link is-active" if n["label"] == active else "nav__link"
        nav.append(f'<li><a href="{n["href"]}" class="{cls}">{E(n["label"])}</a></li>')
    return f"""
<header class="header" id="header">
  <div class="announce">
    <p id="announceTrack">Free carbon-neutral delivery over $75 · 60-night comfort promise · New: The Winter Warmth Edit</p>
  </div>
  <div class="header__inner">
    <div class="header__left">
      <button class="icon-btn header__burger" id="burger" aria-label="Open menu" aria-expanded="false" aria-controls="mobilenav">
        <svg class="icon"><use href="#i-menu"/></svg>
      </button>
      <nav class="nav" aria-label="Primary">
        <ul class="nav__list">
{chr(10).join(nav)}
        </ul>
      </nav>
    </div>
    <a class="brand" href="index.html" aria-label="LUMÉ Pet Atelier, home">
      <span class="brand__mark">L</span>
      <span class="brand__word">LUMÉ</span>
      <span class="brand__sub">Pet Atelier</span>
    </a>
    <div class="header__actions">
      <button class="icon-btn" id="openSearch" aria-label="Search"><svg class="icon"><use href="#i-search"/></svg></button>
      <a class="icon-btn hide-sm" href="wishlist.html" aria-label="Saved pieces"><svg class="icon"><use href="#i-heart"/></svg></a>
      <a class="icon-btn hide-sm" href="account.html" aria-label="Account"><svg class="icon"><use href="#i-user"/></svg></a>
      <button class="icon-btn icon-btn--cart" id="openCart" aria-label="Open bag, 0 items" aria-expanded="false" aria-controls="cart">
        <svg class="icon"><use href="#i-cart"/></svg>
        <span class="cart-count" id="cartCount">0</span>
      </button>
    </div>
  </div>
  <div class="header__progress" id="scrollProgress"></div>
</header>
"""


def footer():
    return f"""
<footer class="footer">
  <div class="footer__glow" aria-hidden="true"></div>
  <div class="footer__top">
    <div class="footer__brand">
      <span class="brand__word brand__word--lg">LUMÉ</span>
      <p class="footer__tag">Pet Atelier — considered essentials for the modern companion. Designed in Copenhagen, made by twelve family-run makers across Europe.</p>
      <div class="footer__social">
        <a href="https://www.instagram.com/lume.pet.atelier" target="_blank" rel="noopener me" aria-label="LUMÉ on Instagram"><svg class="icon icon--sm"><use href="#i-ig"/></svg></a>
        <a href="https://www.facebook.com/lume.pet.atelier" target="_blank" rel="noopener me" aria-label="LUMÉ on Facebook"><svg class="icon icon--sm"><use href="#i-fb"/></svg></a>
        <a href="https://www.pinterest.com/lumepetatelier" target="_blank" rel="noopener me" aria-label="LUMÉ on Pinterest"><svg class="icon icon--sm"><use href="#i-pin"/></svg></a>
        <a href="https://www.tiktok.com/@lume.pet.atelier" target="_blank" rel="noopener me" aria-label="LUMÉ on TikTok"><svg class="icon icon--sm"><use href="#i-tt"/></svg></a>
      </div>
      <p class="footer__note">A demonstration storefront. Photography is openly licensed; see <a href="assets/img/CREDITS.md">image credits</a>.</p>
    </div>
    <div class="footer__cols">
      <div class="footer__col">
        <h4>Shop</h4>
        <a href="dogs.html">Dogs</a><a href="cats.html">Cats</a><a href="small-pets.html">Small Pets</a>
        <a href="food.html">Food</a><a href="toys.html">Toys</a>
      </div>
      <div class="footer__col">
        <h4>Company</h4>
        <a href="about.html">Our Story</a><a href="reviews.html">Reviews</a><a href="about.html#sustainability">Sustainability</a>
        <a href="about.html#makers">Our Makers</a><a href="contact.html">Careers</a>
      </div>
      <div class="footer__col">
        <h4>Support</h4>
        <a href="shipping.html">Delivery &amp; Returns</a><a href="faq.html">FAQs</a>
        <a href="size-guide.html">Size Guide</a><a href="gift-guide.html">Gift Guide</a>
        <a href="compare.html">Compare</a><a href="track.html">Track Order</a><a href="contact.html">Contact</a>
      </div>
      <div class="footer__col">
        <h4>Visit</h4>
        <p class="footer__addr">Studio 4, Bredgade 21<br />1260 Copenhagen K<br />Denmark</p>
        <a href="mailto:hello@lume.atelier">hello@lume.atelier</a>
        <a href="tel:+4532148802">+45 32 14 88 02</a>
      </div>
    </div>
  </div>
  <div class="footer__bottom">
    <p>© <span id="year">2026</span> LUMÉ Pet Atelier. All rights reserved.</p>
    <div class="footer__legal">
      <a href="privacy.html">Privacy</a><a href="terms.html">Terms</a><a href="privacy.html#cookies">Cookies</a>
    </div>
    <div class="footer__pay" aria-label="Payment methods">
      <span>VISA</span><span>MC</span><span>AMEX</span><span>PayPal</span><span>Shop&nbsp;Pay</span><span>Apple&nbsp;Pay</span>
    </div>
  </div>
  <div class="footer__wordmark" aria-hidden="true">LUMÉ</div>
  <button class="to-top" id="toTop" type="button" aria-label="Back to top">
    <svg class="icon"><use href="#i-arrow-d"/></svg>
  </button>
</footer>
"""


def overlays():
    mobile_links = "\n".join(
        f'      <a href="{n["href"]}">{E(n["label"])}</a>' for n in NAV)
    return f"""
<div class="scrim" id="scrim"></div>

<aside class="drawer" id="cart" aria-hidden="true" inert aria-label="Shopping bag">
  <header class="drawer__head">
    <h2>Your bag <span class="drawer__count" id="cartCount2">0</span></h2>
    <button class="icon-btn" id="closeCart" aria-label="Close bag"><svg class="icon"><use href="#i-close"/></svg></button>
  </header>
  <div class="drawer__ship" id="shipBar">
    <p id="shipText">Add $75.00 more for free delivery</p>
    <div class="drawer__ship-track"><i id="shipFill"></i></div>
  </div>
  <div class="drawer__body" id="cartBody">
    <div class="cart-empty" id="cartEmpty">
      <svg class="icon icon--lg"><use href="#i-cart"/></svg>
      <p>Your bag is empty.</p>
      <button class="btn btn--outline" id="emptyShop">Start shopping</button>
    </div>
  </div>
  <footer class="drawer__foot" id="cartFoot" hidden>
    <div class="drawer__row"><span>Subtotal</span><b id="cartSubtotal">$0.00</b></div>
    <p class="drawer__fine">Taxes and shipping calculated at checkout. Carbon-neutral delivery included.</p>
    <a class="btn btn--primary btn--block" href="checkout.html"><span>Proceed to checkout</span><svg class="icon icon--sm"><use href="#i-arrow-r"/></svg></a>
    <button class="link-underline" id="continueShop">Continue shopping</button>
  </footer>
</aside>

<aside class="mobilenav" id="mobilenav" aria-hidden="true" inert>
  <div class="mobilenav__head">
    <span class="brand__word">LUMÉ</span>
    <button class="icon-btn" id="closeNav" aria-label="Close menu"><svg class="icon"><use href="#i-close"/></svg></button>
  </div>
  <nav class="mobilenav__links" aria-label="Mobile">
{mobile_links}
  </nav>
  <div class="mobilenav__foot">
    <a href="wishlist.html" class="btn btn--outline btn--block">Saved pieces</a>
    <a href="account.html" class="btn btn--outline btn--block">Account</a>
    <div class="footer__social footer__social--dark">
      <a href="https://www.instagram.com/lume.pet.atelier" target="_blank" rel="noopener me" aria-label="LUMÉ on Instagram"><svg class="icon icon--sm"><use href="#i-ig"/></svg></a>
      <a href="https://www.facebook.com/lume.pet.atelier" target="_blank" rel="noopener me" aria-label="LUMÉ on Facebook"><svg class="icon icon--sm"><use href="#i-fb"/></svg></a>
      <a href="https://www.pinterest.com/lumepetatelier" target="_blank" rel="noopener me" aria-label="LUMÉ on Pinterest"><svg class="icon icon--sm"><use href="#i-pin"/></svg></a>
      <a href="https://www.tiktok.com/@lume.pet.atelier" target="_blank" rel="noopener me" aria-label="LUMÉ on TikTok"><svg class="icon icon--sm"><use href="#i-tt"/></svg></a>
    </div>
  </div>
</aside>

<div class="modal" id="quickview" aria-hidden="true" inert>
  <div class="modal__panel" id="quickviewPanel"></div>
</div>

<div class="modal offer" id="offer" aria-hidden="true" inert role="dialog" aria-modal="true" aria-labelledby="offerTitle">
  <div class="offer__panel" role="document">
    <button class="icon-btn offer__close" id="closeOffer" aria-label="Close offer"><svg class="icon"><use href="#i-close"/></svg></button>
    <figure class="offer__media">
      <img src="assets/img/look-4.jpg" alt="A cat curled up asleep on a soft blanket" loading="lazy" data-fallback />
      <span class="offer__badge"><svg class="icon icon--xs"><use href="#i-sparkle"/></svg> New in</span>
    </figure>
    <div class="offer__body">
      <p class="eyebrow">Welcome to the atelier</p>
      <h2 class="offer__title" id="offerTitle">Ten percent off<br />your first ritual.</h2>
      <p class="offer__lede">Join the pack and take 10% off your first order — plus early access to limited editions and the new Winter Warmth Edit.</p>
      <form class="offer__form" id="offerForm" novalidate>
        <div class="field">
          <input type="email" id="offerEmail" placeholder="you@email.com" aria-label="Email address" required />
          <button class="btn btn--primary" type="submit"><span>Claim 10%</span></button>
        </div>
        <p class="offer__note" id="offerNote">No spam, ever. Unsubscribe in one click.</p>
      </form>
      <button class="link-underline offer__skip" id="offerSkip" type="button">No thanks, I’ll pay full price</button>
    </div>
  </div>
</div>

<div class="searchbox" id="searchbox" aria-hidden="true" inert>
  <button class="icon-btn searchbox__close" id="closeSearch" aria-label="Close search"><svg class="icon"><use href="#i-close"/></svg></button>
  <div class="searchbox__inner">
    <p class="eyebrow">Search the atelier</p>
    <input type="search" id="searchInput" placeholder="Try ‘orthopaedic bed’ or ‘salmon’" aria-label="Search products" />
    <div class="searchbox__suggest" id="searchSuggest">
      <span>Popular:</span>
      <button class="chip" data-search="bed">Beds</button>
      <button class="chip" data-search="collar">Collars</button>
      <button class="chip" data-search="salmon">Salmon</button>
      <button class="chip" data-search="cat">Cat towers</button>
    </div>
    <div class="searchbox__results" id="searchResults"></div>
  </div>
</div>

<div class="toast" id="toast" role="status" aria-live="polite"><svg class="icon icon--sm"><use href="#i-check"/></svg><span id="toastMsg">Added to bag</span></div>
"""


def scripts(extra=""):
    return f'<script src="assets/js/catalogue.js"></script>\n<script src="assets/js/app.js"></script>\n{extra}</body>\n</html>\n'


def write(name, content):
    path = os.path.join(ROOT, name)
    os.makedirs(os.path.dirname(path), exist_ok=True) if os.path.dirname(name) else None
    with open(path, "w") as f:
        f.write(content)
    print("  wrote", name, f"({len(content):,} bytes)")
