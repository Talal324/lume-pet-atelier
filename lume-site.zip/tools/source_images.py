"""Source real product photographs for the LUMÉ catalogue.

For every product we search Wikimedia Commons, score each candidate with an
ImageNet classifier (so a "dog bed" page cannot end up showing a retriever),
then download the best-scoring openly-licensed image.

Usage:
    python3 tools/source_images.py --plan          # show what it would fetch
    python3 tools/source_images.py --only p1,p2    # fetch selected slots
"""
import argparse
import io
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request

from PIL import Image, ImageOps

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TMP = os.path.join(ROOT, ".agent_tmp")
CACHE = os.path.join(TMP, "candidates")
OUT = os.path.join(ROOT, "assets/img")
UA = {"User-Agent": "lume-storefront/1.0 (demo storefront; contact hello@lume.atelier)"}

# ImageNet classes that count as evidence a photo really shows the product.
# Anything not listed is treated as "not the product" and scored down.
WANT = {
    "cloud-nine-bed":       ["Labrador retriever", "golden retriever", "cocker spaniel", "pillow", "quilt", "Bedlington terrier", "toy terrier"],
    "velvet-calm-bed":      ["tabby", "tiger cat", "Persian cat", "Siamese cat", "Egyptian cat", "pillow", "quilt"],
    "atelier-collar":       ["Labrador retriever", "golden retriever", "cocker spaniel", "beagle", "Maltese dog", "toy terrier", "French bulldog", "pug"],
    "everyday-lead":        ["Labrador retriever", "golden retriever", "cocker spaniel", "beagle", "toy terrier", "Maltese dog", "German shepherd"],
    "trail-harness":        ["Labrador retriever", "golden retriever", "cocker spaniel", "Siberian husky", "German shepherd", "beagle", "Eskimo dog"],
    "ceramic-bowl":         ["mixing bowl", "soup bowl", "Labrador retriever", "golden retriever", "cocker spaniel"],
    "cat-bowl":             ["mixing bowl", "soup bowl", "tabby", "tiger cat", "Persian cat", "Egyptian cat"],
    "rope-chew-set":        ["Labrador retriever", "golden retriever", "toy terrier", "cocker spaniel", "tennis ball", "beagle"],
    "sunday-ball":          ["tennis ball", "soccer ball", "golf ball", "croquet ball", "Labrador retriever", "golden retriever", "beagle"],
    "grooming-brush":       ["hairbrush", "paintbrush", "Labrador retriever", "golden retriever", "cocker spaniel"],
    "oatmeal-shampoo":      ["bottlecap", "pop bottle", "water bottle", "lotion", "Labrador retriever"],
    "winter-coat":          ["Labrador retriever", "golden retriever", "Siberian husky", "Eskimo dog", "toy poodle", "Pembroke"],
    "travel-crate":         ["crate", "Labrador retriever", "beagle", "toy terrier", "tabby", "Egyptian cat"],
    "litter-tray":          ["tabby", "tiger cat", "Egyptian cat", "Persian cat", "Siamese cat"],
    "feather-wand":         ["tabby", "tiger cat", "Egyptian cat", "Persian cat", "Siamese cat", "toy terrier"],
    "sisal-post":           ["tabby", "tiger cat", "Egyptian cat", "Persian cat", "Siamese cat"],
    "climbing-tree":        ["tabby", "tiger cat", "Egyptian cat", "Persian cat", "Siamese cat"],
    "catnip-mouse":         ["tabby", "tiger cat", "Egyptian cat", "Persian cat", "Siamese cat", "mouse"],
    "window-perch":         ["tabby", "tiger cat", "Egyptian cat", "Persian cat", "Siamese cat"],
    "guinea-hutch":         ["guinea pig", "hamster", "wood rabbit", "Angora rabbit"],
    "timothy-hay":          ["guinea pig", "hamster", "wood rabbit", "Angora rabbit", "hay"],
    "wood-chew":            ["guinea pig", "hamster", "wood rabbit", "Angora rabbit"],
    "exercise-wheel":       ["hamster", "guinea pig", "wood rabbit", "car wheel", "potter's wheel"],
    "water-bottle":         ["water bottle", "pop bottle", "beer bottle", "hamster", "guinea pig"],
    "hideaway-hut":         ["hamster", "guinea pig", "wood rabbit", "Angora rabbit"],
    "field-farm-recipe":    ["kibble", "Labrador retriever", "golden retriever", "cocker spaniel", "beagle"],
    "slow-cooked-wet":      ["kibble", "Labrador retriever", "tabby", "Egyptian cat", "cocker spaniel"],
    "puppy-formula":        ["Labrador retriever", "golden retriever", "toy terrier", "beagle", "cocker spaniel"],
    "kitten-formula":       ["tabby", "tiger cat", "Persian cat", "Egyptian cat", "Siamese cat"],
    "raw-medallions":       ["kibble", "Labrador retriever", "golden retriever", "cocker spaniel"],
    "dental-chews":         ["kibble", "Labrador retriever", "golden retriever", "toy terrier"],
    "salmon-oil":           ["bottlecap", "pop bottle", "water bottle", "Labrador retriever"],
    "bone-broth":           ["kibble", "soup bowl", "Labrador retriever", "golden retriever"],
    "training-treats":      ["kibble", "Labrador retriever", "golden retriever", "toy terrier", "beagle"],
}

# Search phrases per product (several, so the pool is wide enough to choose from).
QUERY = {
    "cloud-nine-bed":    ["dog bed", "dog sleeping basket", "pet cushion"],
    "velvet-calm-bed":   ["cat bed", "cat sleeping cushion", "cat sleeping"],
    "atelier-collar":    ["dog collar", "dog wearing collar", "leather dog collar"],
    "everyday-lead":     ["dog on a leash", "dog walking lead", "dog lead"],
    "trail-harness":     ["dog harness", "dog wearing harness", "guide dog harness"],
    "ceramic-bowl":      ["dog food bowl", "dog eating bowl", "dog bowl"],
    "cat-bowl":          ["cat food bowl", "cat eating bowl", "cat bowl"],
    "rope-chew-set":     ["dog toy", "dog chew toy", "dog toys"],
    "sunday-ball":       ["dog playing ball", "dog with ball", "tennis ball dog"],
    "grooming-brush":    ["dog grooming brush", "dog being brushed", "dog brush"],
    "oatmeal-shampoo":   ["dog bath", "washing a dog", "dog bath tub"],
    "winter-coat":       ["dog wearing coat", "dog coat", "dog in winter coat"],
    "travel-crate":      ["pet carrier", "cat carrier", "dog crate"],
    "litter-tray":       ["cat litter box", "cat litter tray", "litter box"],
    "feather-wand":      ["cat playing toy", "cat playing", "cat toy"],
    "sisal-post":        ["cat scratching post", "scratching post", "cat scratch"],
    "climbing-tree":     ["cat tree", "cat climbing", "cat furniture"],
    "catnip-mouse":      ["cat toy mouse", "cat and mouse toy", "cat toy"],
    "window-perch":      ["cat window", "cat looking out window", "cat on windowsill"],
    "guinea-hutch":      ["guinea pig cage", "guinea pig hutch", "guinea pig"],
    "timothy-hay":       ["guinea pig hay", "guinea pig eating", "hay guinea pig"],
    "wood-chew":         ["guinea pig", "guinea pigs", "guinea pig eating"],
    "exercise-wheel":    ["hamster wheel", "hamster exercise", "hamster"],
    "water-bottle":      ["hamster water bottle", "guinea pig water bottle", "water bottle pet"],
    "hideaway-hut":      ["guinea pig house", "hamster house", "guinea pig hideout"],
    "field-farm-recipe": ["dry dog food", "dog food bowl", "dog kibble"],
    "slow-cooked-wet":   ["canned dog food", "dog food can", "wet dog food"],
    "puppy-formula":     ["puppy food", "puppy eating", "puppy bowl food"],
    "kitten-formula":    ["kitten eating food", "kitten food", "kitten eating"],
    "raw-medallions":    ["raw meat", "raw pet food", "minced meat"],
    "dental-chews":      ["dog chew", "dog chewing", "dog chew bone"],
    "salmon-oil":        ["fish oil bottle", "salmon oil", "oil bottle"],
    "bone-broth":        ["bone broth", "broth bowl", "stock bowl"],
    "training-treats":   ["dog treats", "dog treat", "dog biscuits"],
}

# Anything whose title smells like this is never a product photograph.
BAD_TITLE = re.compile(
    r"\b(djvu|\.pdf|book|map|engraving|lithograph|painting|drawing|poster|logo|coat of arms"
    r"|ramen|restaurant|menu|cemetery|gravestone|statue|monument|church|castle|lawn|house\b"
    r"|seascape|landscape|street|building|station|portrait|manuscript|sculpture)\b", re.I)

# Tokens too generic to prove relevance on their own.
STOP = {"the", "and", "with", "for", "dog", "cat", "pet", "pets", "food", "toy", "toys", "small"}

# Hand-picked Commons file names for slots where a keyword search alone is
# unreliable. Matching titles get a large bonus, so they win when present.
OVERRIDE = {
    "oatmeal-shampoo":  "Washing a dog in a bath tub",
    "grooming-brush":   "Dog being brushed, Brisbane",
    "bone-broth":       "Broth",
    "raw-medallions":   "Fresh Raw Meat Hanging",
    "slow-cooked-wet":  "Dog food in a bowl",
    "hideaway-hut":     "Guinea pig in hutch",
    "field-farm-recipe": "Dog Food (1)",
    "everyday-lead":    "Dog on a Leash, Wassenaarse Slag",
    "atelier-collar":   "Leather dog collar made by Les cuirs",
    "travel-crate":     "Close-up of Plaid Pet Carrier Bag",
    "rope-chew-set":    "Dog with Chew Toy",
    "dental-chews":     "Dog chewing dog chew",
    "water-bottle":     "Hamster water bottle",
    "puppy-formula":    "Dog food in a bowl",
    "kitten-formula":   "Cat eating wet plant-based cat food",
    "cloud-nine-bed":   "Dog sleeping in a dog bed",
    "ceramic-bowl":     "Dog food in a bowl",
    "salmon-oil":       "NutriFlex OmegaMax",
    "training-treats":  "Dog Treats (51049057473)",
}


# Exact Commons files, pinned. Used where ranking keeps choosing a wrong subject.
DIRECT = {
    "trail-harness":  "File:A beagle wearing a harness standing in a park.jpg",
    "raw-medallions": "File:Raw beef.jpg",
    "ceramic-bowl":   "File:A Bowl Of Doggie Bone (18272371).jpeg",
    "hideaway-hut":   "File:Home built enclosure for a Syrian Hamster.png",
    "slow-cooked-wet": "File:Dog food in a bowl.jpg",
    "everyday-lead":  "File:Beagle wearing harness and leash.jpg",
    "puppy-formula":  "File:A Beagle sitting next to dog food.jpg",
    "catnip-mouse":   "File:2020-04-14 — Cat playing with ball chaser toy.jpg",
    "kitten-formula": "File:Kitten Pair Eating 01.jpg",
    "salmon-oil":     "File:Super-fish-oil.jpg",
    "grooming-brush": "File:TIKITA-TOILETTAGE-2.jpg",
    "dental-chews":   "File:Dreyfuss chews his rawhide bone.jpg",
    "training-treats": "File:Bone Dog Treats (51049786016).jpg",
    "bone-broth":     "File:Broth.jpg",
}

# Lifestyle photographs shown as a product's secondary gallery images. Each
# product gets its own hero photo plus two of these, picked by category, so no
# product ever reuses another product's hero shot.
GALLERY = {
    "dogs":  ["File:DSC 8684 Happy pup enjoying the outdoors with a big smile and wagging tail.jpg",
              "File:A Maltese Running in the Grass.jpg",
              "File:Spelende hond van Engelsen (2).jpg"],
    "cats":  ["File:Larry the cat playing holding a wool string on gravel in Auderghem, Belgium (DSCF2319).jpg",
              "File:Mr Speaker's cat Clem on a windowsill.jpg",
              "File:Corrugated fiberboard scratch pad with cat.jpg"],
    "small": ["File:Guinea pig eating parsley.jpg",
              "File:Syrian Hamster Cage.jpg",
              "File:Guinea Pig eating apple.JPG"],
    "food":  ["File:Pile of Kibble Dog Food (51049786351).jpg",
              "File:Cat eating wet plant-based cat food.jpg",
              "File:Dog Treats (51049057473).jpg"],
}


def commons_file(title):
    """Metadata for one exact Commons file."""
    url = ("https://commons.wikimedia.org/w/api.php?action=query&format=json"
           "&titles=%s&prop=imageinfo&iiprop=url|size|mime|extmetadata&iiurlwidth=1000"
           % urllib.parse.quote(title))
    req = urllib.request.Request(url, headers=UA)
    data = json.load(urllib.request.urlopen(req, timeout=25))
    for pg in data.get("query", {}).get("pages", {}).values():
        ii = (pg.get("imageinfo") or [{}])[0]
        if not ii:
            continue
        meta = ii.get("extmetadata", {})
        return {
            "title": pg["title"],
            "url": ii.get("thumburl") or ii.get("url"),
            "descurl": ii.get("descriptionurl"),
            "w": ii.get("width"), "h": ii.get("height"),
            "author": re.sub("<[^>]+>", "", meta.get("Artist", {}).get("value", "")).strip(),
            "license": meta.get("LicenseShortName", {}).get("value", ""),
        }
    return None


def title_relevance(title, query):
    """How many distinctive query words appear in the file title."""
    words = [w for w in re.findall(r"[a-z]+", query.lower()) if len(w) > 3 and w not in STOP]
    t = title.lower()
    return sum(1 for w in words if w in t)


def load_model():
    import numpy as np
    import onnxruntime as ort
    sess = ort.InferenceSession(os.path.join(TMP, "mobilenet.onnx"), providers=["CPUExecutionProvider"])
    labels = [l.strip() for l in open(os.path.join(TMP, "labels.txt"), encoding="utf-8")]
    return sess, labels, np


def classify(sess, labels, np, path, topk=8):
    im = Image.open(path).convert("RGB").resize((224, 224))
    x = (np.asarray(im, dtype=np.float32) / 255.0 - 0.5) / 0.5
    x = x.transpose(2, 0, 1)[None]
    out = sess.run(None, {sess.get_inputs()[0].name: x})[0][0]
    idx = np.argsort(-out)[:topk]
    return [(labels[i], float(out[i])) for i in idx]


def score(tags, wanted):
    """Reward wanted classes; the classifier's own confidence does the rest."""
    total = 0.0
    for rank, (label, conf) in enumerate(tags):
        if label in wanted:
            total += max(0.0, 1.6 - rank * 0.2) + min(conf, 20) / 40.0
    return total


# Any dog breed is evidence for a dog product, and likewise for cats, so the
# wanted lists do not have to enumerate every breed.
DOG_HINT = re.compile(r"terrier|retriever|spaniel|hound|shepherd|husky|poodle|bulldog|beagle"
                      r"|pug|malamute|collie|setter|pointer|mastiff|chihuahua|kelpie|whippet"
                      r"|greyhound|maltese|pekinese|pomeranian|chow|keeshond|schnauzer|doberman"
                      r"|rottweiler|dalmatian|boxer|corgi|pembroke|cardigan|eskimo dog|newfoundland"
                      r"|saint bernard|great dane|dingo|basenji|saluki|otterhound|elkhound|papillon"
                      r"|groenendael|malinois|bloodhound|borzoi|deerhound|foxhound|weimaraner", re.I)
CAT_HINT = re.compile(r"tabby|tiger cat|persian cat|siamese cat|egyptian cat|lynx|leopard"
                      r"|jaguar|cheetah|tiger\b|lion\b|panther", re.I)


def score_for(tags, wanted, cats):
    """Score a candidate window for a product in the given categories."""
    s = score(tags, wanted)
    for rank, (label, conf) in enumerate(tags):
        is_dog = bool(DOG_HINT.search(label))
        is_cat = bool(CAT_HINT.search(label))
        if "dogs" in cats and is_dog:
            s += max(0.0, 1.2 - rank * 0.15)
        if "cats" in cats and is_cat:
            s += max(0.0, 1.2 - rank * 0.15)
    return s


def candidate_windows(im):
    """A handful of crops, so a subject off-centre can still be kept."""
    iw, ih = im.size
    out = []
    for box in [None, "top", "bottom", "left", "right"]:
        out.append((box, box))
    return out


def crop_box(im, mode, target=0.8):
    """Return a 4:5 crop rectangle for the requested region."""
    iw, ih = im.size
    ratio = 4 / 5
    # largest 4:5 box that fits
    if iw / ih > ratio:
        bw, bh = int(ih * ratio), ih
    else:
        bw, bh = iw, int(iw / ratio)
    bw, bh = int(bw * target), int(bh * target)
    if mode == "top":
        x, y = (iw - bw) // 2, 0
    elif mode == "bottom":
        x, y = (iw - bw) // 2, ih - bh
    elif mode == "left":
        x, y = 0, (ih - bh) // 2
    elif mode == "right":
        x, y = iw - bw, (ih - bh) // 2
    elif mode == "zoom":
        x, y = (iw - bw) // 2, int((ih - bh) * 0.42)
    else:
        x, y = (iw - bw) // 2, int((ih - bh) * 0.42)
    return (x, y, x + bw, y + bh)


def best_crop(im, wanted, cats, sess, labels, np, out_size=(900, 1125)):
    """Pick the crop whose content best matches the product.

    A centred crop can slice the subject out of a wide photograph (a dog on a
    beach becomes a picture of sand), so we score several windows at several
    scales and keep the one the classifier is happiest with.
    """
    best, best_score = None, -1e9
    tmp = os.path.join(TMP, "_crop_probe.jpg")
    for target in (1.0, 0.88, 0.74):
        for mode in (None, "top", "bottom", "left", "right"):
            box = crop_box(im, mode, target)
            win = im.crop(box).resize((224, 224), Image.LANCZOS)
            win.save(tmp, "JPEG", quality=90)
            tags = classify(sess, labels, np, tmp)
            s = score_for(tags, wanted, cats)
            if s > best_score:
                best_score, best = s, im.crop(box)
    return best.resize(out_size, Image.LANCZOS)


def commons_search(query, limit=14):
    url = ("https://commons.wikimedia.org/w/api.php?action=query&format=json"
           "&generator=search&gsrnamespace=6&gsrlimit=%d&gsrsearch=%s"
           "&prop=imageinfo&iiprop=url|size|mime|extmetadata&iiurlwidth=1000"
           % (limit, urllib.parse.quote(query)))
    req = urllib.request.Request(url, headers=UA)
    data = json.load(urllib.request.urlopen(req, timeout=25))
    out = []
    for pg in data.get("query", {}).get("pages", {}).values():
        ii = pg.get("imageinfo", [{}])[0]
        mime = ii.get("mime", "")
        if not mime.startswith("image/") or "svg" in mime:
            continue
        if (ii.get("width") or 0) < 700 or (ii.get("height") or 0) < 500:
            continue
        if BAD_TITLE.search(pg["title"]):
            continue
        meta = ii.get("extmetadata", {})
        out.append({
            "title": pg["title"],
            "url": ii.get("thumburl") or ii.get("url"),
            "descurl": ii.get("descriptionurl"),
            "w": ii.get("width"), "h": ii.get("height"),
            "author": re.sub("<[^>]+>", "", meta.get("Artist", {}).get("value", "")).strip(),
            "license": meta.get("LicenseShortName", {}).get("value", ""),
        })
    return out


def fetch(url, dest):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=40) as r:
        raw = r.read()
    im = Image.open(io.BytesIO(raw)).convert("RGB")
    return im


def to_card(im, w=900, h=1125):
    """Crop to the catalogue's 4:5 card ratio, centred."""
    im = ImageOps.exif_transpose(im)
    target = w / h
    iw, ih = im.size
    if iw / ih > target:
        nw = int(ih * target)
        im = im.crop(((iw - nw) // 2, 0, (iw - nw) // 2 + nw, ih))
    else:
        nh = int(iw / target)
        top = int((ih - nh) * 0.42)          # bias slightly above centre
        im = im.crop((0, top, iw, top + nh))
    return im.resize((w, h), Image.LANCZOS)


# Classes that legitimately describe each lifestyle pool. A candidate crop is
# accepted only when the classifier's top-1 is one of these, which rejects a
# bird at a food bowl, a store aisle or a biscuit that reads as an odd object.
POOL_FAMILY = {
    "dog": re.compile(r"terrier|retriever|spaniel|hound|shepherd|husky|poodle|bulldog|beagle|"
                      r"corgi|collie|pug|mastiff|labrador|dachshund|chihuahua|malinois|malamute|"
                      r"\bdog\b|puppy|setter|pinscher|schnauzer|shiba|akita|boxer|dalmatian|"
                      r"greyhound|whippet|samoyed|pomeranian|weimaraner|papillon|pembroke|"
                      r"cardigan|pyrenees|french bulldog|boston bull|toy terrier|kuvasz|redbone", re.I),
    "cat": re.compile(r"\bcat\b|kitten|tabby|siamese|persian|shorthair|egyptian|manx|ragdoll|"
                      r"bengal|lilacpoint|tiger cat", re.I),
    "small": re.compile(r"guinea pig|cavia|porcellus|caviidae|hamster|mesocricetus|cricetinae|"
                        r"rabbit|hare|oryctolagus|ferret|mustela|polecat|weasel|gerbil|chinchilla|"
                        r"degus|marmot|angora", re.I),
    "food": re.compile(r"food|kibble|bowl|treat|biscuit|eating|meal|dinner|\bfeed\b|dish|plate|"
                       r"tray|cup|mug|mixing|crock|\bpot\b|confectionery|consomme|soup|pretzel|"
                       r"bagel|doughnut|loaf|meat|\bdog\b|\bcat\b|puppy|kitten|retriever|beagle|"
                       r"labrador|terrier|chihuahua|malinois|pembroke|golden retriever|cardigan|"
                       r"pyrenees|toy terrier", re.I),
}


def verified_crop(im, pool, sess, labels, np, out_size=(900, 1125)):
    """Best crop whose classifier top-1 is a plausible class for `pool`.

    Returns None when no candidate crop reads as the right kind of subject, so a
    photograph that only works as a tight detail (or the wrong animal entirely)
    is dropped rather than shown.
    """
    pat = POOL_FAMILY[pool]
    tmp = os.path.join(TMP, "_crop_probe.jpg")
    best, best_score = None, -1e9
    ih = im.size[1]
    for target in (1.0, 0.88, 0.74):
        for mode in (None, "top", "bottom", "left", "right"):
            box = crop_box(im, mode, target)
            win = im.crop(box)
            win.resize((224, 224), Image.LANCZOS).save(tmp, "JPEG", quality=90)
            tags = classify(sess, labels, np, tmp)
            if not pat.search(tags[0][0]):
                continue
            # prefer bigger windows and higher confidence
            s = tags[0][1] - 0.15 * (1 - (box[3] - box[1]) / ih)
            if s > best_score:
                best_score, best = s, win
    return best.resize(out_size, Image.LANCZOS) if best is not None else None


def install_heroes():
    """Re-source the homepage hero/lookbook images with recorded provenance.

    These nine fixed filenames are referenced directly by index_body.html, so
    they were the only images on the site without an attribution row. Each is
    re-sourced from Commons, subject-verified, and cropped to the aspect the
    layout expects; provenance is written to tools/raw/pool4/heroes.json.
    """
    slots = [
        ("hero.jpg",     "golden retriever portrait", (4, 5),  "dog"),
        ("hero-2.jpg",   "cat portrait",              (3, 4),  "cat"),
        ("banner.jpg",   "dog running grass",         (16, 9), "dog"),
        ("story.jpg",    "cat sitting at home",       (1, 1),  "cat"),
        ("cat-dogs.jpg", "border collie dog",         (3, 4),  "dog"),
        ("cat-small.jpg", "guinea pig",               (3, 4),  "small"),
        ("look-1.jpg",   "labrador retriever dog",    (1, 1),  "dog"),
        ("look-2.jpg",   "dog running outdoors",      (4, 3),  "dog"),
        ("look-4.jpg",   "cat sleeping",              (1, 1),  "cat"),
    ]
    # A wild canid, a historic portrait or a museum piece verifies as "dog" but
    # is not a lifestyle photograph, so reject them by title before cropping.
    hero_bad = re.compile(r"african (wild|hunting) dog|lycaon|wild dog|statue|sculpture|"
                          r"painting|drawing|illustration|engraving|stamp|coat of arms|"
                          r"\b(1[6-9]|20[0-2])\d\d\b|black and white|monochrome|taxidermy|"
                          r"skeleton|skull|museum|war|soldier|with dog|and dog", re.I)
    sess, labels, np = load_model()
    base = os.path.join(ROOT, "tools/raw/pool4")
    os.makedirs(CACHE, exist_ok=True)
    out = {}
    for fname, query, (aw, ah), pool in slots:
        pat = POOL_FAMILY[pool]
        best = None
        for r in commons_search(query, 16):
            if BAD_TITLE.search(r["title"]) or hero_bad.search(r["title"]):
                continue
            key = os.path.join(CACHE, re.sub(r"\W+", "_", r["title"])[:110] + ".jpg")
            try:
                if not os.path.exists(key):
                    fetch(r["url"], key).save(key, "JPEG", quality=92)
                top = classify(sess, labels, np, key)[0]
            except Exception:
                continue
            if not pat.search(top[0]):
                continue
            if best is None or top[1] > best[1][1]:
                best = (r, top, key)
        if best is None:
            print(f"  no verified source for {fname}")
            continue
        im = ImageOps.exif_transpose(Image.open(best[2])).convert("RGB")
        iw, ih = im.size
        target = aw / ah
        if iw / ih > target:
            nw = int(ih * target); box = ((iw - nw) // 2, 0, (iw - nw) // 2 + nw, ih)
        else:
            nh = int(iw / target); box = (0, int((ih - nh) * 0.4), iw, int((ih - nh) * 0.4) + nh)
        im.crop(box).resize((min(1400, box[2] - box[0]), min(1400, box[3] - box[1])),
                            Image.LANCZOS).save(os.path.join(OUT, fname), "JPEG",
                                                quality=86, optimize=True, progressive=True)
        out[fname] = {"title": best[0]["title"], "author": best[0]["author"],
                      "license": best[0]["license"], "descurl": best[0]["descurl"]}
        print(f"wrote {fname:14} <- {best[0]['title']} [{best[1][0]}]")
    json.dump(out, open(os.path.join(base, "heroes.json"), "w", encoding="utf-8"), indent=1)
    return out


def install_pool():
    """Crop the verified lifestyle photographs into assets/img/life-*.jpg.

    Sources are hand-verified Commons files whose full-frame classifier top-1
    agrees with the title's species/subject (see tools/raw/pool4/keep.json).
    Each crop is re-checked so the *visible* frame also reads as the right
    subject; frames that only work as an ambiguous detail are dropped. Writes
    tools/raw/pool4/life_index.json mapping each output file to its attribution.
    """
    sess, labels, np = load_model()
    base = os.path.join(ROOT, "tools/raw/pool4")
    keep = json.load(open(os.path.join(base, "keep.json"), encoding="utf-8"))
    index, per_pool, dropped = {}, {}, []
    for key, m in sorted(keep.items()):
        src = os.path.join(base, key + ".jpg")
        if not os.path.exists(src):
            continue
        pool = m["pool"]
        im = ImageOps.exif_transpose(Image.open(src)).convert("RGB")
        out = verified_crop(im, pool, sess, labels, np)
        if out is None and pool == "food":
            # Food is already verified by title + full frame; a biscuit or bowl
            # often reads as an unrelated object once cropped, so keep the
            # centred crop rather than dropping a genuinely on-topic photograph.
            out = best_crop(im, [], [], sess, labels, np)
        if out is None:
            dropped.append((pool, m["title"]))
            continue
        per_pool[pool] = per_pool.get(pool, 0) + 1
        dest = f"life-{pool}-{per_pool[pool]:02d}.jpg"
        out.save(os.path.join(OUT, dest), "JPEG", quality=86, optimize=True, progressive=True)
        index[dest] = m
    json.dump(index, open(os.path.join(base, "life_index.json"), "w", encoding="utf-8"), indent=1)
    print(f"{len(index)} lifestyle frames installed; {len(dropped)} dropped:")
    for pool, title in dropped:
        print(f"  drop [{pool}] {title}")
    return index


def gallery_pool(cats):
    """Which lifestyle set suits a product, from its category list."""
    if "nutrition" in cats and cats[0] in ("dogs", "cats"):
        return "food"
    return {"dogs": "dog", "cats": "cat", "small-pets": "small"}[cats[0]]


def assign_galleries():
    """Give every product a hero plus two *unique* lifestyle shots from its pool.

    Earlier the lifestyle frames were rotated from a three-image pool, so every
    dog product shared the same two pictures. The verified pools now hold ~20
    frames each, so each product claims its own pair and no photograph is reused
    across products.
    """
    base = os.path.join(ROOT, "tools/raw/pool4")
    index = json.load(open(os.path.join(base, "life_index.json"), encoding="utf-8"))
    by_pool = {}
    for f, m in index.items():
        by_pool.setdefault(m["pool"], []).append(f)
    for pool in by_pool:
        by_pool[pool].sort()

    path = os.path.join(ROOT, "assets/data/catalogue.json")
    cat = json.load(open(path, encoding="utf-8"))
    counters, used = {}, set()
    for p in cat["products"]:
        pool = gallery_pool(p["cats"])
        files = by_pool.get(pool, [])
        if not files:
            continue
        k = counters.get(pool, 0)
        counters[pool] = k + 1
        extras = [files[(k * 2 + i) % len(files)] for i in range(2)]
        used.update(extras)
        p["gallery"] = [p["img"]] + ["assets/img/" + e for e in extras]
    json.dump(cat, open(path, "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    # Drop pool frames no product ended up using, so assets/img holds only live
    # files and CREDITS.md never lists an image the site does not load.
    pruned = 0
    for f in list(index):
        if f not in used:
            fp = os.path.join(OUT, f)
            if os.path.exists(fp):
                os.remove(fp)
            index.pop(f, None)
            pruned += 1
    if pruned:
        json.dump(index, open(os.path.join(base, "life_index.json"), "w", encoding="utf-8"), indent=1)
    print(f"galleries rebuilt for {len(cat['products'])} products; {pruned} unused frames pruned")


def install():
    """Crop every chosen photograph to the catalogue ratio and write it out."""
    picks = json.load(open(os.path.join(TMP, "image_picks.json"), encoding="utf-8"))
    cat = json.load(open(os.path.join(ROOT, "assets/data/catalogue.json"), encoding="utf-8"))
    names = {p["img"].split("/")[-1]: p["name"] for p in cat["products"]}
    cats = {p["img"].split("/")[-1]: p["cats"] for p in cat["products"]}
    sess, labels, np = load_model()
    rows = []
    for slot, v in sorted(picks.items()):
        if not v.get("src") or not os.path.exists(v["src"]):
            print("SKIP (no source)", slot)
            continue
        im = ImageOps.exif_transpose(Image.open(v["src"])).convert("RGB")
        want = WANT.get(v["pid"], [])
        if not want:
            # Fall back to breed/animal hints so at least the right species wins.
            want = []
        out = best_crop(im, want, cats.get(slot, []), sess, labels, np)
        out.save(os.path.join(OUT, slot), "JPEG", quality=86, optimize=True, progressive=True)
        rows.append((slot, names.get(slot, v["pid"]), v["picked"], v["author"], v["license"], v["descurl"]))
        print(f"wrote {slot:18} <- {v['picked']}")
    with open(os.path.join(ROOT, "assets/img/CREDITS.md"), "w", encoding="utf-8") as f:
        f.write("# Image credits\n\n"
                "Every photograph below is from Wikimedia Commons and is reused under the "
                "licence shown. Attribution is required for CC BY / CC BY-SA; keep this file "
                "with the site, or replace these images with your own photography.\n\n"
                "## Product photographs\n\n"
                "| File | Shows | Source | Author | Licence |\n"
                "| --- | --- | --- | --- | --- |\n")
        for slot, name, title, author, lic, url in rows:
            f.write(f"| `{slot}` | {name} | [{title.replace('File:', '')}]({url}) | "
                    f"{author or 'see source'} | {lic or 'see source'} |\n")
        # lifestyle gallery photographs, listed by the file the page actually loads
        life_path = os.path.join(ROOT, "tools/raw/pool4/life_index.json")
        if os.path.exists(life_path):
            index = json.load(open(life_path, encoding="utf-8"))
            f.write("\n## Lifestyle photographs\n\n"
                    "| File | Pool | Source | Author | Licence |\n"
                    "| --- | --- | --- | --- | --- |\n")
            for dest, m in sorted(index.items()):
                f.write(f"| `{dest}` | {m['pool']} | "
                        f"[{m['title'].replace('File:', '')}]({m['descurl']}) | "
                        f"{m['author'] or 'see source'} | {m['license'] or 'see source'} |\n")
        hero_path = os.path.join(ROOT, "tools/raw/pool4/heroes.json")
        if os.path.exists(hero_path):
            heroes = json.load(open(hero_path, encoding="utf-8"))
            f.write("\n## Homepage images\n\n"
                    "| File | Source | Author | Licence |\n"
                    "| --- | --- | --- | --- |\n")
            for dest, m in sorted(heroes.items()):
                f.write(f"| `{dest}` | "
                        f"[{m['title'].replace('File:', '')}]({m['descurl']}) | "
                        f"{m['author'] or 'see source'} | {m['license'] or 'see source'} |\n")
    print(f"\n{len(rows)} images installed; assets/img/CREDITS.md written")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", action="store_true")
    ap.add_argument("--install", action="store_true")
    ap.add_argument("--pool", action="store_true",
                    help="rebuild the verified lifestyle pool images and reassign galleries")
    ap.add_argument("--only", default="")
    args = ap.parse_args()

    if args.pool:
        install_heroes()
        install_pool()
        assign_galleries()
        return

    if args.install:
        install()
        return

    os.makedirs(CACHE, exist_ok=True)
    sess, labels, np = load_model()
    cat = json.load(open(os.path.join(ROOT, "assets/data/catalogue.json"), encoding="utf-8"))
    # image slot -> product id (products share slots, so resolve both ways)
    slot_owner = {}
    for p in cat["products"]:
        slot_owner.setdefault(p["img"].split("/")[-1], p["id"])

    only = {s.strip() for s in args.only.split(",") if s.strip()}
    picks_path = os.path.join(TMP, "image_picks.json")
    report = json.load(open(picks_path, encoding="utf-8")) if os.path.exists(picks_path) else {}
    used_files = set()
    for slot, pid in sorted(slot_owner.items()):
        if only and slot not in only and pid not in only:
            continue
        wanted = WANT.get(pid, [])
        pool, seen_titles = [], set()
        for q in QUERY[pid]:
            for r in commons_search(q):
                if r["title"] in seen_titles:
                    continue
                seen_titles.add(r["title"])
                pool.append(r)
        # Hand-picked Commons files win outright — used where search is weak.
        if pid in OVERRIDE:
            for r in commons_search(OVERRIDE[pid]):
                if r["title"] not in seen_titles:
                    seen_titles.add(r["title"])
                    pool.append(r)
        scored = []
        for r in pool:
            key = os.path.join(CACHE, re.sub(r"\W+", "_", r["title"])[:110] + ".jpg")
            try:
                if not os.path.exists(key):
                    im = fetch(r["url"], key)
                    im.save(key, "JPEG", quality=90)
                tags = classify(sess, labels, np, key)
            except Exception:
                continue
            s = score(tags, wanted) + title_relevance(r["title"], " ".join(QUERY[pid])) * 1.5
            if pid in OVERRIDE and OVERRIDE[pid].lower() in r["title"].lower():
                s += 12
            scored.append((s, r, tags, key))

        # Pinned files beat ranking entirely, and keep a slot off a duplicate.
        pin = DIRECT.get(pid)
        if pin:
            meta = commons_file(pin)
            if meta:
                key = os.path.join(CACHE, re.sub(r"\W+", "_", meta["title"])[:110] + ".jpg")
                try:
                    if not os.path.exists(key):
                        fetch(meta["url"], key).save(key, "JPEG", quality=90)
                    scored.insert(0, (999, meta, classify(sess, labels, np, key), key))
                except Exception:
                    pass
        else:
            # A product may not reuse a photograph already taken by another slot.
            scored = [s for s in scored if os.path.basename(s[3]) not in used_files]
        scored.sort(key=lambda x: -x[0])
        best = scored[0] if scored else None
        if best:
            used_files.add(os.path.basename(best[3]))
        report[slot] = {
            "pid": pid, "query": QUERY[pid],
            "picked": best[1]["title"] if best else None,
            "score": round(best[0], 2) if best else 0,
            "top": [t[0] for t in best[2][:4]] if best else [],
            "author": best[1]["author"] if best else "",
            "license": best[1]["license"] if best else "",
            "descurl": best[1]["descurl"] if best else "",
            "src": best[3] if best else "",
            "alts": [(round(s, 2), r["title"], [t[0] for t in tg[:3]]) for s, r, tg, _ in scored[1:4]],
        }
        print(f"{slot:24} {pid:24} score={report[slot]['score']:5}  {report[slot]['picked']}")
        if args.plan:
            for s, t, tg in report[slot]["alts"]:
                print(f"     alt {s:5} {t[:56]:58} {tg}")
    with open(os.path.join(TMP, "image_picks.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    if not args.plan:
        print("\nwrote", os.path.join(TMP, "image_picks.json"))


if __name__ == "__main__":
    main()
