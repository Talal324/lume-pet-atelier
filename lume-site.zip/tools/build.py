#!/usr/bin/env python3
"""Build every page of the LUMÉ storefront into static HTML."""
import json
import os
import re

import build_lib as B
from build_lib import (E, money, card, cards, grid, head, header, footer,
                       overlays, scripts, write, stars, PRODUCTS, REVIEWS,
                       CATEGORIES, NAV, PAYMENTS, SHIPPING, SUBCAT_LABELS, ROOT)

ANALYTICS = ""  # no third-party scripts

CRUMBS_HOME = '<a href="index.html">Home</a>'


def crumbs(items):
    parts = [CRUMBS_HOME]
    for i, (label, href) in enumerate(items):
        last = i == len(items) - 1
        if last or not href:
            parts.append(f'<span aria-current="page">{E(label)}</span>')
        else:
            parts.append(f'<a href="{href}">{E(label)}</a>')
    return '<nav class="crumbs" aria-label="Breadcrumb">' + '<i aria-hidden="true">/</i>'.join(parts) + "</nav>"


def nav_label_for(href):
    """The nav label whose href matches, so pages highlight the right item."""
    for n in NAV:
        if n["href"] == href:
            return n["label"]
    return ""


def page(title, desc, body, active="", extra_head="", extra_js=""):
    return (head(title, desc, extra_head) + header(active) + f'<main id="main">\n{body}\n</main>\n'
            + footer() + overlays() + scripts(extra_js))


# ------------------------------------------------------------------ home
def build_home():
    body = open(os.path.join(ROOT, "tools/index_body.html")).read()
    body = body.replace("{{PRODUCTS}}", cards(PRODUCTS))
    write("index.html", page(
        "LUMÉ — Pet Atelier | Considered essentials for the modern companion",
        "LUMÉ is a pet atelier. Slow-cooked nutrition, hand-finished toys, couture-soft "
        "bedding and grooming rituals for dogs, cats and small companions.",
        body, active="Shop All"))


# -------------------------------------------------------------- category
CAT_PAGES = {
    "dogs":       ("Dogs", "Beds, collars, leads, harnesses and everyday kit for dogs of every size."),
    "cats":       ("Cats", "Scratching posts, dens, dining and quiet corners designed for cats."),
    "small-pets": ("Small Pets", "Hutches, hay, hideaways and safe chews for rabbits and rodents."),
    "food":       ("Nutrition", "Slow-cooked recipes, gentle supplements and treats you can trust."),
    "toys":       ("Toys &amp; Play", "Natural materials, thoughtful shapes and endlessly chewable play."),
}


def build_category(key, cat_key, title, blurb):
    items = [p for p in PRODUCTS if cat_key in p["cats"]]
    # The last entry in each product's `cats` is its subcategory slug; the rest
    # are top-level categories. Chips filter on that slug.
    subs = sorted({p["cats"][-1] for p in items})
    chips = ['<button class="chip is-active" data-filter="all">All</button>']
    for s in subs:
        chips.append(f'<button class="chip" data-filter="{E(s)}">{E(SUBCAT_LABELS.get(s, s.title()))}</button>')
    filters = (f'<div class="filters" role="group" aria-label="Filter products">{"".join(chips)}</div>'
               if len(subs) > 1 else "")
    sorts = ('<label class="select"><span>Sort</span><select id="sortSelect">'
             '<option value="featured">Featured</option>'
             '<option value="price-asc">Price, low to high</option>'
             '<option value="price-desc">Price, high to low</option>'
             '<option value="rating">Top rated</option></select></label>')
    body = f"""
<section class="page-hero page-hero--cat">
  <div class="wrap">
    {crumbs([(title, None)])}
    <h1 class="page-hero__title reveal">{title}</h1>
    <p class="page-hero__lede reveal" data-delay="1">{blurb}</p>
  </div>
</section>

<section class="section section--listing">
  <div class="wrap">
    <div class="listing__bar">
      {filters}
      {sorts}
    </div>
    <p class="listing__count" id="listingCount">{len(items)} pieces</p>
    <div class="products products--grid" id="products" data-cat="{cat_key}">
{cards(items)}
    </div>
  </div>
</section>
"""
    write(f"{key}.html", page(f"{title.replace('&amp;', '&')} — LUMÉ Pet Atelier",
                              blurb, body, active=nav_label_for(f"{key}.html")))


# ------------------------------------------------------------------- PDP
def review_card(r):
    return f"""        <article class="review">
          <div class="review__head">
            <div class="review__who"><span class="review__avatar">{E(r['name'][0])}</span>
              <div><b>{E(r['name'])}</b><span>{E(r['pet'])}</span></div></div>
            <div class="review__stars">{stars(r['rating'])}</div>
          </div>
          <h4 class="review__title">{E(r['title'])}</h4>
          <p class="review__body">{E(r['body'])}</p>
          <p class="review__meta">{r['date']} · {'Verified buyer' if r['verified'] else 'Reviewer'}</p>
        </article>"""


def rating_bars(items):
    total = len(items) or 1
    rows = []
    for n in range(5, 0, -1):
        c = sum(1 for r in items if r["rating"] == n)
        pct = round(c / total * 100)
        rows.append(f'<div class="bar"><span>{n}</span>'
                    f'<div class="bar__track"><i style="width:{pct}%"></i></div>'
                    f'<b>{pct}%</b></div>')
    return "".join(rows)


def build_product(p):
    rel = [x for x in PRODUCTS if x["id"] != p["id"] and x["cats"][0] == p["cats"][0]][:4]
    if len(rel) < 4:
        rel += [x for x in PRODUCTS if x["id"] != p["id"] and x not in rel][:4 - len(rel)]
    thumbs = "".join(
        f'<button class="pdp__thumb{" is-active" if i == 0 else ""}" type="button" '
        f'data-gallery="{src}" aria-label="View image {i + 1}">'
        f'<img src="{src}" alt="" loading="lazy" width="200" height="250" /></button>'
        for i, src in enumerate(p["gallery"]))
    swatches = "".join(
        f'<button class="sw{" is-active" if i == 0 else ""}" type="button" style="background:{c}" '
        f'data-swatch="{c}" aria-label="Colour {i + 1}"></button>' for i, c in enumerate(p["swatches"]))
    sizes = "".join(
        f'<button class="size{" is-active" if i == 0 else ""}" type="button" data-size="{E(s)}">{E(s)}</button>'
        for i, s in enumerate(p["sizes"]))
    specs = "".join(f'<div class="spec"><dt>{E(k)}</dt><dd>{E(v)}</dd></div>' for k, v in p["specs"].items())
    revs = REVIEWS[:6]
    avg = round(sum(r["rating"] for r in revs) / len(revs), 1)

    body = f"""
<section class="section pdp" data-product="{p['id']}">
  <div class="wrap">
    {crumbs([(p['cat'], None), (p['name'], None)])}
    <div class="pdp__grid">
      <div class="pdp__media">
        <div class="pdp__stage reveal-img">
          <img id="pdpImage" src="{p['gallery'][0]}" alt="{E(p['name'])}" loading="eager" width="900" height="1125" data-fallback />
          {'<span class="badge ' + p['badgeClass'] + '">' + E(p['badge']) + '</span>' if p.get('badge') else ''}
        </div>
        <div class="pdp__thumbs" role="group" aria-label="Product images">{thumbs}</div>
      </div>

      <div class="pdp__info">
        <p class="pdp__cat">{E(p['cat'])}</p>
        <h1 class="pdp__title">{E(p['name'])}</h1>
        <a class="pdp__rate" href="#reviews">
          {stars(p['rating'])}<span>{p['rating']} · {p['reviews']} reviews</span>
        </a>
        <p class="pdp__price" id="pdpPrice">
          <span>{money(p['price'])}</span>
          {f'<s>{money(p["was"])}</s><em class="pdp__save">Save {money(p["was"] - p["price"])}</em>' if p.get('was') else ''}
        </p>
        <p class="pdp__lede">{E(p['long'])}</p>

        <div class="pdp__opt">
          <p class="pdp__label">Colour</p>
          <div class="pdp__swatches" role="group" aria-label="Colour">{swatches}</div>
        </div>
        <div class="pdp__opt">
          <p class="pdp__label">Size</p>
          <div class="pdp__sizes" role="group" aria-label="Size">{sizes}</div>
        </div>

        <div class="pdp__buy">
          <div class="qty" data-qty>
            <button type="button" data-qty-dec aria-label="Decrease quantity">−</button>
            <input id="pdpQty" type="text" inputmode="numeric" value="1" aria-label="Quantity" />
            <button type="button" data-qty-inc aria-label="Increase quantity">+</button>
          </div>
          <button class="btn btn--primary pdp__add" type="button" data-add="{p['id']}" data-add-detail="1">
            <svg class="icon icon--sm"><use href="#i-cart"/></svg><span>Add to bag</span>
          </button>
          <button class="icon-btn pdp__wish" type="button" data-wish="{p['id']}" aria-pressed="false" aria-label="Save for later">
            <svg class="icon"><use href="#i-heart"/></svg>
          </button>
        </div>

        <ul class="pdp__trust">
          <li><svg class="icon icon--xs"><use href="#i-truck"/></svg> Free delivery over $75</li>
          <li><svg class="icon icon--xs"><use href="#i-shield"/></svg> 60-night comfort promise</li>
          <li><svg class="icon icon--xs"><use href="#i-leaf"/></svg> Carbon-neutral shipping</li>
        </ul>
        <p class="pdp__stock"><span class="dot"></span> In stock · {p['stock']} left · SKU {E(p['sku'])}</p>
      </div>
    </div>

    <div class="pdp__tabs" data-tabs>
      <div class="tabs" role="tablist" aria-label="Product information">
        <button class="tab is-active" role="tab" aria-selected="true" aria-controls="tab-desc" id="tabbtn-desc" data-tab="desc">Description</button>
        <button class="tab" role="tab" aria-selected="false" aria-controls="tab-specs" id="tabbtn-specs" data-tab="specs">Specifications</button>
        <button class="tab" role="tab" aria-selected="false" aria-controls="tab-reviews" id="tabbtn-reviews" data-tab="reviews">Reviews ({len(revs)})</button>
        <button class="tab" role="tab" aria-selected="false" aria-controls="tab-ship" id="tabbtn-ship" data-tab="ship">Delivery &amp; returns</button>
      </div>
      <div class="tabpanel is-active" id="tab-desc" role="tabpanel" aria-labelledby="tabbtn-desc" tabindex="0">
        <p>{E(p['long'])}</p>
        <p>{E(p['desc'])}</p>
      </div>
      <div class="tabpanel" id="tab-specs" role="tabpanel" aria-labelledby="tabbtn-specs" tabindex="0">
        <dl class="specs">{specs}</dl>
      </div>
      <div class="tabpanel" id="tab-reviews" role="tabpanel" aria-labelledby="tabbtn-reviews" tabindex="0">
        <div class="revsum">
          <div class="revsum__score"><b>{avg}</b>{stars(avg)}<span>{p['reviews']} reviews</span></div>
          <div class="revsum__bars">{rating_bars(revs)}</div>
        </div>
        <div class="reviews">{''.join(review_card(r) for r in revs)}</div>
        <a class="btn btn--outline" href="reviews.html">Read all reviews <svg class="icon icon--sm"><use href="#i-arrow-r"/></svg></a>
      </div>
      <div class="tabpanel" id="tab-ship" role="tabpanel" aria-labelledby="tabbtn-ship" tabindex="0">
        <p>Free carbon-neutral delivery on orders over $75. Express and next-day options are
        available at checkout, and every order is tracked.</p>
        <p>Not right? Return it within 60 nights, unused and in its original packaging, and we
        will refund you in full.</p>
      </div>
    </div>

    <section class="section--related">
      <div class="section__head section__head--split">
        <h2 class="section__title">You may also like</h2>
        <a class="link-underline" href="index.html#bestsellers">View all</a>
      </div>
      <div class="products products--grid">{cards(rel)}</div>
    </section>
  </div>
</section>
"""
    write(f"product-{p['slug']}.html", page(
        f"{p['name']} — LUMÉ Pet Atelier", p["desc"], body,
        extra_head=B.product_json_ld(p) + "\n"))


# --------------------------------------------------------------- reviews
def build_reviews():
    avg = round(sum(r["rating"] for r in REVIEWS) / len(REVIEWS), 2)
    total_reviews = sum(p["reviews"] for p in PRODUCTS)
    body = f"""
<section class="page-hero">
  <div class="wrap">
    {crumbs([('Reviews', None)])}
    <h1 class="page-hero__title reveal">Loved, and reordered</h1>
    <p class="page-hero__lede reveal" data-delay="1">Every review below comes from a verified
    order. We publish them all — the five stars and the fours.</p>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="revsum revsum--wide">
      <div class="revsum__score"><b>{avg}</b>{stars(avg)}<span>{total_reviews:,} verified reviews</span></div>
      <div class="revsum__bars">{rating_bars(REVIEWS)}</div>
      <div class="revsum__cta">
        <p>Bought something recently?</p>
        <a class="btn btn--outline" href="contact.html">Write a review</a>
      </div>
    </div>

    <div class="filters filters--reviews" role="group" aria-label="Filter reviews">
      <button class="chip is-active" data-filter="all">All</button>
      <button class="chip" data-filter="dogs">Dogs</button>
      <button class="chip" data-filter="cats">Cats</button>
      <button class="chip" data-filter="small-pets">Small pets</button>
      <button class="chip" data-filter="nutrition">Nutrition</button>
    </div>

    <div class="reviews reviews--wide">{''.join(review_card(r) for r in REVIEWS)}</div>

    <section class="section--related">
      <div class="section__head section__head--split">
        <h2 class="section__title">Shop the most-reviewed pieces</h2>
        <a class="link-underline" href="index.html#bestsellers">View all</a>
      </div>
      <div class="products products--grid">
{cards(sorted(PRODUCTS, key=lambda p: -p['reviews'])[:4])}
      </div>
    </section>
  </div>
</section>
"""
    write("reviews.html", page("Reviews — LUMÉ Pet Atelier",
                               "Verified customer reviews of LUMÉ pet accessories, bedding and nutrition.",
                               body, active="Reviews"))


# -------------------------------------------------------------- checkout
def build_checkout():
    body = f"""
<section class="section checkout">
  <div class="wrap">
    {crumbs([('Checkout', None)])}
    <h1 class="checkout__title reveal">Checkout</h1>

    <div class="checkout__grid">
      <form class="checkout__form" id="checkoutForm" novalidate>
        <fieldset class="fset">
          <legend><span class="fset__n">1</span> Contact</legend>
          <div class="field"><label for="email">Email</label>
            <input id="email" name="email" type="email" autocomplete="email" required placeholder="you@example.com" />
            <p class="field__err" data-err="email"></p></div>
          <label class="check"><input type="checkbox" id="news" checked /> <span>Email me new arrivals and care notes</span></label>
        </fieldset>

        <fieldset class="fset">
          <legend><span class="fset__n">2</span> Delivery address</legend>
          <div class="field-row">
            <div class="field"><label for="first">First name</label>
              <input id="first" name="first" autocomplete="given-name" required /><p class="field__err" data-err="first"></p></div>
            <div class="field"><label for="last">Last name</label>
              <input id="last" name="last" autocomplete="family-name" required /><p class="field__err" data-err="last"></p></div>
          </div>
          <div class="field"><label for="addr">Address</label>
            <input id="addr" name="addr" autocomplete="street-address" required placeholder="Street and number" />
            <p class="field__err" data-err="addr"></p></div>
          <div class="field-row">
            <div class="field"><label for="city">City</label>
              <input id="city" name="city" autocomplete="address-level2" required /><p class="field__err" data-err="city"></p></div>
            <div class="field"><label for="zip">Postcode</label>
              <input id="zip" name="zip" autocomplete="postal-code" required /><p class="field__err" data-err="zip"></p></div>
          </div>
          <div class="field"><label for="country">Country</label>
            <select id="country" name="country" required>
              <option value="DK">Denmark</option><option value="SE">Sweden</option>
              <option value="DE">Germany</option><option value="FR">France</option>
              <option value="GB">United Kingdom</option><option value="US">United States</option>
            </select></div>
        </fieldset>

        <fieldset class="fset">
          <legend><span class="fset__n">3</span> Delivery method</legend>
          <div class="radios">
{''.join(f'''            <label class="radio"><input type="radio" name="ship" value="{s['id']}"{' checked' if i == 0 else ''} />
              <span class="radio__box"></span>
              <span class="radio__txt"><b>{s['label']}</b><i>{s['eta']}</i></span>
              <span class="radio__price">{'Free' if s['price'] == 0 else money(s['price'])}</span></label>''' for i, s in enumerate(SHIPPING))}
          </div>
        </fieldset>

        <fieldset class="fset">
          <legend><span class="fset__n">4</span> Payment</legend>
          <div class="paymethods">
{''.join(f'''            <label class="paymethod"><input type="radio" name="pay" value="{m['id']}"{' checked' if i == 0 else ''} />
              <span class="paymethod__badge">{E(m['label'].split()[0])}</span>
              <span class="paymethod__txt"><b>{E(m['label'])}</b><i>{E(m['note'])}</i></span></label>''' for i, m in enumerate(PAYMENTS))}
          </div>

          <div class="cardfields" id="cardFields">
            <div class="field"><label for="cardnum">Card number</label>
              <input id="cardnum" name="cardnum" inputmode="numeric" autocomplete="cc-number" placeholder="4242 4242 4242 4242" />
              <p class="field__err" data-err="cardnum"></p></div>
            <div class="field-row">
              <div class="field"><label for="cardexp">Expiry</label>
                <input id="cardexp" name="cardexp" inputmode="numeric" autocomplete="cc-exp" placeholder="MM/YY" />
                <p class="field__err" data-err="cardexp"></p></div>
              <div class="field"><label for="cardcvc">CVC</label>
                <input id="cardcvc" name="cardcvc" inputmode="numeric" autocomplete="cc-csc" placeholder="123" />
                <p class="field__err" data-err="cardcvc"></p></div>
            </div>
          </div>
          <p class="checkout__secure"><svg class="icon icon--xs"><use href="#i-shield"/></svg>
            Payments are encrypted. This is a demonstration storefront — no card is charged.</p>
        </fieldset>

        <button class="btn btn--primary btn--block btn--lg" type="submit" id="placeOrder">
          <span>Place order</span><svg class="icon icon--sm"><use href="#i-arrow-r"/></svg>
        </button>
        <p class="checkout__fine">By placing this order you agree to our <a href="terms.html">Terms</a> and <a href="privacy.html">Privacy Policy</a>.</p>
      </form>

      <aside class="checkout__summary" aria-label="Order summary">
        <h2 class="summary__title">Order summary</h2>
        <div class="summary__items" id="summaryItems"></div>
        <div class="summary__row"><span>Subtotal</span><b id="sumSubtotal">$0.00</b></div>
        <div class="summary__row"><span>Delivery</span><b id="sumShip">Free</b></div>
        <div class="summary__row summary__row--tax"><span>VAT (25%)</span><b id="sumTax">$0.00</b></div>
        <div class="summary__row summary__row--total"><span>Total</span><b id="sumTotal">$0.00</b></div>
        <div class="promo">
          <label for="promo">Promotion code</label>
          <div class="promo__row"><input id="promo" placeholder="Try LUME10" /><button class="btn btn--outline" type="button" id="promoApply">Apply</button></div>
          <p class="promo__msg" id="promoMsg"></p>
        </div>
        <ul class="summary__trust">
          <li><svg class="icon icon--xs"><use href="#i-shield"/></svg> Secure checkout</li>
          <li><svg class="icon icon--xs"><use href="#i-truck"/></svg> Carbon-neutral delivery</li>
          <li><svg class="icon icon--xs"><use href="#i-leaf"/></svg> 60-night returns</li>
        </ul>
      </aside>
    </div>
  </div>
</section>
"""
    write("checkout.html", page("Checkout — LUMÉ Pet Atelier",
                                "Complete your LUMÉ order: delivery, payment and order summary.",
                                body, active=""))


# ------------------------------------------------------------------ cart
def build_cart():
    body = """
<section class="section">
  <div class="wrap">
    <nav class="crumbs" aria-label="Breadcrumb"><a href="index.html">Home</a><i aria-hidden="true">/</i><span aria-current="page">Your bag</span></nav>
    <h1 class="page-hero__title">Your bag</h1>
    <div class="cartpage">
      <div class="cartpage__items" id="cartPageItems"></div>
      <aside class="cartpage__side">
        <h2 class="summary__title">Summary</h2>
        <div class="summary__row"><span>Subtotal</span><b id="cartPageSubtotal">$0.00</b></div>
        <div class="summary__row"><span>Delivery</span><b>Calculated at checkout</b></div>
        <a class="btn btn--primary btn--block" href="checkout.html"><span>Checkout</span><svg class="icon icon--sm"><use href="#i-arrow-r"/></svg></a>
        <a class="btn btn--ghost btn--block" href="index.html#bestsellers">Continue shopping</a>
        <ul class="summary__trust">
          <li><svg class="icon icon--xs"><use href="#i-shield"/></svg> Secure checkout</li>
          <li><svg class="icon icon--xs"><use href="#i-truck"/></svg> Free delivery over $75</li>
        </ul>
      </aside>
    </div>
  </div>
</section>
"""
    write("cart.html", page("Your bag — LUMÉ Pet Atelier",
                            "Review the items in your LUMÉ bag before checkout.", body))


# ------------------------------------------------------------------- 404
def build_404():
    body = f"""
<section class="section notfound">
  <div class="wrap">
    <p class="eyebrow">Error 404</p>
    <h1 class="notfound__title">This page has wandered off.</h1>
    <p class="notfound__lede">The link may be broken, or the piece may have sold out.
    Let us help you find the way back.</p>
    <div class="notfound__cta">
      <a class="btn btn--primary" href="index.html"><span>Back to home</span><svg class="icon icon--sm"><use href="#i-arrow-r"/></svg></a>
      <a class="btn btn--ghost" href="index.html#bestsellers">Shop bestsellers</a>
    </div>
    <div class="products products--grid">{cards(PRODUCTS[:4])}</div>
  </div>
</section>
"""
    write("404.html", page("Page not found — LUMÉ Pet Atelier",
                           "The page you were looking for could not be found.", body))


def slugify_heading(text):
    """Anchor id for a prose heading, so footer links like about.html#makers land."""
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-") or "section"


def simple_page(slug, title, lede, sections, active=""):
    """A content page built from (heading, [paragraph|list]) sections.

    Each section gets an anchor id derived from its heading (or an explicit
    third tuple element), which is what the footer's deep links target.
    """
    blocks = []
    used_ids = set()
    for sec in sections:
        h, content = sec[0], sec[1]
        anchor = sec[2] if len(sec) > 2 else slugify_heading(h)
        while anchor in used_ids:
            anchor += "-2"
        used_ids.add(anchor)
        if isinstance(content, str):
            inner = f"<p>{content}</p>"
        elif isinstance(content, tuple) and content[0] == "list":
            inner = "<ul class=\"prose__list\">" + "".join(f"<li>{x}</li>" for x in content[1]) + "</ul>"
        elif isinstance(content, tuple) and content[0] == "faq":
            inner = "".join(
                f'<details class="faq"><summary>{q}</summary><div class="faq__body"><p>{a}</p></div></details>'
                for q, a in content[1])
        elif isinstance(content, tuple) and content[0] == "cards":
            inner = '<div class="infocards">' + "".join(
                f'<article class="infocard"><h3>{t}</h3><p>{b}</p></article>' for t, b in content[1]) + "</div>"
        else:
            inner = "".join(f"<p>{p}</p>" for p in content)
        blocks.append(f'<section class="prose__block reveal" id="{anchor}"><h2>{h}</h2>{inner}</section>')
    body = f"""
<section class="page-hero">
  <div class="wrap">
    {crumbs([(title, None)])}
    <h1 class="page-hero__title reveal">{title}</h1>
    <p class="page-hero__lede reveal" data-delay="1">{lede}</p>
  </div>
</section>
<section class="section section--prose">
  <div class="wrap"><div class="prose">{''.join(blocks)}</div></div>
</section>
"""
    write(f"{slug}.html", page(f"{title} — LUMÉ Pet Atelier", lede, body, active=active))


def build_supporting():
    simple_page(
        "about", "Our story",
        "LUMÉ began in a Copenhagen kitchen with one badly-made dog bed and a stubborn belief "
        "that pet things deserve the same care as the things we keep for ourselves.",
        [
            ("Made by twelve makers", [
                "We work with twelve family-run workshops across Europe — a tannery in Tuscany, "
                "a stoneware studio in Portugal, a loom in Yorkshire. Every one of them is small "
                "enough to know our names, and none of them would recognise a minimum order quantity.",
                "That is slower, and it costs more. It also means we can repair rather than replace, "
                "and that the person who made your bed can tell you exactly what is in it.",
            ]),
            ("Sustainability", ("cards", [
                ("Materials", "Organic cotton, FSC timber, vegetable-tanned leather and recycled "
                              "webbing — chosen so a piece can be repaired rather than binned."),
                ("Delivery", "Every order ships carbon-neutral, in plastic-free packaging you can "
                             "compost or recycle at the kerbside."),
                ("Longevity", "Spare covers, replacement sisal and new chew tips are all available, "
                              "so a favourite lasts years rather than seasons."),
            ])),
            ("Our makers", [
                "Our makers are named on every product page. When you buy from LUMÉ, you are buying "
                "from a workshop with a name, not from a spreadsheet.",
            ], "makers"),
            ("Our promise", [
                "If a piece does not suit your companion, send it back within 60 nights for a full "
                "refund. No forms, no restocking fee, no questions about whether they really used it.",
            ]),
        ], active="Our Story")

    simple_page(
        "contact", "Contact us",
        "A real person reads every message. We usually reply the same working day.",
        [
            ("Ways to reach us", ("cards", [
                ("Customer care", "hello@lume.atelier — orders, delivery and returns."),
                ("Product advice", "atelier@lume.atelier — sizing, materials and care."),
                ("Call us", "+45 32 14 88 02, Monday to Friday, 9am–6pm CET."),
            ])),
            ("Visit the studio", [
                "Studio 4, Bredgade 21, 1260 Copenhagen K, Denmark. Open by appointment — "
                "come and meet the collection, and bring the dog.",
            ]),
            ("Trade and press", [
                "For wholesale, stockist enquiries or press samples, write to trade@lume.atelier "
                "with a little detail about what you need and we will come back to you quickly.",
            ]),
        ], active="Contact")

    simple_page(
        "faq", "Frequently asked questions",
        "Sizing, care, delivery and returns — the things people ask us most.",
        [
            ("Ordering and delivery", ("faq", [
                ("How long does delivery take?",
                 "Standard delivery is 3–5 working days and free over $75. Express is 1–2 days, "
                 "and next-day arrives before 1pm if you order by 4pm."),
                ("Do you ship internationally?",
                 "We ship across Europe and to the United States. Duties are calculated at checkout "
                 "so there is nothing to pay on the doorstep."),
                ("Can I track my order?",
                 "Yes — every order gets a tracking link by email, and you can follow it any time "
                 "from the Track order page."),
            ])),
            ("Sizing and fit", ("faq", [
                ("How do I choose a bed size?",
                 "Measure your companion nose to tail while they are lying stretched out, then add "
                 "10 cm. If they curl up, the next size down is usually fine."),
                ("Are the collars true to size?",
                 "Measure the neck snugly and add two fingers. Our size guide gives the exact range "
                 "for every collar, and leather softens by a few millimetres as it breaks in."),
            ]), "size"),
            ("Care and returns", ("faq", [
                ("How do I wash a bed cover?",
                 "Unzip the cover and machine wash at 30° on a gentle cycle. Tumble dry on low or "
                 "line dry — never hot, as it shrinks the organic cotton."),
                ("What is the returns window?",
                 "60 nights. Send it back unused and in its original packaging and we refund you "
                 "in full, including the original delivery cost."),
                ("Do you repair rather than replace?",
                 "Where we can. Spare covers, replacement sisal columns and new chew tips are all "
                 "available, and a repair keeps a favourite out of landfill."),
            ])),
        ], active="FAQs")

    simple_page(
        "shipping", "Delivery and returns",
        "Free carbon-neutral delivery over $75, tracked every step, and 60 nights to change your mind.",
        [
            ("Delivery options", ("cards", [
                ("Standard", "3–5 working days. Free over $75, otherwise $6. Tracked."),
                ("Express", "1–2 working days, $12. Tracked, and signed for on delivery."),
                ("Next day", "Tomorrow before 1pm, $22. Order before 4pm."),
            ])),
            ("Where we ship", [
                "We deliver across Europe and to the United States. Prices include any duties due, "
                "so nothing is collected at the door.",
            ]),
            ("Returns", [
                "You have 60 nights from delivery. Return anything unused and in its original "
                "packaging and we will refund the full amount, including the original delivery cost.",
                "To start a return, reply to your order confirmation or write to hello@lume.atelier "
                "with your order reference and we will send a label.",
            ]),
            ("Damaged or faulty items", [
                "If something arrives damaged or fails in normal use, send us a photograph and we "
                "will replace it straight away — no need to return the original first.",
            ]),
        ], active="Delivery")

    simple_page(
        "privacy", "Privacy policy",
        "We collect the least we can, keep it only as long as we need it, and never sell it.",
        [
            ("What we collect", [
                "To fulfil an order we need your name, address, email and payment details. Payment "
                "details go straight to our payment processor and never touch our servers.",
            ]),
            ("Cookies", [
                "We use one cookie to remember your bag and one to remember your saved items. "
                "There is no advertising or cross-site tracking on this site.",
            ]),
            ("Your rights", [
                "You can ask us for a copy of everything we hold about you, ask us to correct it, "
                "or ask us to delete it. Write to privacy@lume.atelier and we will act within "
                "30 days.",
            ]),
            ("Retention", [
                "Order records are kept for seven years because tax law requires it. Everything "
                "else is deleted within a year of your last order.",
            ]),
        ])

    simple_page(
        "terms", "Terms of service",
        "The agreement between you and LUMÉ Pet Atelier when you buy from this store.",
        [
            ("Orders", [
                "An order is an offer to buy. It is accepted when we confirm dispatch, and we may "
                "decline an order if an item is mispriced or out of stock.",
            ]),
            ("Pricing", [
                "Prices are in US dollars and include any duties for the destinations we ship to. "
                "VAT is shown separately at checkout.",
            ]),
            ("Your rights", [
                "Nothing here limits your statutory rights, including your right to cancel within "
                "14 days of delivery under EU consumer law — our own 60-night window is more "
                "generous and takes precedence.",
            ]),
            ("Liability", [
                "We are responsible for products being as described and fit for purpose. We are not "
                "responsible for damage caused by a pet to a product, or by a product used contrary "
                "to its care instructions.",
            ]),
        ])

    simple_page(
        "track", "Track your order",
        "Enter your order reference and we will show you where your parcel has got to.",
        [
            ("Find your order", [
                "Your reference looks like LM-A1B2C3 and is in your confirmation email. If you "
                "cannot find it, write to hello@lume.atelier with your email address and we will "
                "dig it out.",
            ]),
        ])


# ------------------------------------------------------- customer tools
def build_wishlist():
    """The saved-items page. Renders the same localStorage list the hearts write to."""
    body = """
<section class="page-hero">
  <div class="wrap">
    __CRUMBS__
    <h1 class="page-hero__title reveal">Saved pieces</h1>
    <p class="page-hero__lede reveal" data-delay="1">Everything you have tapped the heart on,
    kept here so you can find it again. Move anything into your bag, or clear it out.</p>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="toolbar" id="wishToolbar">
      <p class="listing__count" id="wishCount">0 saved</p>
      <div class="toolbar__actions">
        <button class="btn btn--outline btn--sm" id="wishAddAll" type="button">Add all to bag</button>
        <button class="link-underline" id="wishClear" type="button">Clear all</button>
      </div>
    </div>

    <div class="products products--grid" id="wishGrid"></div>

    <div class="empty" id="wishEmpty">
      <svg class="icon icon--lg"><use href="#i-heart"/></svg>
      <h2>Nothing saved yet</h2>
      <p>Tap the heart on any piece and it will wait for you here — across visits, on this device.</p>
      <a class="btn btn--primary" href="index.html#bestsellers"><span>Browse bestsellers</span><svg class="icon icon--sm"><use href="#i-arrow-r"/></svg></a>
    </div>
  </div>
</section>
""".replace("__CRUMBS__", crumbs([('Saved pieces', None)]))
    write("wishlist.html", page("Saved pieces — LUMÉ Pet Atelier",
                                "Your saved LUMÉ pieces, kept in one place until you are ready.",
                                body, active=""))


def build_account():
    """Sign in / create account, plus the signed-in dashboard (orders, saved
    pieces, delivery address, preferences). A demonstration session only:
    the 'account' lives in localStorage on this device, no server involved."""
    body = """
<section class="section account-hero">
  <div class="wrap">
    __CRUMBS__
    <p class="eyebrow reveal">Your account</p>
    <h1 class="checkout__title reveal" data-delay="1">Your account</h1>
    <p class="page-hero__lede reveal" data-delay="2">Orders, saved pieces, addresses and
    preferences — all in one calm place.</p>
  </div>
</section>

<section class="section account">
  <div class="wrap">
    <p class="account__demo reveal">
      <svg class="icon icon--xs"><use href="#i-shield"/></svg>
      Demonstration storefront — this account lives on your device only. No password is sent anywhere.
    </p>

    <!-- ===================== SIGNED OUT ===================== -->
    <div class="account__grid" id="accountGuest">
      <div class="auth reveal" id="auth">
        <div class="auth__tabs" role="tablist" aria-label="Sign in or create an account">
          <button class="auth__tab is-active" role="tab" aria-selected="true" aria-controls="signinForm" data-tab="signin" type="button">Sign in</button>
          <button class="auth__tab" role="tab" aria-selected="false" aria-controls="registerForm" data-tab="register" type="button">Create account</button>
        </div>

        <form class="auth__panel is-active" id="signinForm" data-panel="signin" novalidate>
          <h2 class="auth__title">Welcome back</h2>
          <p class="auth__lede">Sign in to see your orders, saved pieces and addresses.</p>
          <div class="field"><label for="si-email">Email</label>
            <input id="si-email" type="email" autocomplete="email" placeholder="you@example.com" required />
            <p class="field__err" data-err="si-email"></p></div>
          <div class="field"><label for="si-pass">Password</label>
            <span class="pwfield">
              <input id="si-pass" type="password" autocomplete="current-password" placeholder="Your password" required />
              <button class="pwfield__toggle" type="button" data-pw="si-pass" aria-label="Show password"><svg class="icon icon--sm"><use href="#i-eye"/></svg></button>
            </span>
            <p class="field__err" data-err="si-pass"></p></div>
          <div class="auth__row">
            <label class="check"><input type="checkbox" id="si-remember" checked /> <span>Keep me signed in</span></label>
            <a class="auth__link" href="#reset" id="forgotLink">Forgot password?</a>
          </div>
          <p class="auth__note" id="resetNote" hidden>Password resets are part of a connected store.
          For now, create an account or use any email and a password of 6+ characters to explore.</p>
          <button class="btn btn--primary btn--block btn--lg" type="submit"><span>Sign in</span><svg class="icon icon--sm"><use href="#i-arrow-r"/></svg></button>
          <p class="auth__alt">New to LUMÉ? <button class="auth__switch" data-tab="register" type="button">Create an account</button></p>
        </form>

        <form class="auth__panel" id="registerForm" data-panel="register" novalidate hidden>
          <h2 class="auth__title">Create your account</h2>
          <p class="auth__lede">One account for orders, saved pieces and one-tap reorder.</p>
          <div class="field-row">
            <div class="field"><label for="rg-first">First name</label>
              <input id="rg-first" autocomplete="given-name" required /><p class="field__err" data-err="rg-first"></p></div>
            <div class="field"><label for="rg-last">Last name</label>
              <input id="rg-last" autocomplete="family-name" required /><p class="field__err" data-err="rg-last"></p></div>
          </div>
          <div class="field"><label for="rg-email">Email</label>
            <input id="rg-email" type="email" autocomplete="email" placeholder="you@example.com" required />
            <p class="field__err" data-err="rg-email"></p></div>
          <div class="field"><label for="rg-pass">Password</label>
            <span class="pwfield">
              <input id="rg-pass" type="password" autocomplete="new-password" placeholder="At least 8 characters" required />
              <button class="pwfield__toggle" type="button" data-pw="rg-pass" aria-label="Show password"><svg class="icon icon--sm"><use href="#i-eye"/></svg></button>
            </span>
            <div class="pwmeter" id="pwMeter" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
            <p class="auth__hint" id="pwHint">Use 8+ characters, with a number for good measure.</p>
            <p class="field__err" data-err="rg-pass"></p></div>
          <label class="check"><input type="checkbox" id="rg-terms" required /> <span>I agree to the <a href="terms.html">terms</a> and <a href="privacy.html">privacy policy</a>.</span></label>
          <p class="field__err" data-err="rg-terms"></p>
          <button class="btn btn--primary btn--block btn--lg" type="submit"><span>Create account</span><svg class="icon icon--sm"><use href="#i-arrow-r"/></svg></button>
          <p class="auth__alt">Already have an account? <button class="auth__switch" data-tab="signin" type="button">Sign in</button></p>
        </form>
      </div>

      <aside class="account__aside reveal" data-delay="2">
        <h2 class="account__aside-title">Why keep an account</h2>
        <ul class="account__perks">
          <li><svg class="icon"><use href="#i-truck"/></svg><div><b>Follow every parcel</b><span>Order history and delivery status in one view.</span></div></li>
          <li><svg class="icon"><use href="#i-heart"/></svg><div><b>Saved pieces, kept</b><span>Your shortlist waits for you, across visits.</span></div></li>
          <li><svg class="icon"><use href="#i-sparkle"/></svg><div><b>One-tap reorder</b><span>Repeat the essentials without re-typing a thing.</span></div></li>
          <li><svg class="icon"><use href="#i-gift"/></svg><div><b>Early access</b><span>First look at limited editions and the Winter Warmth Edit.</span></div></li>
        </ul>
        <p class="account__aside-fine">Members get free delivery over $75 and our 60-night comfort promise.</p>
      </aside>
    </div>

    <!-- ===================== SIGNED IN ===================== -->
    <div class="account__grid account__grid--dash" id="accountDash" hidden>
      <div class="account__main">
        <header class="account__head">
          <div>
            <p class="eyebrow">Signed in</p>
            <h2 class="account__hello">Hello, <span id="acctName">friend</span></h2>
            <p class="account__meta" id="acctEmail"></p>
          </div>
          <button class="btn btn--outline btn--sm" id="signOut" type="button">Sign out</button>
        </header>

        <section class="account__panel">
          <div class="account__panel-head">
            <h3 class="account__sub">Orders</h3>
            <a class="link-arrow" href="index.html#bestsellers">Shop again <svg class="icon icon--sm"><use href="#i-arrow-r"/></svg></a>
          </div>
          <div id="acctOrders"></div>
        </section>

        <section class="account__panel">
          <div class="account__panel-head">
            <h3 class="account__sub">Saved pieces</h3>
            <a class="link-arrow" href="wishlist.html">Open wishlist <svg class="icon icon--sm"><use href="#i-arrow-r"/></svg></a>
          </div>
          <p class="account__hint" id="acctWishLine">Nothing saved yet.</p>
          <div class="acctwish" id="acctWish"></div>
        </section>
      </div>

      <aside class="account__side">
        <section class="account__panel">
          <h3 class="account__sub">Delivery address</h3>
          <form class="account__addr" id="addrForm" novalidate>
            <div class="field"><label for="ad-name">Full name</label>
              <input id="ad-name" autocomplete="name" placeholder="Ada Lovelace" /></div>
            <div class="field"><label for="ad-line">Address</label>
              <input id="ad-line" autocomplete="street-address" placeholder="Street and number" /></div>
            <div class="field-row">
              <div class="field"><label for="ad-city">City</label><input id="ad-city" autocomplete="address-level2" /></div>
              <div class="field"><label for="ad-zip">Postcode</label><input id="ad-zip" autocomplete="postal-code" /></div>
            </div>
            <div class="field"><label for="ad-country">Country</label>
              <select id="ad-country">
                <option value="DK">Denmark</option><option value="SE">Sweden</option>
                <option value="DE">Germany</option><option value="FR">France</option>
                <option value="GB">United Kingdom</option><option value="US">United States</option>
              </select></div>
            <button class="btn btn--outline btn--sm" type="submit">Save address</button>
            <p class="account__hint" id="addrMsg"></p>
          </form>
        </section>

        <section class="account__panel">
          <h3 class="account__sub">Preferences</h3>
          <div class="account__prefs">
            <label class="check"><input type="checkbox" id="prefNews" /> <span>New arrivals &amp; care notes</span></label>
            <label class="check"><input type="checkbox" id="prefRestock" /> <span>Back-in-stock alerts</span></label>
            <label class="check"><input type="checkbox" id="prefOffers" /> <span>Occasional offers</span></label>
          </div>
          <p class="account__hint" id="prefMsg"></p>
        </section>

        <section class="account__panel account__panel--help">
          <h3 class="account__sub">Need a hand?</h3>
          <ul class="account__links">
            <li><a href="track.html">Track an order <svg class="icon icon--xs"><use href="#i-arrow-r"/></svg></a></li>
            <li><a href="shipping.html">Shipping &amp; returns <svg class="icon icon--xs"><use href="#i-arrow-r"/></svg></a></li>
            <li><a href="size-guide.html">Size guide <svg class="icon icon--xs"><use href="#i-arrow-r"/></svg></a></li>
            <li><a href="contact.html">Contact us <svg class="icon icon--xs"><use href="#i-arrow-r"/></svg></a></li>
          </ul>
        </section>
      </aside>
    </div>
  </div>
</section>
""".replace("__CRUMBS__", crumbs([('Your account', None)]))
    write("account.html", page("Your account — LUMÉ Pet Atelier",
                               "Sign in or create your LUMÉ account to see orders, saved pieces and delivery addresses.",
                               body, active=""))


def build_size_guide():
    """An interactive measuring guide that recommends a size from real inputs."""
    # Each size chart: (product family, [(size, min, max, note)])
    charts = {
        "bed": ("Beds & sleep", [
            ("Small", 0, 45, "Up to 45 cm nose-to-tail"),
            ("Medium", 45, 65, "45–65 cm"),
            ("Large", 65, 90, "65–90 cm"),
            ("Grand", 90, 200, "90 cm and up"),
        ]),
        "collar": ("Collars & harnesses", [
            ("XS", 20, 28, "Neck 20–28 cm"),
            ("S", 28, 36, "Neck 28–36 cm"),
            ("M", 36, 46, "Neck 36–46 cm"),
            ("L", 46, 58, "Neck 46–58 cm"),
            ("XL", 58, 72, "Neck 58–72 cm"),
        ]),
        "apparel": ("Coats & wear", [
            ("S", 0, 30, "Back length up to 30 cm"),
            ("M", 30, 42, "30–42 cm"),
            ("L", 42, 55, "42–55 cm"),
            ("XL", 55, 200, "55 cm and up"),
        ]),
    }
    rows = []
    for key, (label, sizes) in charts.items():
        opts = "".join(
            f'<tr><td><b>{E(s)}</b></td><td>{lo}–{hi if hi < 200 else "∞"} cm</td><td>{E(note)}</td></tr>'
            for s, lo, hi, note in sizes)
        rows.append(f"""      <div class="sizecard" id="chart-{key}">
        <h3>{E(label)}</h3>
        <table class="sizetable"><thead><tr><th>Size</th><th>Fits</th><th>How to check</th></tr></thead>
        <tbody>{opts}</tbody></table>
      </div>""")

    chart_data = {k: {"label": v[0], "sizes": [list(s) for s in v[1]]} for k, v in charts.items()}

    body = f"""
<section class="page-hero">
  <div class="wrap">
    {crumbs([('Size guide', None)])}
    <h1 class="page-hero__title reveal">Find the right size</h1>
    <p class="page-hero__lede reveal" data-delay="1">Two measurements are all it takes. Measure
    with a soft tape while your companion is standing, then let the guide do the arithmetic.</p>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="sizefinder reveal" id="sizeFinder">
      <form class="sizefinder__form" id="sizeForm" novalidate>
        <div class="field">
          <label for="sizeType">What are you sizing for?</label>
          <select id="sizeType">
            <option value="bed">A bed</option>
            <option value="collar">A collar or harness</option>
            <option value="apparel">A coat or jumper</option>
          </select>
        </div>
        <div class="field">
          <label for="sizePet">Who is it for?</label>
          <select id="sizePet">
            <option value="dog">A dog</option>
            <option value="cat">A cat</option>
            <option value="small">A small pet</option>
          </select>
        </div>
        <div class="field">
          <label for="sizeCm" id="sizeCmLabel">Measurement in cm</label>
          <input type="number" id="sizeCm" min="1" max="200" step="1" placeholder="e.g. 54" inputmode="numeric" />
          <p class="field__err" id="sizeErr"></p>
        </div>
        <div class="sizefinder__actions">
          <button class="btn btn--primary" type="submit"><span>Recommend a size</span><svg class="icon icon--sm"><use href="#i-arrow-r"/></svg></button>
          <button class="link-underline" type="button" id="sizeReset">Reset</button>
        </div>
        <p class="sizefinder__hint" id="sizeHint">Measuring a bed? Run the tape from nose to tail while
        they lie stretched out, then add 10 cm. For a collar, measure the neck snugly and add two fingers.</p>
      </form>
      <div class="sizefinder__result" id="sizeResult" aria-live="polite" hidden></div>
    </div>

    <section class="section--related">
      <div class="section__head"><h2 class="section__title">Size charts</h2></div>
      <div class="sizecards">
{''.join(rows)}
      </div>
    </section>

    <section class="section--related">
      <div class="section__head"><h2 class="section__title">Pieces in this guide</h2></div>
      <div class="products products--grid">
{cards([p for p in PRODUCTS if p['cats'][-1] in ('sleep', 'walks', 'apparel')][:4])}
      </div>
    </section>
  </div>
</section>
<script id="sizeCharts" type="application/json">{json.dumps(chart_data)}</script>
"""
    write("size-guide.html", page("Size guide — LUMÉ Pet Atelier",
                                  "Measure once and get the right size for beds, collars, harnesses "
                                  "and coats — with charts and an interactive finder.",
                                  body, active=""))


def build_compare():
    """Compare up to four products side by side, picked with a live search box."""
    body = f"""
<section class="page-hero">
  <div class="wrap">
    {crumbs([('Compare', None)])}
    <h1 class="page-hero__title reveal">Compare pieces</h1>
    <p class="page-hero__lede reveal" data-delay="1">Put up to four pieces next to each other —
    price, rating, materials and care — and see exactly where the money goes.</p>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="compare__picker reveal">
      <label class="field" for="compareSearch">
        <span class="compare__label">Add a piece</span>
        <input type="search" id="compareSearch" placeholder="Search by name or material…" autocomplete="off" />
      </label>
      <div class="compare__suggest" id="compareSuggest" hidden></div>
      <div class="compare__popular">
        <span>Popular:</span>
        <button class="chip" data-compare-add="cloud-nine-bed">Cloud Nine Bed</button>
        <button class="chip" data-compare-add="atelier-collar">Atelier Collar</button>
        <button class="chip" data-compare-add="climbing-tree">Climbing Tower</button>
        <button class="chip" data-compare-add="slow-cooked-wet">Slow-cooked Wet Food</button>
      </div>
    </div>

    <div class="compare__wrap" id="compareWrap">
      <table class="compare__table" id="compareTable"></table>
    </div>

    <div class="empty" id="compareEmpty">
      <svg class="icon icon--lg"><use href="#i-star"/></svg>
      <h2>Nothing to compare yet</h2>
      <p>Add two or more pieces above and we will line up their details for you.</p>
      <a class="btn btn--primary" href="index.html#bestsellers"><span>Browse the shop</span><svg class="icon icon--sm"><use href="#i-arrow-r"/></svg></a>
    </div>
  </div>
</section>
"""
    write("compare.html", page("Compare — LUMÉ Pet Atelier",
                               "Compare LUMÉ beds, collars, food and toys side by side on price, "
                               "rating, materials and care.",
                               body, active=""))


def build_gift_guide():
    """Gift finder: pick a recipient and a budget, get matching pieces."""
    bands = [
        ("Under $50", 0, 50),
        ("$50 – $100", 50, 100),
        ("$100 – $200", 100, 200),
        ("$200 and up", 200, 100000),
    ]
    band_chips = "".join(
        f'<button class="chip" data-gift-band="{i}">{E(label)}</button>' for i, (label, _, _) in enumerate(bands))
    band_data = [{"label": l, "min": a, "max": b} for l, a, b in bands]
    body = f"""
<section class="page-hero">
  <div class="wrap">
    {crumbs([('Gift guide', None)])}
    <h1 class="page-hero__title reveal">The gift guide</h1>
    <p class="page-hero__lede reveal" data-delay="1">Tell us who it is for and roughly what you
    would like to spend. We will narrow the atelier down to things they will actually use.</p>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="giftfinder reveal">
      <div class="giftfinder__row">
        <span class="giftfinder__label">Who is it for?</span>
        <div class="filters" role="group" aria-label="Recipient">
          <button class="chip is-active" data-gift-pet="all">Anyone</button>
          <button class="chip" data-gift-pet="dogs">A dog</button>
          <button class="chip" data-gift-pet="cats">A cat</button>
          <button class="chip" data-gift-pet="small-pets">A small pet</button>
        </div>
      </div>
      <div class="giftfinder__row">
        <span class="giftfinder__label">What budget?</span>
        <div class="filters" role="group" aria-label="Budget">
          <button class="chip is-active" data-gift-band="all">Any</button>
          {band_chips}
        </div>
      </div>
      <div class="giftfinder__row">
        <span class="giftfinder__label">The occasion?</span>
        <div class="filters" role="group" aria-label="Occasion">
          <button class="chip is-active" data-gift-mood="all">Any</button>
          <button class="chip" data-gift-mood="new">New arrival</button>
          <button class="chip" data-gift-mood="cosy">Cosy</button>
          <button class="chip" data-gift-mood="active">Active</button>
          <button class="chip" data-gift-mood="treat">A treat</button>
        </div>
      </div>
    </div>

    <div class="giftfinder__bar">
      <p class="listing__count" id="giftCount">34 gifts</p>
      <a class="link-underline" href="wishlist.html">Save ideas to your list</a>
    </div>
    <div class="products products--grid" id="giftGrid" data-cat=""></div>
    <div class="empty" id="giftEmpty" hidden>
      <svg class="icon icon--lg"><use href="#i-search"/></svg>
      <h2>No gifts match yet</h2>
      <p>Try a wider budget or a different companion.</p>
    </div>
  </div>
</section>
<script id="giftBands" type="application/json">{json.dumps(band_data)}</script>
"""
    write("gift-guide.html", page("Gift guide — LUMÉ Pet Atelier",
                                  "Find a gift by recipient, budget and occasion from across the "
                                  "LUMÉ atelier.",
                                  body, active=""))


def write_catalogue_js():
    """Emit assets/js/catalogue.js from assets/data/catalogue.json.

    The browser reads the catalogue from window.LUME. Generating this file from
    the JSON keeps the Python build and the runtime catalogue in lockstep.
    """
    d = B.DATA
    payload = "\n".join(
        f"  const {name} = {json.dumps(d[key], ensure_ascii=False, indent=2)};"
        for name, key in [("CATEGORIES", "categories"), ("NAV", "nav"),
                          ("PRODUCTS", "products"), ("REVIEWS", "reviews"),
                          ("PAYMENTS", "payments"), ("SHIPPING", "shipping")]
    )
    js = f"""/* =========================================================
   LUMÉ — Pet Atelier · catalogue
   Generated from assets/data/catalogue.json by tools/build.py.
   Do not edit by hand. Loaded by every page; exposes window.LUME.
   ========================================================= */
(function () {{
  "use strict";

{payload};

  window.LUME = {{
    CATEGORIES, NAV, PRODUCTS, REVIEWS, PAYMENTS, SHIPPING,
    byId: (id) => PRODUCTS.find((p) => p.id === id),
    byCat: (c) => PRODUCTS.filter((p) => p.cats.includes(c)),
    bySlug: (s) => PRODUCTS.find((p) => p.slug === s),
  }};
}})();
"""
    with open(os.path.join(ROOT, "assets/js/catalogue.js"), "w", encoding="utf-8") as f:
        f.write(js)


def main():
    write_catalogue_js()
    print("Building LUMÉ storefront…")
    build_home()
    for key, (title, blurb) in CAT_PAGES.items():
        cat_key = {"food": "nutrition", "toys": "toys"}.get(key, key)
        build_category(key, cat_key, title, blurb)
    for p in PRODUCTS:
        build_product(p)
    build_reviews()
    build_checkout()
    build_cart()
    build_404()
    build_supporting()
    build_account()
    build_wishlist()
    build_size_guide()
    build_compare()
    build_gift_guide()
    print("done")


if __name__ == "__main__":
    main()
