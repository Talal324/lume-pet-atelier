/* =========================================================
   LUMÉ — Pet Atelier · catalogue
   Generated from assets/data/catalogue.json by tools/build.py.
   Do not edit by hand. Loaded by every page; exposes window.LUME.
   ========================================================= */
(function () {
  "use strict";

  const CATEGORIES = [
  {
    "id": "dogs",
    "name": "Dogs",
    "blurb": "Beds, leads, collars and everyday kit.",
    "img": "assets/img/cat-dogs.jpg",
    "href": "dogs.html"
  },
  {
    "id": "cats",
    "name": "Cats",
    "blurb": "Scratch posts, dens and quiet corners.",
    "img": "assets/img/cat-cats.jpg",
    "href": "cats.html"
  },
  {
    "id": "small-pets",
    "name": "Small Pets",
    "blurb": "Hutches, hay and hideaways for little ones.",
    "img": "assets/img/cat-small.jpg",
    "href": "small-pets.html"
  },
  {
    "id": "nutrition",
    "name": "Nutrition",
    "blurb": "Slow-cooked recipes and gentle supplements.",
    "img": "assets/img/cat-gift.jpg",
    "href": "food.html"
  }
];
  const NAV = [
  {
    "label": "Shop All",
    "href": "index.html#bestsellers"
  },
  {
    "label": "Dogs",
    "href": "dogs.html"
  },
  {
    "label": "Cats",
    "href": "cats.html"
  },
  {
    "label": "Small Pets",
    "href": "small-pets.html"
  },
  {
    "label": "Food",
    "href": "food.html"
  },
  {
    "label": "Toys",
    "href": "toys.html"
  }
];
  const PRODUCTS = [
  {
    "id": "cloud-nine-bed",
    "slug": "cloud-nine-orthopedic-bed",
    "name": "Cloud Nine Orthopedic Bed",
    "cat": "Sleep",
    "price": 189,
    "was": 225,
    "cats": [
      "dogs",
      "sleep"
    ],
    "rating": 4.9,
    "reviews": 412,
    "badge": "Bestseller",
    "badgeClass": "badge--best",
    "img": "assets/img/p1.jpg",
    "gallery": [
      "assets/img/p1.jpg",
      "assets/img/life-dog-01.jpg",
      "assets/img/life-dog-02.jpg"
    ],
    "desc": "Memory-foam base with a breathable organic-cotton cover that unzips for the wash.",
    "long": "A deep, supportive bed built around a pressure-relieving memory-foam core. The bolster edges give older dogs something to lean against, while the removable cover is woven from certified organic cotton so it stays cool in summer and warm in winter.",
    "swatches": [
      "#E4DAC9",
      "#6B6154",
      "#26221D"
    ],
    "sizes": [
      "Small",
      "Medium",
      "Large",
      "Grand"
    ],
    "stock": 12,
    "sku": "LM-BED-001",
    "specs": {
      "Material": "Organic cotton, memory foam",
      "Care": "Cover machine washable at 30°",
      "Origin": "Made in Portugal",
      "Warranty": "5 years"
    }
  },
  {
    "id": "atelier-collar",
    "slug": "atelier-leather-collar",
    "name": "Atelier Leather Collar",
    "cat": "Collars",
    "price": 68,
    "was": null,
    "cats": [
      "dogs",
      "walks"
    ],
    "rating": 4.8,
    "reviews": 236,
    "badge": "New",
    "badgeClass": "badge--new",
    "img": "assets/img/p2.jpg",
    "gallery": [
      "assets/img/p2.jpg",
      "assets/img/life-dog-03.jpg",
      "assets/img/life-dog-04.jpg"
    ],
    "desc": "Vegetable-tanned leather with solid brass hardware that ages into a fine patina.",
    "long": "Cut from a single hide and finished by hand, this collar softens with wear rather than cracking. The solid brass buckle is cast in a small foundry and will outlast the leather many times over.",
    "swatches": [
      "#7A4B2A",
      "#26221D",
      "#C39A5C"
    ],
    "sizes": [
      "XS",
      "S",
      "M",
      "L",
      "XL"
    ],
    "stock": 34,
    "sku": "LM-COL-002",
    "specs": {
      "Material": "Vegetable-tanned leather, brass",
      "Care": "Condition twice a year",
      "Origin": "Made in Italy",
      "Warranty": "3 years"
    }
  },
  {
    "id": "everyday-lead",
    "slug": "everyday-walking-lead",
    "name": "Everyday Walking Lead",
    "cat": "Walks",
    "price": 54,
    "was": null,
    "cats": [
      "dogs",
      "walks"
    ],
    "rating": 4.8,
    "reviews": 159,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/p6.jpg",
    "gallery": [
      "assets/img/p6.jpg",
      "assets/img/life-dog-05.jpg",
      "assets/img/life-dog-06.jpg"
    ],
    "desc": "Soft-woven webbing with a padded handle and a reflective thread for dark evenings.",
    "long": "Woven on a narrow loom so the webbing stays supple in the hand. The handle is padded and stitched twice at every stress point, and a reflective thread runs its full length.",
    "swatches": [
      "#6B6154",
      "#26221D",
      "#C39A5C"
    ],
    "sizes": [
      "1.2 m",
      "1.8 m"
    ],
    "stock": 41,
    "sku": "LM-LEA-003",
    "specs": {
      "Material": "Recycled polyester webbing",
      "Care": "Hand wash, air dry",
      "Origin": "Made in Portugal",
      "Warranty": "2 years"
    }
  },
  {
    "id": "trail-harness",
    "slug": "trail-harness",
    "name": "Trail Harness",
    "cat": "Walks",
    "price": 78,
    "was": 92,
    "cats": [
      "dogs",
      "walks"
    ],
    "rating": 4.7,
    "reviews": 204,
    "badge": "Sale",
    "badgeClass": "badge--sale",
    "img": "assets/img/dog-harness.jpg",
    "gallery": [
      "assets/img/dog-harness.jpg",
      "assets/img/life-dog-07.jpg",
      "assets/img/life-dog-08.jpg"
    ],
    "desc": "Five-point adjustment with a padded chest plate and a rear haul handle.",
    "long": "Built for long days out. The chest plate spreads load away from the throat, and a reinforced handle on the back lets you lift a tired dog over a stile.",
    "swatches": [
      "#7E8B6E",
      "#26221D",
      "#8E4B4B"
    ],
    "sizes": [
      "S",
      "M",
      "L",
      "XL"
    ],
    "stock": 18,
    "sku": "LM-HAR-004",
    "specs": {
      "Material": "Ripstop nylon, aluminium",
      "Care": "Machine washable at 30°",
      "Origin": "Made in Portugal",
      "Warranty": "3 years"
    }
  },
  {
    "id": "rope-chew-set",
    "slug": "rope-cotton-chew-set",
    "name": "Rope & Cotton Chew Set",
    "cat": "Play",
    "price": 26,
    "was": 34,
    "cats": [
      "dogs",
      "toys",
      "play"
    ],
    "rating": 4.6,
    "reviews": 301,
    "badge": "Sale",
    "badgeClass": "badge--sale",
    "img": "assets/img/p4.jpg",
    "gallery": [
      "assets/img/p4.jpg",
      "assets/img/life-dog-09.jpg",
      "assets/img/life-dog-10.jpg"
    ],
    "desc": "Undyed cotton rope and natural rubber — dental-friendly and endlessly fun.",
    "long": "Three toys in one set: a knotted rope for tug, a rubber ring for fetch, and a woven bone for chewing. Every part is free from dyes and plastic softeners.",
    "swatches": [
      "#EFE8DC",
      "#C9B79C",
      "#8E4B4B"
    ],
    "sizes": [
      "One size"
    ],
    "stock": 57,
    "sku": "LM-TOY-005",
    "specs": {
      "Material": "Cotton rope, natural rubber",
      "Care": "Machine washable at 40°",
      "Origin": "Made in Portugal",
      "Warranty": "1 year"
    }
  },
  {
    "id": "sunday-ball",
    "slug": "sunday-fetch-ball",
    "name": "Sunday Fetch Ball",
    "cat": "Play",
    "price": 18,
    "was": null,
    "cats": [
      "dogs",
      "toys",
      "play"
    ],
    "rating": 4.5,
    "reviews": 143,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/dog-ball.jpg",
    "gallery": [
      "assets/img/dog-ball.jpg",
      "assets/img/life-dog-11.jpg",
      "assets/img/life-dog-12.jpg"
    ],
    "desc": "Solid natural rubber that bounces true and floats on water.",
    "long": "A simple, honest ball. Dense enough to throw a long way, soft enough not to bruise a nose, and it floats — so lakes and rivers are fair game.",
    "swatches": [
      "#8E4B4B",
      "#7E8B6E",
      "#C39A5C"
    ],
    "sizes": [
      "Small",
      "Large"
    ],
    "stock": 88,
    "sku": "LM-TOY-006",
    "specs": {
      "Material": "Natural rubber",
      "Care": "Rinse after use",
      "Origin": "Made in Portugal",
      "Warranty": "1 year"
    }
  },
  {
    "id": "ceramic-bowl",
    "slug": "ceramic-slow-feed-bowl",
    "name": "Ceramic Slow-Feed Bowl",
    "cat": "Nutrition",
    "price": 42,
    "was": null,
    "cats": [
      "dogs",
      "nutrition",
      "feed"
    ],
    "rating": 4.7,
    "reviews": 188,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/p3.jpg",
    "gallery": [
      "assets/img/p3.jpg",
      "assets/img/life-food-01.jpg",
      "assets/img/life-food-02.jpg"
    ],
    "desc": "Hand-glazed stoneware with an anti-gulp spiral, dishwasher friendly.",
    "long": "A heavy stoneware bowl that will not slide across the floor. The internal spiral slows fast eaters, which is kinder on digestion, and the whole thing goes in the dishwasher.",
    "swatches": [
      "#F7F3EC",
      "#7E8B6E",
      "#C39A5C"
    ],
    "sizes": [
      "300 ml",
      "600 ml",
      "900 ml"
    ],
    "stock": 63,
    "sku": "LM-BWL-007",
    "specs": {
      "Material": "Glazed stoneware",
      "Care": "Dishwasher safe",
      "Origin": "Made in Portugal",
      "Warranty": "2 years"
    }
  },
  {
    "id": "grooming-brush",
    "slug": "soft-grooming-brush",
    "name": "Soft Grooming Brush",
    "cat": "Grooming",
    "price": 32,
    "was": null,
    "cats": [
      "dogs",
      "grooming"
    ],
    "rating": 4.6,
    "reviews": 127,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/dog-brush.jpg",
    "gallery": [
      "assets/img/dog-brush.jpg",
      "assets/img/life-dog-13.jpg",
      "assets/img/life-dog-14.jpg"
    ],
    "desc": "Beechwood handle with boar bristles that lift loose hair without scratching.",
    "long": "The bristles are set in beechwood by hand and angled to follow the coat, so a few minutes each week keeps most of the shedding off your furniture.",
    "swatches": [
      "#C9B79C",
      "#7A4B2A"
    ],
    "sizes": [
      "One size"
    ],
    "stock": 46,
    "sku": "LM-GRM-008",
    "specs": {
      "Material": "Beechwood, boar bristle",
      "Care": "Wipe clean",
      "Origin": "Made in Germany",
      "Warranty": "2 years"
    }
  },
  {
    "id": "oatmeal-shampoo",
    "slug": "oatmeal-pet-shampoo",
    "name": "Calm Oatmeal Shampoo",
    "cat": "Grooming",
    "price": 24,
    "was": null,
    "cats": [
      "dogs",
      "cats",
      "grooming"
    ],
    "rating": 4.8,
    "reviews": 265,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/dog-shampoo.jpg",
    "gallery": [
      "assets/img/dog-shampoo.jpg",
      "assets/img/life-dog-15.jpg",
      "assets/img/life-dog-16.jpg"
    ],
    "desc": "Colloidal oatmeal and chamomile, pH-balanced and free from sulphates.",
    "long": "Formulated for sensitive skin. Colloidal oatmeal soothes irritation while chamomile calms, and there are no sulphates, parabens or synthetic perfumes.",
    "swatches": [
      "#EFE8DC"
    ],
    "sizes": [
      "250 ml",
      "500 ml"
    ],
    "stock": 71,
    "sku": "LM-GRM-009",
    "specs": {
      "Material": "Oatmeal, chamomile",
      "Care": "Store below 25°",
      "Origin": "Made in France",
      "Warranty": "n/a"
    }
  },
  {
    "id": "winter-coat",
    "slug": "winter-quilted-coat",
    "name": "Winter Quilted Coat",
    "cat": "Apparel",
    "price": 86,
    "was": 104,
    "cats": [
      "dogs",
      "apparel"
    ],
    "rating": 4.7,
    "reviews": 178,
    "badge": "Sale",
    "badgeClass": "badge--sale",
    "img": "assets/img/dog-coat.jpg",
    "gallery": [
      "assets/img/dog-coat.jpg",
      "assets/img/life-dog-17.jpg",
      "assets/img/life-dog-18.jpg"
    ],
    "desc": "Quilted recycled shell with a fleece lining and a water-repellent finish.",
    "long": "Cut for dogs who hate getting dressed: it slips over the head, closes with one strap, and the harness slot means you never take it off to clip a lead on.",
    "swatches": [
      "#7E8B6E",
      "#8E4B4B",
      "#26221D"
    ],
    "sizes": [
      "XS",
      "S",
      "M",
      "L"
    ],
    "stock": 24,
    "sku": "LM-APP-010",
    "specs": {
      "Material": "Recycled poly shell, fleece",
      "Care": "Machine washable at 30°",
      "Origin": "Made in Portugal",
      "Warranty": "2 years"
    }
  },
  {
    "id": "travel-crate",
    "slug": "travel-carrier-crate",
    "name": "Soft Travel Carrier",
    "cat": "Travel",
    "price": 132,
    "was": null,
    "cats": [
      "dogs",
      "cats",
      "travel"
    ],
    "rating": 4.6,
    "reviews": 92,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/dog-crate.jpg",
    "gallery": [
      "assets/img/dog-crate.jpg",
      "assets/img/life-dog-19.jpg",
      "assets/img/life-dog-20.jpg"
    ],
    "desc": "Airline-friendly frame with mesh panels on three sides and a fleece mat.",
    "long": "Approved by most airlines as cabin baggage. The frame holds its shape when empty, three mesh sides keep air moving, and the base mat lifts out to wash.",
    "swatches": [
      "#6B6154",
      "#26221D"
    ],
    "sizes": [
      "Small",
      "Medium"
    ],
    "stock": 15,
    "sku": "LM-TRV-011",
    "specs": {
      "Material": "Ripstop nylon, steel frame",
      "Care": "Spot clean, mat washable",
      "Origin": "Made in Portugal",
      "Warranty": "3 years"
    }
  },
  {
    "id": "velvet-calm-bed",
    "slug": "velvet-calm-cat-bed",
    "name": "Velvet Calm Cat Bed",
    "cat": "Sleep",
    "price": 124,
    "was": null,
    "cats": [
      "cats",
      "sleep"
    ],
    "rating": 4.9,
    "reviews": 274,
    "badge": "Bestseller",
    "badgeClass": "badge--best",
    "img": "assets/img/p5.jpg",
    "gallery": [
      "assets/img/p5.jpg",
      "assets/img/life-cat-01.jpg",
      "assets/img/life-cat-02.jpg"
    ],
    "desc": "Cocooning velvet shell with a cooling-gel base for the warmer months.",
    "long": "Cats like to feel enclosed, so this bed wraps high on three sides and leaves one low lip to step over. The gel layer underneath pulls heat away in summer and can be removed for winter.",
    "swatches": [
      "#E4DAC9",
      "#7E8B6E",
      "#26221D"
    ],
    "sizes": [
      "Small",
      "Medium"
    ],
    "stock": 29,
    "sku": "LM-BED-012",
    "specs": {
      "Material": "Velvet, cooling gel",
      "Care": "Cover machine washable at 30°",
      "Origin": "Made in Portugal",
      "Warranty": "3 years"
    }
  },
  {
    "id": "feather-wand",
    "slug": "feather-chase-cat-wand",
    "name": "Feather Chase Cat Wand",
    "cat": "Play",
    "price": 22,
    "was": null,
    "cats": [
      "cats",
      "toys",
      "play"
    ],
    "rating": 4.7,
    "reviews": 96,
    "badge": "New",
    "badgeClass": "badge--new",
    "img": "assets/img/p8.jpg",
    "gallery": [
      "assets/img/p8.jpg",
      "assets/img/life-cat-03.jpg",
      "assets/img/life-cat-04.jpg"
    ],
    "desc": "Natural feathers on a flexible birch wand with a bell and a refillable tip.",
    "long": "The wand is birch, steamed to bend and spring back. Feathers are attached to a clip so you can swap the tip when it wears out rather than replace the whole toy.",
    "swatches": [
      "#EFE8DC",
      "#8E4B4B",
      "#C39A5C"
    ],
    "sizes": [
      "One size"
    ],
    "stock": 62,
    "sku": "LM-TOY-013",
    "specs": {
      "Material": "Birch, natural feather",
      "Care": "Replace tip when worn",
      "Origin": "Made in Portugal",
      "Warranty": "1 year"
    }
  },
  {
    "id": "sisal-post",
    "slug": "sisal-scratching-post",
    "name": "Sisal Scratching Post",
    "cat": "Play",
    "price": 58,
    "was": null,
    "cats": [
      "cats",
      "toys",
      "play"
    ],
    "rating": 4.8,
    "reviews": 211,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/cat-scratch.jpg",
    "gallery": [
      "assets/img/cat-scratch.jpg",
      "assets/img/life-cat-05.jpg",
      "assets/img/life-cat-06.jpg"
    ],
    "desc": "Solid pine wrapped in natural sisal, tall enough for a full stretch.",
    "long": "Most posts are too short, so cats scratch the sofa instead. This one stands 90 cm tall on a weighted base, wrapped in sisal that frays rather than shreds.",
    "swatches": [
      "#C9B79C",
      "#7A4B2A"
    ],
    "sizes": [
      "90 cm",
      "120 cm"
    ],
    "stock": 21,
    "sku": "LM-TOY-014",
    "specs": {
      "Material": "Pine, natural sisal",
      "Care": "Vacuum the base",
      "Origin": "Made in Portugal",
      "Warranty": "3 years"
    }
  },
  {
    "id": "climbing-tree",
    "slug": "climbing-tree-tower",
    "name": "Climbing Tree Tower",
    "cat": "Play",
    "price": 246,
    "was": 289,
    "cats": [
      "cats",
      "toys",
      "play"
    ],
    "rating": 4.9,
    "reviews": 137,
    "badge": "Sale",
    "badgeClass": "badge--sale",
    "img": "assets/img/cat-tree.jpg",
    "gallery": [
      "assets/img/cat-tree.jpg",
      "assets/img/life-cat-07.jpg",
      "assets/img/life-cat-08.jpg"
    ],
    "desc": "Three tiers, two dens and a replaceable sisal column on a solid oak frame.",
    "long": "A piece of furniture rather than a toy. The oak frame is screwed together, not stapled, and every wear part — sisal, cushions — can be ordered separately.",
    "swatches": [
      "#EFE8DC",
      "#7E8B6E"
    ],
    "sizes": [
      "One size"
    ],
    "stock": 9,
    "sku": "LM-TOY-015",
    "specs": {
      "Material": "Oak, sisal, wool felt",
      "Care": "Vacuum cushions",
      "Origin": "Made in Portugal",
      "Warranty": "5 years"
    }
  },
  {
    "id": "catnip-mouse",
    "slug": "catnip-mouse-trio",
    "name": "Catnip Mouse Trio",
    "cat": "Play",
    "price": 16,
    "was": null,
    "cats": [
      "cats",
      "toys",
      "play"
    ],
    "rating": 4.5,
    "reviews": 168,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/cat-mouse.jpg",
    "gallery": [
      "assets/img/cat-mouse.jpg",
      "assets/img/life-cat-09.jpg",
      "assets/img/life-cat-10.jpg"
    ],
    "desc": "Wool-felt mice stuffed with organic catnip, sold as a set of three.",
    "long": "Hand-felted from wool with a genuine catnip filling — no polyester wadding and no glue, so a determined cat can safely pull them apart.",
    "swatches": [
      "#C9B79C",
      "#8E4B4B",
      "#7E8B6E"
    ],
    "sizes": [
      "Set of 3"
    ],
    "stock": 74,
    "sku": "LM-TOY-016",
    "specs": {
      "Material": "Wool felt, organic catnip",
      "Care": "Spot clean",
      "Origin": "Made in Nepal",
      "Warranty": "1 year"
    }
  },
  {
    "id": "window-perch",
    "slug": "window-perch",
    "name": "Window Perch",
    "cat": "Sleep",
    "price": 74,
    "was": null,
    "cats": [
      "cats",
      "sleep"
    ],
    "rating": 4.7,
    "reviews": 119,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/cat-perch.jpg",
    "gallery": [
      "assets/img/cat-perch.jpg",
      "assets/img/life-cat-11.jpg",
      "assets/img/life-cat-12.jpg"
    ],
    "desc": "Suction-mounted hammock that holds a sunbathing cat on any window.",
    "long": "Four industrial suction cups hold a canvas hammock that supports up to 15 kg. It pops off in seconds for cleaning or to take travelling.",
    "swatches": [
      "#EFE8DC",
      "#7E8B6E"
    ],
    "sizes": [
      "One size"
    ],
    "stock": 33,
    "sku": "LM-BED-017",
    "specs": {
      "Material": "Canvas, industrial suction",
      "Care": "Machine washable at 30°",
      "Origin": "Made in Portugal",
      "Warranty": "2 years"
    }
  },
  {
    "id": "litter-tray",
    "slug": "covered-litter-tray",
    "name": "Covered Litter Tray",
    "cat": "Essentials",
    "price": 96,
    "was": null,
    "cats": [
      "cats",
      "essentials"
    ],
    "rating": 4.6,
    "reviews": 144,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/cat-litter.jpg",
    "gallery": [
      "assets/img/cat-litter.jpg",
      "assets/img/life-cat-13.jpg",
      "assets/img/life-cat-14.jpg"
    ],
    "desc": "High-sided tray with a charcoal filter and a swivel lid for easy scooping.",
    "long": "High sides stop litter being kicked over the edge, and the lid swings right back so you can scoop without unclipping anything. A charcoal filter sits in the roof.",
    "swatches": [
      "#EFE8DC",
      "#6B6154"
    ],
    "sizes": [
      "One size"
    ],
    "stock": 27,
    "sku": "LM-ESS-018",
    "specs": {
      "Material": "Recycled polypropylene",
      "Care": "Rinse and air dry",
      "Origin": "Made in Portugal",
      "Warranty": "2 years"
    }
  },
  {
    "id": "cat-bowl",
    "slug": "wide-ceramic-cat-bowl",
    "name": "Wide Ceramic Cat Bowl",
    "cat": "Nutrition",
    "price": 34,
    "was": null,
    "cats": [
      "cats",
      "nutrition",
      "feed"
    ],
    "rating": 4.8,
    "reviews": 156,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/cat-bowl.jpg",
    "gallery": [
      "assets/img/cat-bowl.jpg",
      "assets/img/life-food-03.jpg",
      "assets/img/life-food-04.jpg"
    ],
    "desc": "Shallow, whisker-friendly stoneware that keeps food away from the sides.",
    "long": "Whisker fatigue is real: a narrow bowl makes cats flinch while eating. This one is wide and shallow so their whiskers never touch the rim.",
    "swatches": [
      "#F7F3EC",
      "#7E8B6E",
      "#C39A5C"
    ],
    "sizes": [
      "200 ml",
      "400 ml"
    ],
    "stock": 58,
    "sku": "LM-BWL-019",
    "specs": {
      "Material": "Glazed stoneware",
      "Care": "Dishwasher safe",
      "Origin": "Made in Portugal",
      "Warranty": "2 years"
    }
  },
  {
    "id": "guinea-hutch",
    "slug": "guinea-pig-hutch",
    "name": "Indoor Guinea Pig Hutch",
    "cat": "Habitat",
    "price": 168,
    "was": null,
    "cats": [
      "small-pets",
      "habitat"
    ],
    "rating": 4.7,
    "reviews": 88,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/small-cage.jpg",
    "gallery": [
      "assets/img/small-cage.jpg",
      "assets/img/life-small-01.jpg",
      "assets/img/life-small-02.jpg"
    ],
    "desc": "FSC-pine hutch with a hideaway loft and an easy-clean slide-out tray.",
    "long": "Built from FSC-certified pine with no staples on the inside and a slide-out tray that comes free in one motion. The loft gives guinea pigs somewhere to retreat to.",
    "swatches": [
      "#C9B79C",
      "#7A4B2A"
    ],
    "sizes": [
      "Small",
      "Large"
    ],
    "stock": 11,
    "sku": "LM-HAB-020",
    "specs": {
      "Material": "FSC pine, galvanised mesh",
      "Care": "Wipe tray weekly",
      "Origin": "Made in Portugal",
      "Warranty": "3 years"
    }
  },
  {
    "id": "timothy-hay",
    "slug": "timothy-hay",
    "name": "Organic Timothy Hay",
    "cat": "Nutrition",
    "price": 28,
    "was": null,
    "cats": [
      "small-pets",
      "nutrition",
      "feed"
    ],
    "rating": 4.9,
    "reviews": 232,
    "badge": "Bestseller",
    "badgeClass": "badge--best",
    "img": "assets/img/small-hay.jpg",
    "gallery": [
      "assets/img/small-hay.jpg",
      "assets/img/life-small-03.jpg",
      "assets/img/life-small-04.jpg"
    ],
    "desc": "Second-cut organic timothy, dust-extracted and packed in a resealable bag.",
    "long": "Second-cut hay is softer and leafier, which is what small pets actually eat. It is dust-extracted twice and sealed in a resealable bag so it stays sweet.",
    "swatches": [
      "#C9B79C"
    ],
    "sizes": [
      "1 kg",
      "2.5 kg",
      "5 kg"
    ],
    "stock": 94,
    "sku": "LM-NUT-021",
    "specs": {
      "Material": "Organic timothy hay",
      "Care": "Store dry and cool",
      "Origin": "Grown in the UK",
      "Warranty": "n/a"
    }
  },
  {
    "id": "wood-chew",
    "slug": "natural-wood-chew-blocks",
    "name": "Natural Wood Chew Blocks",
    "cat": "Play",
    "price": 14,
    "was": null,
    "cats": [
      "small-pets",
      "toys",
      "play"
    ],
    "rating": 4.6,
    "reviews": 176,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/small-chew.jpg",
    "gallery": [
      "assets/img/small-chew.jpg",
      "assets/img/life-small-05.jpg",
      "assets/img/life-small-06.jpg"
    ],
    "desc": "Untreated applewood offcuts that keep teeth worn down naturally.",
    "long": "Applewood from orchard pruning, kiln-dried and left completely untreated. Gnawing keeps rodent teeth — which never stop growing — properly worn.",
    "swatches": [
      "#C9B79C",
      "#7A4B2A"
    ],
    "sizes": [
      "200 g"
    ],
    "stock": 120,
    "sku": "LM-TOY-022",
    "specs": {
      "Material": "Untreated applewood",
      "Care": "Replace when chewed down",
      "Origin": "Made in Portugal",
      "Warranty": "n/a"
    }
  },
  {
    "id": "exercise-wheel",
    "slug": "quiet-exercise-wheel",
    "name": "Quiet Exercise Wheel",
    "cat": "Play",
    "price": 46,
    "was": null,
    "cats": [
      "small-pets",
      "toys",
      "play"
    ],
    "rating": 4.7,
    "reviews": 103,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/small-wheel.jpg",
    "gallery": [
      "assets/img/small-wheel.jpg",
      "assets/img/life-small-07.jpg",
      "assets/img/life-small-08.jpg"
    ],
    "desc": "Sealed ball bearings and a solid running surface with no rungs to catch.",
    "long": "Rungs are how hamsters break legs. This wheel has a continuous, solid track with a cork surface for grip, running on sealed bearings so it stays silent at night.",
    "swatches": [
      "#7E8B6E",
      "#C39A5C"
    ],
    "sizes": [
      "20 cm",
      "28 cm"
    ],
    "stock": 47,
    "sku": "LM-TOY-023",
    "specs": {
      "Material": "Cork, recycled plastic",
      "Care": "Wipe clean",
      "Origin": "Made in Germany",
      "Warranty": "2 years"
    }
  },
  {
    "id": "water-bottle",
    "slug": "no-drip-water-bottle",
    "name": "No-Drip Water Bottle",
    "cat": "Essentials",
    "price": 22,
    "was": null,
    "cats": [
      "small-pets",
      "essentials"
    ],
    "rating": 4.5,
    "reviews": 129,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/small-water.jpg",
    "gallery": [
      "assets/img/small-water.jpg",
      "assets/img/life-small-09.jpg",
      "assets/img/life-small-10.jpg"
    ],
    "desc": "Twin-ball nozzle that seals between sips, with a bracket for any cage.",
    "long": "A twin-ball valve means no slow drip to soak the bedding. The bottle clips to any cage with the included bracket and the whole thing is dishwasher safe.",
    "swatches": [
      "#EFE8DC",
      "#7E8B6E"
    ],
    "sizes": [
      "250 ml",
      "500 ml"
    ],
    "stock": 83,
    "sku": "LM-ESS-024",
    "specs": {
      "Material": "Borosilicate glass, steel",
      "Care": "Dishwasher safe",
      "Origin": "Made in Portugal",
      "Warranty": "2 years"
    }
  },
  {
    "id": "hideaway-hut",
    "slug": "hideaway-hut",
    "name": "Wooden Hideaway Hut",
    "cat": "Habitat",
    "price": 38,
    "was": null,
    "cats": [
      "small-pets",
      "habitat"
    ],
    "rating": 4.8,
    "reviews": 91,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/small-hut.jpg",
    "gallery": [
      "assets/img/small-hut.jpg",
      "assets/img/life-small-11.jpg",
      "assets/img/life-small-12.jpg"
    ],
    "desc": "Two-door pine hut so small pets always have an escape route.",
    "long": "Prey animals need two exits to feel safe. This hut has a door at each end, a hinged roof for cleaning, and it doubles as somewhere to climb on.",
    "swatches": [
      "#C9B79C"
    ],
    "sizes": [
      "Small",
      "Medium"
    ],
    "stock": 52,
    "sku": "LM-HAB-025",
    "specs": {
      "Material": "FSC pine",
      "Care": "Wipe clean",
      "Origin": "Made in Portugal",
      "Warranty": "2 years"
    }
  },
  {
    "id": "field-farm-recipe",
    "slug": "field-farm-dry-recipe",
    "name": "Field & Farm Dry Recipe",
    "cat": "Nutrition",
    "price": 48,
    "was": null,
    "cats": [
      "dogs",
      "nutrition",
      "feed"
    ],
    "rating": 4.9,
    "reviews": 528,
    "badge": "Bestseller",
    "badgeClass": "badge--best",
    "img": "assets/img/p7.jpg",
    "gallery": [
      "assets/img/p7.jpg",
      "assets/img/life-food-05.jpg",
      "assets/img/life-food-06.jpg"
    ],
    "desc": "Single-source protein, gently baked in small batches. Vet-formulated.",
    "long": "One protein, so it is gentle on sensitive stomachs. Baked at a low temperature rather than extruded at high heat, which keeps more of the nutrients intact.",
    "swatches": [
      "#C9B79C",
      "#7E8B6E"
    ],
    "sizes": [
      "2 kg",
      "6 kg",
      "12 kg"
    ],
    "stock": 66,
    "sku": "LM-NUT-026",
    "specs": {
      "Protein": "32%",
      "Fat": "16%",
      "Fibre": "3.5%",
      "Origin": "Made in the UK"
    }
  },
  {
    "id": "slow-cooked-wet",
    "slug": "slow-cooked-wet-food",
    "name": "Slow-Cooked Wet Food",
    "cat": "Nutrition",
    "price": 36,
    "was": null,
    "cats": [
      "dogs",
      "cats",
      "nutrition",
      "feed"
    ],
    "rating": 4.8,
    "reviews": 341,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/food-wet.jpg",
    "gallery": [
      "assets/img/food-wet.jpg",
      "assets/img/life-food-07.jpg",
      "assets/img/life-food-08.jpg"
    ],
    "desc": "Gently steamed in the tin so no nutrients are lost to the cooking water.",
    "long": "Steamed in its own tin, which means nothing leaches out during cooking. High water content too, so it helps pets that do not drink enough.",
    "swatches": [
      "#C9B79C"
    ],
    "sizes": [
      "6 × 400 g",
      "12 × 400 g"
    ],
    "stock": 88,
    "sku": "LM-NUT-027",
    "specs": {
      "Protein": "11%",
      "Moisture": "78%",
      "Grain free": "Yes",
      "Origin": "Made in the UK"
    }
  },
  {
    "id": "puppy-formula",
    "slug": "puppy-growth-formula",
    "name": "Puppy Growth Formula",
    "cat": "Nutrition",
    "price": 52,
    "was": null,
    "cats": [
      "dogs",
      "nutrition",
      "feed"
    ],
    "rating": 4.9,
    "reviews": 264,
    "badge": "New",
    "badgeClass": "badge--new",
    "img": "assets/img/food-puppy.jpg",
    "gallery": [
      "assets/img/food-puppy.jpg",
      "assets/img/life-food-09.jpg",
      "assets/img/life-food-10.jpg"
    ],
    "desc": "Small kibble with DHA and a calcium-to-phosphorus ratio set for growing joints.",
    "long": "Puppies need a precise calcium-to-phosphorus ratio or their joints develop badly. This recipe holds the ratio steady and adds DHA for early brain development.",
    "swatches": [
      "#C9B79C"
    ],
    "sizes": [
      "2 kg",
      "6 kg"
    ],
    "stock": 39,
    "sku": "LM-NUT-028",
    "specs": {
      "Protein": "30%",
      "DHA": "0.2%",
      "Ca:P": "1.3:1",
      "Origin": "Made in the UK"
    }
  },
  {
    "id": "kitten-formula",
    "slug": "kitten-formula",
    "name": "Kitten Formula",
    "cat": "Nutrition",
    "price": 44,
    "was": null,
    "cats": [
      "cats",
      "nutrition",
      "feed"
    ],
    "rating": 4.8,
    "reviews": 197,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/food-kitten.jpg",
    "gallery": [
      "assets/img/food-kitten.jpg",
      "assets/img/life-food-11.jpg",
      "assets/img/life-food-12.jpg"
    ],
    "desc": "Tiny, dense kibble with taurine for eyesight and heart development.",
    "long": "Cats cannot make taurine, and kittens need a lot of it. This recipe is fortified well above the minimum and the kibble is small enough for milk teeth.",
    "swatches": [
      "#C9B79C"
    ],
    "sizes": [
      "1.5 kg",
      "4 kg"
    ],
    "stock": 44,
    "sku": "LM-NUT-029",
    "specs": {
      "Protein": "36%",
      "Taurine": "0.25%",
      "Grain free": "Yes",
      "Origin": "Made in the UK"
    }
  },
  {
    "id": "raw-medallions",
    "slug": "freeze-dried-raw-medallions",
    "name": "Freeze-Dried Raw Medallions",
    "cat": "Nutrition",
    "price": 64,
    "was": 76,
    "cats": [
      "dogs",
      "cats",
      "nutrition",
      "feed"
    ],
    "rating": 4.7,
    "reviews": 152,
    "badge": "Sale",
    "badgeClass": "badge--sale",
    "img": "assets/img/food-raw.jpg",
    "gallery": [
      "assets/img/food-raw.jpg",
      "assets/img/life-food-13.jpg",
      "assets/img/life-food-14.jpg"
    ],
    "desc": "Raw meat freeze-dried into medallions — rehydrate with warm water to serve.",
    "long": "All the benefits of a raw diet without the freezer space or the mess. Freeze-drying removes water at low temperature, so the nutrients survive intact.",
    "swatches": [
      "#8E4B4B"
    ],
    "sizes": [
      "400 g",
      "900 g"
    ],
    "stock": 31,
    "sku": "LM-NUT-030",
    "specs": {
      "Protein": "48%",
      "Fat": "28%",
      "Moisture": "4%",
      "Origin": "Made in the UK"
    }
  },
  {
    "id": "dental-chews",
    "slug": "dental-chews",
    "name": "Daily Dental Chews",
    "cat": "Nutrition",
    "price": 19,
    "was": null,
    "cats": [
      "dogs",
      "nutrition",
      "feed"
    ],
    "rating": 4.6,
    "reviews": 388,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/food-dental.jpg",
    "gallery": [
      "assets/img/food-dental.jpg",
      "assets/img/life-food-15.jpg",
      "assets/img/life-food-16.jpg"
    ],
    "desc": "Ridged texture that scrubs the gum line, with mint and no added sugar.",
    "long": "The ridges are shaped to reach between teeth, which is where plaque actually forms. Mint freshens the breath and there is no sugar or artificial colour.",
    "swatches": [
      "#C9B79C"
    ],
    "sizes": [
      "7 chews",
      "28 chews"
    ],
    "stock": 105,
    "sku": "LM-NUT-031",
    "specs": {
      "Calories": "78 kcal each",
      "Sugar": "None added",
      "Origin": "Made in the UK",
      "Warranty": "n/a"
    }
  },
  {
    "id": "salmon-oil",
    "slug": "wild-salmon-oil",
    "name": "Wild Salmon Oil",
    "cat": "Nutrition",
    "price": 29,
    "was": null,
    "cats": [
      "dogs",
      "cats",
      "nutrition",
      "feed"
    ],
    "rating": 4.8,
    "reviews": 214,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/food-oil.jpg",
    "gallery": [
      "assets/img/food-oil.jpg",
      "assets/img/life-food-17.jpg",
      "assets/img/life-food-18.jpg"
    ],
    "desc": "Cold-pressed omega-3 for coat condition, joints and healthy skin.",
    "long": "Cold-pressed from wild-caught salmon so the omega-3 stays intact. A pump action makes it easy to measure over food, and it is naturally rich in vitamin D.",
    "swatches": [
      "#C39A5C"
    ],
    "sizes": [
      "250 ml",
      "500 ml"
    ],
    "stock": 57,
    "sku": "LM-NUT-032",
    "specs": {
      "Omega-3": "1,800 mg/10 ml",
      "Vitamin D": "Natural",
      "Origin": "Made in Norway",
      "Warranty": "n/a"
    }
  },
  {
    "id": "bone-broth",
    "slug": "bone-broth-treat",
    "name": "Slow Bone Broth",
    "cat": "Nutrition",
    "price": 21,
    "was": null,
    "cats": [
      "dogs",
      "cats",
      "nutrition",
      "feed"
    ],
    "rating": 4.7,
    "reviews": 166,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/bone-broth.jpg",
    "gallery": [
      "assets/img/bone-broth.jpg",
      "assets/img/life-food-19.jpg",
      "assets/img/life-food-20.jpg"
    ],
    "desc": "Simmered for 18 hours, then reduced into a pour-over topper for dry food.",
    "long": "Eighteen hours of slow simmering draws collagen and minerals out of the bones. Pour it over dry food to tempt fussy eaters or to get more water into them.",
    "swatches": [
      "#C9B79C"
    ],
    "sizes": [
      "350 ml",
      "1 L"
    ],
    "stock": 68,
    "sku": "LM-NUT-033",
    "specs": {
      "Collagen": "High",
      "Additives": "None",
      "Origin": "Made in the UK",
      "Warranty": "n/a"
    }
  },
  {
    "id": "training-treats",
    "slug": "training-treats",
    "name": "Soft Training Treats",
    "cat": "Nutrition",
    "price": 12,
    "was": null,
    "cats": [
      "dogs",
      "nutrition",
      "treats"
    ],
    "rating": 4.5,
    "reviews": 297,
    "badge": null,
    "badgeClass": "",
    "img": "assets/img/training-treats.jpg",
    "gallery": [
      "assets/img/training-treats.jpg",
      "assets/img/life-food-21.jpg",
      "assets/img/life-food-22.jpg"
    ],
    "desc": "Pea-sized and soft enough to break in half — for rewarding, not filling.",
    "long": "Small enough to hand out a dozen in a session without spoiling dinner, and soft enough to break in two. Single-ingredient liver, nothing else.",
    "swatches": [
      "#8E4B4B"
    ],
    "sizes": [
      "100 g",
      "250 g"
    ],
    "stock": 132,
    "sku": "LM-NUT-034",
    "specs": {
      "Protein": "60%",
      "Ingredients": "Liver only",
      "Origin": "Made in the UK",
      "Warranty": "n/a"
    }
  }
];
  const REVIEWS = [
  {
    "name": "Marta H.",
    "pet": "Border Collie, 6",
    "rating": 5,
    "title": "He actually sleeps through the night",
    "body": "We tried four beds before this one. Our collie has hip trouble and the memory foam clearly helps — he settles immediately and no longer paces at 3am.",
    "date": "2026-09-14",
    "verified": true
  },
  {
    "name": "Daniel O.",
    "pet": "British Shorthair, 3",
    "rating": 5,
    "title": "Beautifully made",
    "body": "The stitching and the leather quality are genuinely better than anything I have seen in a pet shop. Two years in and it has darkened into a lovely colour.",
    "date": "2026-08-30",
    "verified": true
  },
  {
    "name": "Priya S.",
    "pet": "Two rescue cats",
    "rating": 4,
    "title": "Great, though my cats took a week",
    "body": "Took a few days for them to trust it but now they fight over it. Only reason for four stars is that I wish the cover came in more colours.",
    "date": "2026-08-22",
    "verified": true
  },
  {
    "name": "Tom W.",
    "pet": "Labrador, 2",
    "rating": 5,
    "title": "Survived a labrador puppy",
    "body": "Nothing survives this dog. This set has been chewed, dragged through mud and washed repeatedly and it still looks new. Remarkable.",
    "date": "2026-08-05",
    "verified": true
  },
  {
    "name": "Aisha K.",
    "pet": "Rabbit, 4",
    "rating": 5,
    "title": "Finally hay he eats",
    "body": "My rabbit is extremely fussy and turns his nose up at supermarket hay. He ate this straight away. Smells fresh and sweet, not dusty.",
    "date": "2026-07-28",
    "verified": true
  },
  {
    "name": "Henrik L.",
    "pet": "Dachshund, 8",
    "rating": 5,
    "title": "Kind to an older dog",
    "body": "Our dachshund is eight and getting stiff. The low step-over on this bed means he can get in without help, which matters more than I expected.",
    "date": "2026-07-19",
    "verified": true
  },
  {
    "name": "Clara M.",
    "pet": "Maine Coon, 5",
    "rating": 4,
    "title": "Large enough at last",
    "body": "Most cat furniture is far too small for a Maine Coon. This tower is genuinely sturdy and he fits on every level. Assembly took a while.",
    "date": "2026-07-02",
    "verified": true
  },
  {
    "name": "Yusuf A.",
    "pet": "Whippet, 4",
    "rating": 5,
    "title": "The coat is a lifesaver",
    "body": "Whippets have almost no fat and feel the cold badly. He now asks to have this put on before walks. The harness slot is a thoughtful detail.",
    "date": "2026-06-21",
    "verified": true
  }
];
  const PAYMENTS = [
  {
    "id": "card",
    "label": "Credit or debit card",
    "note": "Visa, Mastercard, Amex"
  },
  {
    "id": "paypal",
    "label": "PayPal",
    "note": "Pay in a few taps"
  },
  {
    "id": "apple",
    "label": "Apple Pay",
    "note": "Fastest at checkout"
  },
  {
    "id": "klarna",
    "label": "Klarna",
    "note": "3 interest-free payments"
  },
  {
    "id": "bank",
    "label": "Bank transfer",
    "note": "For orders over $500"
  }
];
  const SHIPPING = [
  {
    "id": "standard",
    "label": "Standard",
    "eta": "3–5 working days",
    "price": 0,
    "note": "Free over $75"
  },
  {
    "id": "express",
    "label": "Express",
    "eta": "1–2 working days",
    "price": 12,
    "note": "Tracked"
  },
  {
    "id": "next",
    "label": "Next day",
    "eta": "Tomorrow before 1pm",
    "price": 22,
    "note": "Order by 4pm"
  }
];;

  window.LUME = {
    CATEGORIES, NAV, PRODUCTS, REVIEWS, PAYMENTS, SHIPPING,
    byId: (id) => PRODUCTS.find((p) => p.id === id),
    byCat: (c) => PRODUCTS.filter((p) => p.cats.includes(c)),
    bySlug: (s) => PRODUCTS.find((p) => p.slug === s),
  };
})();
