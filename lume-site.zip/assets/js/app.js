/* =========================================================
   LUMÉ — Pet Atelier · storefront behaviour
   Reads the shared catalogue from window.LUME (assets/js/catalogue.js)
   and drives every page: shop, product, reviews, bag, checkout.
   ========================================================= */
(() => {
  "use strict";

  const LUME = window.LUME;
  if (!LUME) return;
  const PRODUCTS = LUME.PRODUCTS;
  const REVIEWS = LUME.REVIEWS;

  /* ---------- Helpers ---------- */
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const money = (n) => "$" + n.toFixed(2);
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const find = (id) => PRODUCTS.find((p) => p.id === id);
  const star = '<svg class="icon icon--xs"><use href="#i-star"/></svg>';

  /* ---------- Image fallback ---------- */
  const wireFallback = (scope = document) => {
    $$("img[data-fallback]", scope).forEach((img) => {
      if (img.dataset.wired) return;
      img.dataset.wired = "1";
      const fail = () => {
        img.style.display = "none";
        const host = img.parentElement;
        if (host) host.style.background =
          "linear-gradient(135deg,#EFE8DC 0%,#E4DAC9 50%,#C9B79C 100%)";
      };
      if (img.complete && img.naturalWidth === 0) fail();
      img.addEventListener("error", fail);
    });
  };

  /* =========================================================
     CART
     ========================================================= */
  const FREE_SHIP = 75;
  let cart = [];
  try { cart = JSON.parse(localStorage.getItem("lume.cart") || "[]"); } catch { cart = []; }

  const saveCart = () => {
    try { localStorage.setItem("lume.cart", JSON.stringify(cart)); } catch {}
  };
  const cartCount = () => cart.reduce((n, i) => n + i.qty, 0);
  const cartTotal = () => cart.reduce((n, i) => n + i.qty * i.price, 0);

  const addToCart = (id, { size = null, swatch = null, qty = 1, open = true } = {}) => {
    const p = find(id);
    if (!p) return;
    size = size || p.sizes[0];
    const key = id + "|" + size + "|" + (swatch || "");
    const existing = cart.find((i) => i.key === key);
    if (existing) existing.qty += qty;
    else cart.push({ key, id, name: p.name, price: p.price, img: p.img, size, swatch, qty });
    saveCart();
    renderCart();
    renderCartPage();
    renderSummary();
    bumpBadge();
    toast(`${p.name} added to bag`);
    if (open) openCart();
  };

  const setQty = (key, delta) => {
    const it = cart.find((i) => i.key === key);
    if (!it) return;
    it.qty += delta;
    if (it.qty <= 0) cart = cart.filter((i) => i.key !== key);
    saveCart();
    renderCart();
    renderCartPage();
    renderSummary();
  };

  const removeItem = (key) => {
    cart = cart.filter((i) => i.key !== key);
    saveCart();
    renderCart();
    renderCartPage();
    renderSummary();
    toast("Removed from bag");
  };

  const bumpBadge = () => {
    const b = $("#cartCount");
    if (!b) return;
    b.classList.remove("bump");
    void b.offsetWidth;
    b.classList.add("bump");
  };

  const renderCart = () => {
    const n = cartCount(), total = cartTotal();
    const c1 = $("#cartCount"), c2 = $("#cartCount2");
    if (c1) { c1.textContent = n; c1.classList.toggle("is-on", n > 0); }
    if (c2) c2.textContent = n;
    const openBtn = $("#openCart");
    if (openBtn) openBtn.setAttribute("aria-label", `Open bag, ${n} item${n === 1 ? "" : "s"}`);

    const shipText = $("#shipText");
    if (shipText) {
      const remain = Math.max(0, FREE_SHIP - total);
      shipText.innerHTML = remain > 0
        ? `Add <b>${money(remain)}</b> more for free delivery`
        : `You've unlocked <b>free carbon-neutral delivery</b>`;
      $("#shipFill").style.width = Math.min(100, (total / FREE_SHIP) * 100) + "%";
    }

    const body = $("#cartBody");
    if (!body) return;
    const empty = $("#cartEmpty"), foot = $("#cartFoot");
    $$(".line", body).forEach((el) => el.remove());
    if (!cart.length) {
      if (empty) empty.hidden = false;
      if (foot) foot.hidden = true;
      return;
    }
    if (empty) empty.hidden = true;
    if (foot) foot.hidden = false;
    cart.forEach((it) => {
      const el = document.createElement("div");
      el.className = "line";
      el.innerHTML = `
        <div class="line__img"><img src="${it.img}" alt="${esc(it.name)}" data-fallback></div>
        <div class="line__body">
          <div class="line__name">${esc(it.name)}</div>
          <div class="line__meta">${esc(it.size)}${it.swatch ? " · " + esc(it.swatch) : ""}</div>
          <div class="line__row">
            <div class="qty">
              <button data-dec="${esc(it.key)}" aria-label="Decrease quantity"><svg class="icon icon--xs"><use href="#i-minus"/></svg></button>
              <span>${it.qty}</span>
              <button data-inc="${esc(it.key)}" aria-label="Increase quantity"><svg class="icon icon--xs"><use href="#i-plus"/></svg></button>
            </div>
            <div class="line__price">${money(it.price * it.qty)}</div>
          </div>
          <button class="line__rm" data-rm="${esc(it.key)}">Remove</button>
        </div>`;
      body.appendChild(el);
    });
    const sub = $("#cartSubtotal");
    if (sub) sub.textContent = money(total);
    wireFallback(body);
  };

  /* =========================================================
     CART PAGE (cart.html)
     ========================================================= */
  const renderCartPage = () => {
    const host = $("#cartPageItems");
    if (!host) return;
    if (!cart.length) {
      host.innerHTML = `
        <div class="cart-empty cart-empty--page">
          <svg class="icon icon--lg"><use href="#i-cart"/></svg>
          <p>Your bag is empty.</p>
          <a class="btn btn--outline" href="index.html#bestsellers">Start shopping</a>
        </div>`;
      const s = $("#cartPageSubtotal"); if (s) s.textContent = money(0);
      return;
    }
    host.innerHTML = cart.map((it) => {
      const p = find(it.id) || {};
      const url = `product-${p.slug}.html`;
      return `
      <div class="cartline">
        <a class="cartline__img" href="${url}"><img src="${it.img}" alt="${esc(it.name)}" data-fallback></a>
        <div class="cartline__body">
          <a class="cartline__name" href="${url}">${esc(it.name)}</a>
          <p class="cartline__meta">${esc(it.size)}${it.swatch ? " · " + esc(it.swatch) : ""}</p>
          <div class="cartline__row">
            <div class="qty">
              <button data-dec="${esc(it.key)}" aria-label="Decrease quantity">−</button>
              <span>${it.qty}</span>
              <button data-inc="${esc(it.key)}" aria-label="Increase quantity">+</button>
            </div>
            <b class="cartline__price">${money(it.price * it.qty)}</b>
            <button class="line__rm" data-rm="${esc(it.key)}">Remove</button>
          </div>
        </div>
      </div>`;
    }).join("");
    const s = $("#cartPageSubtotal");
    if (s) s.textContent = money(cartTotal());
    wireFallback(host);
  };

  /* =========================================================
     PRODUCT GRID
     ========================================================= */
  const cardHTML = (p) => {
    const badges = [];
    if (p.badge) badges.push(`<span class="badge ${p.badgeClass}">${p.badge}</span>`);
    if (p.was) badges.push(`<span class="badge badge--sale">−${Math.round((1 - p.price / p.was) * 100)}%</span>`);
    const sw = p.swatches.map((c) => `<span class="sw" style="background:${c}"></span>`).join("");
    const url = `product-${p.slug}.html`;
    return `
      <article class="card" data-cats="${p.cats.join(" ")}">
        <div class="card__media">
          <div class="card__badges">${badges.join("")}</div>
          <button class="card__wish" aria-label="Save ${esc(p.name)}" aria-pressed="false" data-wish="${p.id}"><svg class="icon icon--sm"><use href="#i-heart"/></svg></button>
          <a class="card__img-link" href="${url}" tabindex="-1" aria-hidden="true"><img src="${p.img}" alt="${esc(p.name)}" loading="lazy" data-fallback></a>
          <button class="card__quick" data-quickview="${p.id}">Quick view</button>
        </div>
        <div class="card__body">
          <a class="card__body-link" href="${url}">
            <span class="card__cat">${esc(p.cat)}</span>
            <h3 class="card__name">${esc(p.name)}</h3>
            <p class="card__desc">${esc(p.desc)}</p>
          </a>
          <div class="card__swatches">${sw}</div>
          <div class="card__row">
            <div class="card__price">${money(p.price)}${p.was ? `<s>${money(p.was)}</s>` : ""}</div>
            <div class="card__rate">${star}${p.rating} (${p.reviews})</div>
          </div>
          <button class="btn btn--primary btn--sm card__add" data-add="${p.id}"><svg class="icon icon--xs"><use href="#i-plus"/></svg><span>Add to bag</span></button>
        </div>
      </article>`;
  };

  const renderProducts = () => {
    const grid = $("#products");
    // Pages ship with cards already rendered; only fill a genuinely empty grid.
    if (!grid || $(".card", grid)) return;
    const cat = grid.dataset.cat;
    const items = cat ? PRODUCTS.filter((p) => p.cats.includes(cat)) : PRODUCTS;
    grid.innerHTML = items.map(cardHTML).join("");
    wireFallback(grid);
  };

  const applyFilter = (f) => {
    const grid = $("#products");
    if (!grid) return;
    let shown = 0;
    $$(".card", grid).forEach((c) => {
      const match = f === "all" || c.dataset.cats.split(" ").includes(f);
      c.classList.toggle("is-hidden", !match);
      if (match) shown++;
    });
    const count = $("#listingCount");
    if (count) count.textContent = `${shown} piece${shown === 1 ? "" : "s"}`;
  };

  const applySort = (mode) => {
    const grid = $("#products");
    if (!grid) return;
    const cards = $$(".card", grid);
    const val = (c) => find(c.querySelector("[data-add]").dataset.add) || {};
    const cmp = {
      "price-asc": (a, b) => val(a).price - val(b).price,
      "price-desc": (a, b) => val(b).price - val(a).price,
      "rating": (a, b) => val(b).rating - val(a).rating,
    }[mode];
    if (!cmp) return;
    cards.sort(cmp).forEach((c) => grid.appendChild(c));
  };

  const filterReviews = (f) => {
    $$(".review").forEach((r) => {
      const show = f === "all" || (r.dataset.cats || "").split(" ").includes(f);
      r.classList.toggle("is-hidden", !show);
    });
  };

  /* =========================================================
     QUICK VIEW
     ========================================================= */
  const openQuickView = (id) => {
    const p = find(id);
    if (!p) return;
    rememberFocus();
    const sizes = p.sizes.map((s, i) =>
      `<button class="size${i === 0 ? " is-active" : ""}" data-size="${esc(s)}">${esc(s)}</button>`).join("");
    const sw = p.swatches.map((c, i) =>
      `<button type="button" class="sw${i === 0 ? " is-active" : ""}" data-swatch="${c}" style="background:${c}" aria-label="Colour ${i + 1}" aria-pressed="${i === 0}"></button>`).join("");
    $("#quickviewPanel").innerHTML = `
      <div class="qv">
        <div class="qv__media"><img src="${p.img}" alt="${esc(p.name)}" data-fallback></div>
        <div class="qv__body">
          <button class="icon-btn qv__close" id="qvClose" aria-label="Close"><svg class="icon"><use href="#i-close"/></svg></button>
          <span class="qv__cat">${esc(p.cat)}</span>
          <h3 class="qv__name">${esc(p.name)}</h3>
          <div class="stars">${star.repeat(5)}<span class="qv__rate">${p.rating} · ${p.reviews} reviews</span></div>
          <div class="qv__price">${money(p.price)}${p.was ? `<s>${money(p.was)}</s>` : ""}</div>
          <p class="qv__desc">${esc(p.desc)}</p>
          <div class="qv__opt"><h5>Colour</h5><div class="card__swatches">${sw}</div></div>
          <div class="qv__opt"><h5>Size</h5><div class="qv__sizes">${sizes}</div></div>
          <div class="qv__actions">
            <button class="btn btn--primary" id="qvAdd"><span>Add to bag</span><svg class="icon icon--sm"><use href="#i-arrow-r"/></svg></button>
            <a class="btn btn--outline" href="product-${p.slug}.html">Full details</a>
          </div>
          <ul class="qv__list">
            <li><svg class="icon icon--xs"><use href="#i-truck"/></svg> Free carbon-neutral delivery over $75</li>
            <li><svg class="icon icon--xs"><use href="#i-shield"/></svg> 60-night comfort promise</li>
            <li><svg class="icon icon--xs"><use href="#i-check"/></svg> Complimentary gift wrapping</li>
          </ul>
        </div>
      </div>`;
    const modal = $("#quickview");
    modal.classList.add("is-open");
    setHidden(modal, false);
    document.body.classList.add("is-locked");
    wireFallback(modal);

    let size = p.sizes[0], swatch = p.swatches[0];
    $("#qvClose").onclick = closeQuickView;
    $$(".size", modal).forEach((b) => b.onclick = () => {
      $$(".size", modal).forEach((x) => x.classList.remove("is-active"));
      b.classList.add("is-active"); size = b.dataset.size;
    });
    $$(".sw[data-swatch]", modal).forEach((b) => b.onclick = () => {
      $$(".sw[data-swatch]", modal).forEach((x) => {
        x.classList.remove("is-active"); x.setAttribute("aria-pressed", "false");
      });
      b.classList.add("is-active"); b.setAttribute("aria-pressed", "true"); swatch = b.dataset.swatch;
    });
    $("#qvAdd").onclick = () => { addToCart(p.id, { size, swatch }); closeQuickView(); };
  };
  const closeQuickView = () => {
    const modal = $("#quickview");
    if (!modal || !modal.classList.contains("is-open")) return;
    modal.classList.remove("is-open");
    setHidden(modal, true);
    document.body.classList.remove("is-locked");
    restoreFocus();
  };

  /* =========================================================
     WELCOME OFFER POPUP
     ========================================================= */
  const OFFER_KEY = "lume.offer.seen";
  let offerTimer, offerIdle;

  const closeOffer = () => {
    clearTimeout(offerTimer); clearTimeout(offerIdle);
    const el = $("#offer");
    if (!el || !el.classList.contains("is-open")) return;
    el.classList.remove("is-open");
    setHidden(el, true);
    if (scrim) scrim.classList.remove("is-on");
    lockScroll(false);
    try { localStorage.setItem(OFFER_KEY, "1"); } catch {}
    restoreFocus();
  };

  const openOffer = () => {
    const el = $("#offer");
    if (!el || el.classList.contains("is-open")) return;
    rememberFocus();
    el.classList.add("is-open");
    setHidden(el, false);
    if (scrim) scrim.classList.add("is-on");
    lockScroll(true);
    setTimeout(() => { const i = $("#offerEmail"); if (i) i.focus(); }, 360);
  };

  const initOffer = () => {
    const el = $("#offer");
    if (!el) return;
    let seen = "1";
    try { seen = localStorage.getItem(OFFER_KEY); } catch {}
    if (seen) return;

    // Never interrupt a visitor who is already checking out, reviewing their bag
    // or signing in.
    const here = location.pathname.split("/").pop() || "index.html";
    if (/^(checkout|cart|account)\.html$/.test(here)) return;

    // Let the visitor land first, and never interrupt active scrolling.
    const arm = () => {
      offerTimer = setTimeout(() => {
        if (document.body.classList.contains("is-locked")) return;
        openOffer();
      }, 5200);
    };
    arm();
    window.addEventListener("scroll", () => {
      clearTimeout(offerTimer); clearTimeout(offerIdle);
      offerIdle = setTimeout(arm, 900);
    }, { passive: true });

    const c = $("#closeOffer"); if (c) c.onclick = closeOffer;
    const skip = $("#offerSkip"); if (skip) skip.onclick = closeOffer;
    el.addEventListener("click", (e) => { if (e.target === el) closeOffer(); });

    const form = $("#offerForm");
    if (form) form.addEventListener("submit", (e) => {
      e.preventDefault();
      const email = $("#offerEmail").value.trim();
      const note = $("#offerNote");
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        note.textContent = "Please enter a valid email address.";
        note.style.color = "var(--berry)";
        return;
      }
      note.innerHTML = 'You’re in — your code is <b class="offer__code">LUME10</b>';
      note.style.color = "var(--brass-d)";
      toast("Code LUME10 applied");
      form.reset();
      setTimeout(closeOffer, 1700);
    });
  };

  /* =========================================================
     PRODUCT DETAIL PAGE
     ========================================================= */
  const initPDP = () => {
    const root = $(".pdp");
    if (!root) return;
    const p = find(root.dataset.product);
    if (!p) return;

    $$(".pdp__thumb").forEach((t) => t.addEventListener("click", () => {
      $$(".pdp__thumb").forEach((x) => x.classList.remove("is-active"));
      t.classList.add("is-active");
      $("#pdpImage").src = t.dataset.gallery;
    }));

    let size = p.sizes[0], swatch = p.swatches[0];
    $$(".pdp__sizes .size").forEach((b) => b.addEventListener("click", () => {
      $$(".pdp__sizes .size").forEach((x) => x.classList.remove("is-active"));
      b.classList.add("is-active"); size = b.dataset.size;
    }));
    $$(".pdp__swatches .sw").forEach((b) => b.addEventListener("click", () => {
      $$(".pdp__swatches .sw").forEach((x) => x.classList.remove("is-active"));
      b.classList.add("is-active"); swatch = b.dataset.swatch;
    }));

    const qty = $("#pdpQty");
    const clamp = () => {
      let v = parseInt(qty.value, 10);
      if (isNaN(v) || v < 1) v = 1;
      if (v > 20) v = 20;
      qty.value = v;
      return v;
    };
    $$("[data-qty-inc]").forEach((b) => b.addEventListener("click", () => { qty.value = clamp() + 1; clamp(); }));
    $$("[data-qty-dec]").forEach((b) => b.addEventListener("click", () => { qty.value = clamp() - 1; clamp(); }));
    qty.addEventListener("blur", clamp);

    const addBtn = $(".pdp__add");
    if (addBtn) addBtn.addEventListener("click", () => addToCart(p.id, { size, swatch, qty: clamp() }));

    const tabs = $$(".tab", root);
    tabs.forEach((tab) => {
      tab.addEventListener("click", () => {
        tabs.forEach((t) => { t.classList.remove("is-active"); t.setAttribute("aria-selected", "false"); });
        tab.classList.add("is-active");
        tab.setAttribute("aria-selected", "true");
        $$(".tabpanel", root).forEach((pnl) =>
          pnl.classList.toggle("is-active", pnl.id === tab.getAttribute("aria-controls")));
      });
      tab.addEventListener("keydown", (e) => {
        const i = tabs.indexOf(tab);
        if (e.key === "ArrowRight") { e.preventDefault(); tabs[(i + 1) % tabs.length].focus(); }
        if (e.key === "ArrowLeft") { e.preventDefault(); tabs[(i - 1 + tabs.length) % tabs.length].focus(); }
      });
    });
  };

  /* =========================================================
     CHECKOUT
     ========================================================= */
  let promoOff = 0;
  const shipPrice = () => {
    const sel = $('input[name="ship"]:checked');
    const s = LUME.SHIPPING.find((x) => x.id === (sel ? sel.value : "standard"));
    return s ? s.price : 0;
  };

  const renderSummary = () => {
    const host = $("#summaryItems");
    if (!host) return;
    if (!cart.length) {
      host.innerHTML = `<p class="summary__empty">Your bag is empty. <a href="index.html#bestsellers">Add something lovely.</a></p>`;
    } else {
      host.innerHTML = cart.map((it) => `
        <div class="sumline">
          <div class="sumline__img"><img src="${it.img}" alt="${esc(it.name)}" data-fallback><span class="sumline__qty">${it.qty}</span></div>
          <div class="sumline__body"><b>${esc(it.name)}</b><span>${esc(it.size)}</span></div>
          <span class="sumline__price">${money(it.price * it.qty)}</span>
        </div>`).join("");
      wireFallback(host);
    }
    const subtotal = cartTotal();
    const discount = subtotal * promoOff;
    const taxable = subtotal - discount;
    const tax = taxable * 0.25;
    const ship = shipPrice();
    const total = taxable + tax + (subtotal >= FREE_SHIP || !subtotal ? 0 : ship);
    const set = (id, v) => { const el = $(id); if (el) el.textContent = v; };
    set("#sumSubtotal", money(subtotal));
    set("#sumShip", subtotal >= FREE_SHIP || !subtotal ? "Free" : money(ship));
    set("#sumTax", money(tax));
    set("#sumTotal", money(total));
    if (promoOff) {
      const badge = $("#promoMsg");
      if (badge) badge.textContent = `Code applied — ${Math.round(promoOff * 100)}% off.`;
    }
  };

  const initCheckout = () => {
    const form = $("#checkoutForm");
    if (!form) return;
    renderSummary();

    $$('input[name="ship"], input[name="pay"]').forEach((r) =>
      r.addEventListener("change", () => {
        renderSummary();
        const card = $("#cardFields");
        if (card) {
          const pay = ($('input[name="pay"]:checked') || {}).value;
          card.hidden = pay !== "card";
        }
      }));

    const promo = $("#promoApply");
    if (promo) promo.addEventListener("click", () => {
      const code = ($("#promo").value || "").trim().toUpperCase();
      const msg = $("#promoMsg");
      if (code === "LUME10") { promoOff = 0.10; msg.textContent = "Code applied — 10% off."; }
      else if (code === "WINTER15") { promoOff = 0.15; msg.textContent = "Code applied — 15% off."; }
      else { promoOff = 0; msg.textContent = "That code is not recognised."; }
      renderSummary();
    });

    const rules = {
      email: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) || "Enter a valid email address.",
      first: (v) => v.trim() ? true : "Required.",
      last: (v) => v.trim() ? true : "Required.",
      addr: (v) => v.trim().length >= 4 ? true : "Enter your street address.",
      city: (v) => v.trim() ? true : "Required.",
      zip: (v) => /^[A-Za-z0-9 -]{3,10}$/.test(v.trim()) || "Enter a valid postcode.",
      cardnum: (v) => /^(\d[ ]?){13,19}$/.test(v.trim()) || "Enter a valid card number.",
      cardexp: (v) => /^(0[1-9]|1[0-2])\/?\d{2}$/.test(v.trim()) || "Use MM/YY.",
      cardcvc: (v) => /^\d{3,4}$/.test(v.trim()) || "3 or 4 digits.",
    };

    const showErr = (name, msg) => {
      const box = $(`[data-err="${name}"]`);
      const input = $(`#${name}`);
      if (box) box.textContent = msg === true ? "" : msg;
      if (input) input.setAttribute("aria-invalid", msg === true ? "false" : "true");
    };

    const validate = () => {
      let ok = true, firstBad = null;
      const pay = ($('input[name="pay"]:checked') || {}).value;
      Object.entries(rules).forEach(([name, fn]) => {
        const input = $(`#${name}`);
        if (!input) return;
        if (name.startsWith("card") && pay !== "card") { showErr(name, true); return; }
        const res = fn(input.value);
        showErr(name, res);
        if (res !== true) { ok = false; firstBad = firstBad || input; }
      });
      if (!cart.length) { toast("Your bag is empty."); ok = false; }
      if (firstBad) firstBad.focus();
      return ok;
    };

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      if (!validate()) return;
      const btn = $("#placeOrder");
      btn.disabled = true;
      btn.querySelector("span").textContent = "Placing order…";
      setTimeout(() => {
        const ref = "LM-" + Math.random().toString(36).slice(2, 8).toUpperCase();
        const placed = cart.slice();
        const total = cartTotal();
        try {
          const acct = JSON.parse(localStorage.getItem("lume.account") || "null");
          if (acct && acct.email) {
            acct.orders = acct.orders || [];
            acct.orders.push({
              ref,
              date: new Date().toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" }),
              status: "Processing",
              total,
              items: placed.map((i) => ({ id: i.id, name: i.name, img: i.img, size: i.size, swatch: i.swatch, qty: i.qty, price: i.price })),
            });
            localStorage.setItem("lume.account", JSON.stringify(acct));
          }
        } catch {}
        cart = [];
        saveCart();
        renderCart();
        renderSummary();
        form.outerHTML = `
          <div class="orderok" role="status">
            <div class="orderok__mark"><svg class="icon icon--lg"><use href="#i-check"/></svg></div>
            <h2>Thank you — your order is placed.</h2>
            <p>Order reference <b>${ref}</b>. A confirmation is on its way to your inbox,
            and you can follow the delivery any time from your account.</p>
            <p class="orderok__fine">This is a demonstration storefront, so no payment was taken
            and nothing will be shipped.</p>
            <div class="orderok__cta">
              <a class="btn btn--primary" href="index.html#bestsellers">Continue shopping</a>
              <a class="btn btn--ghost" href="track.html">Track an order</a>
            </div>
          </div>`;
      }, 900);
    });
  };

  /* =========================================================
     DRAWERS / OVERLAYS
     ========================================================= */
  const scrim = $("#scrim");
  let lastFocus = null;

  const setHidden = (el, hidden) => {
    if (!el) return;
    el.setAttribute("aria-hidden", hidden ? "true" : "false");
    if (hidden) el.setAttribute("inert", "");
    else el.removeAttribute("inert");
  };
  const rememberFocus = () => { lastFocus = document.activeElement; };
  const restoreFocus = () => {
    if (lastFocus && document.contains(lastFocus)) lastFocus.focus();
  };
  const lockScroll = (on) => document.body.classList.toggle("is-locked", on);

  const openCart = () => {
    rememberFocus();
    const el = $("#cart");
    el.classList.add("is-open");
    setHidden(el, false);
    if (scrim) scrim.classList.add("is-on");
    lockScroll(true);
    setTimeout(() => { const c = $("#closeCart"); if (c) c.focus(); }, 320);
  };
  const closeCart = () => {
    const el = $("#cart");
    if (!el || !el.classList.contains("is-open")) return;
    el.classList.remove("is-open");
    setHidden(el, true);
    if (scrim) scrim.classList.remove("is-on");
    lockScroll(false);
    restoreFocus();
  };
  const openNav = () => {
    rememberFocus();
    const el = $("#mobilenav");
    el.classList.add("is-open");
    setHidden(el, false);
    if (scrim) scrim.classList.add("is-on");
    lockScroll(true);
    const b = $("#burger"); if (b) b.setAttribute("aria-expanded", "true");
    setTimeout(() => { const c = $("#closeNav"); if (c) c.focus(); }, 320);
  };
  const closeNav = () => {
    const el = $("#mobilenav");
    if (!el || !el.classList.contains("is-open")) return;
    el.classList.remove("is-open");
    setHidden(el, true);
    if (scrim) scrim.classList.remove("is-on");
    lockScroll(false);
    const b = $("#burger"); if (b) b.setAttribute("aria-expanded", "false");
    restoreFocus();
  };
  const openSearch = () => {
    rememberFocus();
    const el = $("#searchbox");
    el.classList.add("is-open");
    setHidden(el, false);
    lockScroll(true);
    setTimeout(() => { const i = $("#searchInput"); if (i) i.focus(); }, 320);
  };
  const closeSearch = () => {
    const el = $("#searchbox");
    if (!el || !el.classList.contains("is-open")) return;
    el.classList.remove("is-open");
    setHidden(el, true);
    lockScroll(false);
    restoreFocus();
  };

  /* =========================================================
     SEARCH
     ========================================================= */
  const runSearch = (q) => {
    const term = q.trim().toLowerCase();
    const box = $("#searchResults");
    if (!box) return;
    if (!term) { box.innerHTML = ""; return; }
    const hits = PRODUCTS.filter((p) =>
      (p.name + " " + p.cat + " " + p.desc + " " + p.cats.join(" ")).toLowerCase().includes(term));
    if (!hits.length) {
      box.innerHTML = `<p class="searchbox__none">No pieces match “${esc(q)}”. Try “bed”, “collar” or “salmon”.</p>`;
      return;
    }
    box.innerHTML = hits.slice(0, 8).map((p) => `
      <a class="sres" href="product-${p.slug}.html">
        <div class="sres__img"><img src="${p.img}" alt="${esc(p.name)}" data-fallback></div>
        <div class="sres__name">${esc(p.name)}</div>
        <div class="sres__price">${money(p.price)}</div>
      </a>`).join("");
    wireFallback(box);
  };

  /* =========================================================
     TOAST
     ========================================================= */
  let toastTimer;
  const toast = (msg) => {
    const el = $("#toast");
    if (!el) return;
    $("#toastMsg").textContent = msg;
    el.classList.add("is-on");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("is-on"), 2600);
  };

  /* =========================================================
     WISHLIST
     ========================================================= */
  let wish = [];
  try { wish = JSON.parse(localStorage.getItem("lume.wish") || "[]"); } catch { wish = []; }
  const saveWish = () => { try { localStorage.setItem("lume.wish", JSON.stringify(wish)); } catch {} };
  const paintWish = () => {
    $$("[data-wish]").forEach((b) => {
      const on = wish.includes(b.dataset.wish);
      b.classList.toggle("is-on", on);
      b.setAttribute("aria-pressed", on ? "true" : "false");
    });
  };
  const toggleWish = (id) => {
    const i = wish.indexOf(id);
    const p = find(id);
    if (i === -1) { wish.push(id); toast(`${p ? p.name : "Item"} saved`); }
    else { wish.splice(i, 1); toast("Removed from saved"); }
    saveWish();
    paintWish();
  };

  /* =========================================================
     REVEAL ON SCROLL
     ========================================================= */
  const reveal = () => {
    const els = $$(".reveal, .reveal-img, [data-reveal], [data-stagger], .footer__col");
    if (!("IntersectionObserver" in window)) {
      els.forEach((e) => e.classList.add("is-in"));
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (!en.isIntersecting) return;
        const d = parseInt(en.target.dataset.delay || "0", 10);
        en.target.style.transitionDelay = d * 110 + "ms";
        en.target.classList.add("is-in");
        io.unobserve(en.target);
      });
    }, { threshold: 0.14, rootMargin: "0px 0px -8% 0px" });
    els.forEach((e) => io.observe(e));
  };

  /* =========================================================
     PARALLAX — a slow drift for hero and banner imagery
     ========================================================= */
  const parallax = () => {
    const els = $$(".parallax");
    if (!els.length || prefersReduced()) return;
    let ticking = false;
    const frame = () => {
      const vh = window.innerHeight;
      els.forEach((el) => {
        const r = el.getBoundingClientRect();
        if (r.bottom < -80 || r.top > vh + 80) return;
        const speed = parseFloat(el.dataset.speed || "0.12");
        const offset = (r.top + r.height / 2 - vh / 2) * -speed;
        el.style.transform = `translate3d(0,${offset.toFixed(2)}px,0)`;
      });
      ticking = false;
    };
    const onScroll = () => { if (!ticking) { ticking = true; requestAnimationFrame(frame); } };
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    frame();
  };

  /* =========================================================
     COUNTERS — numerals ease up to their target once in view
     ========================================================= */
  const counters = () => {
    const els = $$("[data-count]");
    if (!els.length) return;
    const run = (el) => {
      const target = parseFloat(el.dataset.count);
      const dec = (el.dataset.decimals | 0);
      if (prefersReduced()) { el.textContent = target.toFixed(dec); return; }
      const dur = 1400;
      const t0 = performance.now();
      const tick = (now) => {
        const p = Math.min((now - t0) / dur, 1);
        const eased = 1 - Math.pow(1 - p, 3);
        el.textContent = (target * eased).toFixed(dec);
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    };
    if (!("IntersectionObserver" in window)) { els.forEach(run); return; }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => { if (en.isIntersecting) { run(en.target); io.unobserve(en.target); } });
    }, { threshold: 0.4 });
    els.forEach((e) => io.observe(e));
  };

  /* =========================================================
     BACK TO TOP
     ========================================================= */
  const backToTop = () => {
    const btn = $("#toTop");
    if (!btn) return;
    const onScroll = () => btn.classList.toggle("is-on", window.scrollY > window.innerHeight * 1.2);
    btn.addEventListener("click", () =>
      window.scrollTo({ top: 0, behavior: prefersReduced() ? "auto" : "smooth" }));
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
  };

  const prefersReduced = () =>
    window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* =========================================================
     SAVED PIECES — the wishlist page
     Renders the same localStorage list the card hearts write to,
     so the heart button finally leads somewhere useful.
     ========================================================= */
  const renderWishlist = () => {
    const grid = $("#wishGrid");
    if (!grid) return;
    const items = wish.map(find).filter(Boolean);
    const empty = $("#wishEmpty");
    const toolbar = $("#wishToolbar");
    const count = $("#wishCount");

    if (count) count.textContent = `${items.length} saved`;
    if (empty) empty.hidden = items.length > 0;
    if (toolbar) toolbar.hidden = items.length === 0;
    grid.innerHTML = items.map(cardHTML).join("");
    wireFallback(grid);
    paintWish();
  };

  const initWishlist = () => {
    if (!$("#wishGrid")) return;
    renderWishlist();

    const addAll = $("#wishAddAll");
    if (addAll) addAll.addEventListener("click", () => {
      const items = wish.map(find).filter(Boolean);
      if (!items.length) return;
      items.forEach((p) => addToCart(p.id, { open: false }));
      openCart();
    });

    const clear = $("#wishClear");
    if (clear) clear.addEventListener("click", () => {
      if (!wish.length) return;
      wish = [];
      saveWish();
      renderWishlist();
      toast("Saved list cleared");
    });

    // Removing via the card heart should drop the card from this page at once.
    document.addEventListener("click", (e) => {
      const b = e.target.closest("[data-wish]");
      if (b && $("#wishGrid")) setTimeout(renderWishlist, 0);
    });
  };

  /* =========================================================
     SIZE FINDER — recommends a size from a real measurement
     ========================================================= */
  const initSizeFinder = () => {
    const form = $("#sizeForm");
    if (!form) return;
    const dataEl = $("#sizeCharts");
    const charts = dataEl ? JSON.parse(dataEl.textContent) : {};
    const typeEl = $("#sizeType");
    const cmEl = $("#sizeCm");
    const errEl = $("#sizeErr");
    const result = $("#sizeResult");
    const label = $("#sizeCmLabel");

    const labels = {
      bed: "Length nose to tail (cm)",
      collar: "Neck circumference (cm)",
      apparel: "Back length, neck to tail base (cm)",
    };
    const updateLabel = () => {
      if (label) label.textContent = labels[typeEl.value] || "Measurement in cm";
      clearResult();
    };
    const clearResult = () => {
      if (result) { result.hidden = true; result.innerHTML = ""; }
      if (errEl) errEl.textContent = "";
      $$(".sizecard").forEach((c) => c.classList.remove("is-highlight"));
    };
    const fail = (msg) => {
      if (errEl) errEl.textContent = msg;
      if (cmEl) cmEl.setAttribute("aria-invalid", "true");
      if (result) { result.hidden = true; result.innerHTML = ""; }
    };

    typeEl.addEventListener("change", updateLabel);

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      clearResult();
      const cm = parseFloat(cmEl.value);
      if (!cm || cm <= 0 || cm > 200) { fail("Enter a measurement between 1 and 200 cm."); return; }
      cmEl.removeAttribute("aria-invalid");

      const chart = charts[typeEl.value];
      if (!chart) return;
      const hit = chart.sizes.find((s) => cm >= s[1] && cm < s[2]) || chart.sizes[chart.sizes.length - 1];
      const [size, lo, hi, note] = hit;
      const span = hi >= 200 ? `${lo} cm and up` : `${lo}–${hi} cm`;
      const heading = { bed: "Recommended bed size", collar: "Recommended collar size", apparel: "Recommended coat size" }[typeEl.value];

      const card = $("#chart-" + typeEl.value);
      if (card) {
        $$(".sizecard").forEach((c) => c.classList.remove("is-highlight"));
        card.classList.add("is-highlight");
      }

      result.hidden = false;
      result.innerHTML = `
        <div class="sizeresult__card">
          <span class="sizeresult__eyebrow">${esc(heading)}</span>
          <p class="sizeresult__size">${esc(size)}</p>
          <p class="sizeresult__fits">For ${esc(span)} — you measured ${esc(String(cm))} cm.</p>
          <p class="sizeresult__note">${esc(note)}. If you are between two sizes, size up for a bed and
          size down for a coat, so nothing drags on the floor.</p>
          <div class="sizeresult__actions">
            <a class="btn btn--primary btn--sm" href="index.html#bestsellers"><span>Shop this size</span><svg class="icon icon--xs"><use href="#i-arrow-r"/></svg></a>
            <a class="link-underline" href="contact.html">Ask an advisor</a>
          </div>
        </div>`;
    });

    const reset = $("#sizeReset");
    if (reset) reset.addEventListener("click", () => {
      form.reset();
      updateLabel();
    });
    updateLabel();
  };

  /* =========================================================
     COMPARE — line up to four pieces side by side
     ========================================================= */
  const initCompare = () => {
    const table = $("#compareTable");
    if (!table) return;
    const wrap = $("#compareWrap");
    const empty = $("#compareEmpty");
    const search = $("#compareSearch");
    const suggest = $("#compareSuggest");
    let picked = [];
    try { picked = JSON.parse(localStorage.getItem("lume.compare") || "[]"); } catch { picked = []; }
    const savePicked = () => { try { localStorage.setItem("lume.compare", JSON.stringify(picked)); } catch {} };

    const add = (id) => {
      if (!find(id) || picked.includes(id)) return;
      if (picked.length >= 4) { toast("Compare holds four pieces at a time"); return; }
      picked.push(id); savePicked(); draw();
    };
    const remove = (id) => { picked = picked.filter((x) => x !== id); savePicked(); draw(); };

    const row = (label, valFn, fmtFn, bestFn) => {
      const raw = picked.map((id) => valFn(find(id)));
      const best = bestFn ? bestFn(raw) : null;
      const cells = picked.map((id, i) => {
        const isBest = best !== null && raw.length > 1 && raw[i] === best;
        return `<td class="${isBest ? "is-best" : ""}">${isBest ? "★ " : ""}${esc(String(fmtFn ? fmtFn(raw[i], find(id)) : raw[i]))}</td>`;
      });
      return `<tr><th scope="row">${esc(label)}</th>${cells.join("")}</tr>`;
    };

    const draw = () => {
      const items = picked.map(find).filter(Boolean);
      const has = items.length > 0;
      if (wrap) wrap.hidden = !has;
      if (empty) empty.hidden = has;
      if (!has) { table.innerHTML = ""; return; }

      const head = items.map((p) => `
        <th scope="col">
          <div class="compare__head">
            <img src="${p.img}" alt="${esc(p.name)}" width="150" height="188" data-fallback />
            <b>${esc(p.name)}</b>
            <span class="compare__price">${money(p.price)}${p.was ? ` <s>${money(p.was)}</s>` : ""}</span>
            <button class="compare__remove" type="button" data-compare-remove="${p.id}">Remove</button>
          </div>
        </th>`).join("");

      table.innerHTML = `
        <thead><tr><th scope="col"><span class="compare__empty-cell">${items.length} of 4</span></th>${head}</tr></thead>
        <tbody>
          ${row("Category", (p) => p.cat, null, null)}
          ${row("Price", (p) => p.price, (v) => money(v), (a) => Math.min(...a))}
          ${row("Rating", (p) => p.rating, (v, p) => `${v} (${p.reviews})`, (a) => Math.max(...a))}
          ${row("Material", (p) => (p.specs || {}).Material || "—", null, null)}
          ${row("Care", (p) => (p.specs || {}).Care || "—", null, null)}
          ${row("Origin", (p) => (p.specs || {}).Origin || "—", null, null)}
          ${row("Warranty", (p) => (p.specs || {}).Warranty || "—", null, null)}
          ${row("Sizes", (p) => (p.sizes || []).join(", ") || "—", null, null)}
          <tr><th scope="row">Add</th>${items.map((p) =>
            `<td><button class="btn btn--primary btn--sm" type="button" data-add="${p.id}"><svg class="icon icon--xs"><use href="#i-plus"/></svg><span>Add to bag</span></button></td>`).join("")}</tr>
        </tbody>`;
      wireFallback(table);
    };

    const closeSuggest = () => { if (suggest) { suggest.hidden = true; suggest.innerHTML = ""; } };
    if (search) {
      search.addEventListener("input", () => {
        const q = search.value.trim().toLowerCase();
        if (q.length < 2) { closeSuggest(); return; }
        const hits = PRODUCTS.filter((p) =>
          (p.name + " " + p.cat + " " + ((p.specs || {}).Material || "")).toLowerCase().includes(q)).slice(0, 6);
        if (!hits.length) { closeSuggest(); return; }
        suggest.innerHTML = hits.map((p) => {
          const on = picked.includes(p.id);
          return `<button class="compare__opt" type="button" data-compare-add="${p.id}"${on ? " disabled" : ""}>
             <img src="${p.img}" alt="" width="44" height="44" data-fallback />
             <b>${esc(p.name)}</b><span>${on ? "Added" : money(p.price)}</span></button>`;
        }).join("");
        suggest.hidden = false;
      });
    }
    document.addEventListener("click", (e) => {
      const a = e.target.closest("[data-compare-add]");
      if (a) { add(a.dataset.compareAdd); if (search) search.value = ""; closeSuggest(); return; }
      const r = e.target.closest("[data-compare-remove]");
      if (r) { remove(r.dataset.compareRemove); return; }
      if (suggest && !e.target.closest(".compare__picker")) closeSuggest();
    });
    draw();
  };

  /* =========================================================
     GIFT GUIDE — filter by recipient, budget and occasion
     ========================================================= */
  const initGiftGuide = () => {
    const grid = $("#giftGrid");
    if (!grid) return;
    const dataEl = $("#giftBands");
    const bands = dataEl ? JSON.parse(dataEl.textContent) : [];
    const empty = $("#giftEmpty");
    const count = $("#giftCount");
    const state = { pet: "all", band: "all", mood: "all" };

    const moodOf = (p) => {
      const cats = p.cats || [];
      if (p.badge === "New") return "new";
      if (cats.includes("sleep") || cats.includes("apparel")) return "cosy";
      if (cats.includes("play") || cats.includes("walks") || cats.includes("travel")) return "active";
      if (cats.includes("treats") || cats.includes("nutrition") || cats.includes("grooming")) return "treat";
      return "cosy";
    };
    const matches = (p) => {
      if (state.pet !== "all" && !(p.cats || []).includes(state.pet)) return false;
      if (state.band !== "all") {
        const b = bands[+state.band];
        if (b && !(p.price >= b.min && p.price < b.max)) return false;
      }
      if (state.mood !== "all" && moodOf(p) !== state.mood) return false;
      return true;
    };

    const draw = () => {
      const items = PRODUCTS.filter(matches);
      grid.innerHTML = items.map(cardHTML).join("");
      wireFallback(grid);
      if (count) count.textContent = `${items.length} gift${items.length === 1 ? "" : "s"}`;
      if (empty) empty.hidden = items.length > 0;
    };

    const groups = [
      ["data-gift-pet", "pet"],
      ["data-gift-band", "band"],
      ["data-gift-mood", "mood"],
    ];
    document.addEventListener("click", (e) => {
      for (const [attr, key] of groups) {
        const c = e.target.closest(`.chip[${attr}]`);
        if (!c) continue;
        const group = c.closest(".filters") || document;
        $$(`.chip[${attr}]`, group).forEach((x) => x.classList.remove("is-active"));
        c.classList.add("is-active");
        state[key] = c.getAttribute(attr);
        draw();
        return;
      }
    });
    draw();
  };

  /* =========================================================
     ACCOUNT — sign in / register + dashboard (demo session)
     ========================================================= */
  const ACCT_KEY = "lume.account";

  const initAccount = () => {
    const guest = $("#accountGuest");
    const dash = $("#accountDash");
    if (!guest && !dash) return;

    const read = () => {
      try { return JSON.parse(localStorage.getItem(ACCT_KEY) || "null"); } catch { return null; }
    };
    const save = (acct) => {
      try { localStorage.setItem(ACCT_KEY, JSON.stringify(acct)); } catch {}
    };
    const errOf = (id) => $(`[data-err="${id}"]`);
    const setErr = (id, msg) => {
      const el = errOf(id);
      if (el) el.textContent = msg || "";
      const input = document.getElementById(id);
      if (input) input.setAttribute("aria-invalid", msg ? "true" : "false");
    };

    /* ---- password visibility toggles ---- */
    $$(".pwfield__toggle").forEach((b) => b.addEventListener("click", () => {
      const input = document.getElementById(b.dataset.pw);
      if (!input) return;
      const show = input.type === "password";
      input.type = show ? "text" : "password";
      b.setAttribute("aria-label", show ? "Hide password" : "Show password");
      b.classList.toggle("is-on", show);
    }));

    /* ---- tabs ---- */
    const showPanel = (name) => {
      $$(".auth__tab").forEach((t) => {
        const on = t.dataset.tab === name;
        t.classList.toggle("is-active", on);
        t.setAttribute("aria-selected", on ? "true" : "false");
      });
      $$(".auth__panel").forEach((p) => {
        const on = p.dataset.panel === name;
        p.classList.toggle("is-active", on);
        p.hidden = !on;
      });
    };
    $$("[data-tab]").forEach((b) => b.addEventListener("click", () => showPanel(b.dataset.tab)));

    const forgot = $("#forgotLink");
    if (forgot) forgot.addEventListener("click", (e) => {
      e.preventDefault();
      const note = $("#resetNote");
      if (note) note.hidden = false;
    });

    /* ---- password strength ---- */
    const scoreOf = (v) => {
      let s = 0;
      if (v.length >= 8) s++;
      if (/[A-Z]/.test(v) && /[a-z]/.test(v)) s++;
      if (/\d/.test(v)) s++;
      if (/[^A-Za-z0-9]/.test(v)) s++;
      return s;
    };
    const rgPass = $("#rg-pass");
    if (rgPass) rgPass.addEventListener("input", () => {
      const s = scoreOf(rgPass.value);
      const meter = $("#pwMeter");
      if (meter) meter.dataset.score = rgPass.value ? String(Math.max(1, s)) : "0";
      const hint = $("#pwHint");
      if (hint) hint.textContent = ["Use 8+ characters, with a number for good measure.",
        "A little short — aim for 8+ characters.",
        "Getting there — add a number or symbol.",
        "Strong password.",
        "Excellent — hard to guess."][rgPass.value ? Math.max(1, s) : 0];
    });

    /* ---- sign in ---- */
    const signin = $("#signinForm");
    if (signin) signin.addEventListener("submit", (e) => {
      e.preventDefault();
      const email = $("#si-email").value.trim();
      const pass = $("#si-pass").value;
      let ok = true;
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setErr("si-email", "Enter a valid email address."); ok = false; }
      else setErr("si-email", "");
      if (pass.length < 6) { setErr("si-pass", "Passwords are at least 6 characters."); ok = false; }
      else setErr("si-pass", "");
      if (!ok) return;
      const stored = read();
      const name = stored && stored.email === email && stored.name ? stored.name : email.split("@")[0];
      enter({ name, email, prefs: (stored && stored.prefs) || {}, address: (stored && stored.address) || {}, orders: (stored && stored.orders) || [] });
      toast("Welcome back, " + name);
    });

    /* ---- register ---- */
    const register = $("#registerForm");
    if (register) register.addEventListener("submit", (e) => {
      e.preventDefault();
      const first = $("#rg-first").value.trim();
      const last = $("#rg-last").value.trim();
      const email = $("#rg-email").value.trim();
      const pass = $("#rg-pass").value;
      const terms = $("#rg-terms").checked;
      let ok = true;
      if (!first) { setErr("rg-first", "Required."); ok = false; } else setErr("rg-first", "");
      if (!last) { setErr("rg-last", "Required."); ok = false; } else setErr("rg-last", "");
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setErr("rg-email", "Enter a valid email address."); ok = false; }
      else setErr("rg-email", "");
      if (pass.length < 8) { setErr("rg-pass", "Use at least 8 characters."); ok = false; }
      else setErr("rg-pass", "");
      const termsErr = errOf("rg-terms");
      if (!terms) { if (termsErr) termsErr.textContent = "Please accept the terms to continue."; ok = false; }
      else if (termsErr) termsErr.textContent = "";
      if (!ok) return;
      const name = `${first} ${last}`.trim();
      enter({ name, email, prefs: { news: true }, address: {}, orders: [] });
      toast("Account created — welcome, " + first);
    });

    /* ---- session lifecycle ---- */
    const enter = (acct) => {
      save(acct);
      renderDash(acct);
    };

    const signOut = $("#signOut");
    if (signOut) signOut.addEventListener("click", () => {
      try { localStorage.removeItem(ACCT_KEY); } catch {}
      if (guest) guest.hidden = false;
      if (dash) dash.hidden = true;
      showPanel("signin");
      toast("Signed out");
      window.scrollTo({ top: 0, behavior: "smooth" });
    });

    /* ---- dashboard ---- */
    const renderDash = (acct) => {
      if (guest) guest.hidden = true;
      if (dash) dash.hidden = false;

      const first = (acct.name || "friend").split(" ")[0];
      $("#acctName").textContent = first;
      $("#acctEmail").textContent = acct.email || "";

      const wrap = $("#acctOrders");
      const orders = (acct.orders || []).slice().reverse();
      if (!orders.length) {
        wrap.innerHTML = `
          <div class="account__empty">
            <svg class="icon icon--lg"><use href="#i-cart"/></svg>
            <p>No orders yet — your first one will appear here.</p>
          </div>`;
      } else {
        wrap.innerHTML = orders.map((o) => {
          const thumbs = (o.items || []).slice(0, 4).map((it) =>
            `<span class="order__thumb"><img src="${it.img}" alt="" data-fallback></span>`).join("");
          const extra = (o.items || []).length > 4 ? `<span class="order__more">+${o.items.length - 4} more</span>` : "";
          return `
            <article class="order">
              <div class="order__top">
                <div>
                  <div class="order__ref">${esc(o.ref)}</div>
                  <div class="order__date">${esc(o.date || "")}</div>
                </div>
                <span class="order__status${o.status === "Delivered" ? " order__status--done" : ""}">${esc(o.status || "Processing")}</span>
              </div>
              <div class="order__items">${thumbs}${extra}</div>
              <div class="order__foot">
                <span class="order__total">Total <b>${money(o.total || 0)}</b></span>
                <button class="order__reorder" type="button" data-reorder="${esc(o.ref)}">Reorder</button>
              </div>
            </article>`;
        }).join("");
        wireFallback(wrap);
      }

      renderSaved();

      const addr = acct.address || {};
      $("#ad-name").value = addr.name || acct.name || "";
      $("#ad-line").value = addr.line || "";
      $("#ad-city").value = addr.city || "";
      $("#ad-zip").value = addr.zip || "";
      if (addr.country) $("#ad-country").value = addr.country;

      const prefs = acct.prefs || {};
      $("#prefNews").checked = !!prefs.news;
      $("#prefRestock").checked = !!prefs.restock;
      $("#prefOffers").checked = !!prefs.offers;
    };

    const renderSaved = () => {
      const line = $("#acctWishLine");
      const box = $("#acctWish");
      if (!box) return;
      const items = wish.map(find).filter(Boolean).slice(0, 8);
      if (line) line.textContent = wish.length ? `${wish.length} saved piece${wish.length === 1 ? "" : "s"}.` : "Nothing saved yet.";
      box.innerHTML = items.map((p) => `
        <a class="acctwish__item" href="product-${p.slug}.html">
          <span class="acctwish__img"><img src="${p.img}" alt="${esc(p.name)}" loading="lazy" data-fallback></span>
          <span class="acctwish__name">${esc(p.name)}</span>
        </a>`).join("");
      wireFallback(box);
    };

    /* ---- reorder ---- */
    document.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-reorder]");
      if (!btn) return;
      const acct = read();
      const order = (acct && acct.orders || []).find((o) => o.ref === btn.dataset.reorder);
      if (!order) return;
      (order.items || []).forEach((it) => addToCart(it.id, { size: it.size, swatch: it.swatch }));
      openCart();
    });

    /* ---- address + preferences ---- */
    const addrForm = $("#addrForm");
    if (addrForm) addrForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const acct = read() || {};
      acct.address = {
        name: $("#ad-name").value.trim(),
        line: $("#ad-line").value.trim(),
        city: $("#ad-city").value.trim(),
        zip: $("#ad-zip").value.trim(),
        country: $("#ad-country").value,
      };
      save(acct);
      const msg = $("#addrMsg");
      if (msg) msg.textContent = "Address saved.";
      toast("Address saved");
    });

    [["prefNews", "news"], ["prefRestock", "restock"], ["prefOffers", "offers"]].forEach(([id, key]) => {
      const box = $("#" + id);
      if (box) box.addEventListener("change", () => {
        const acct = read() || {};
        acct.prefs = Object.assign({}, acct.prefs, { [key]: box.checked });
        save(acct);
        const msg = $("#prefMsg");
        if (msg) msg.textContent = "Preferences updated.";
      });
    });

    /* ---- resume an existing session ---- */
    const existing = read();
    if (existing && existing.email) renderDash(existing);
    else showPanel("signin");
  };

  /* =========================================================
     INIT
     ========================================================= */
  const init = () => {
    const year = $("#year");
    if (year) year.textContent = new Date().getFullYear();

    renderProducts();
    renderCart();
    renderCartPage();
    renderSummary();
    wireFallback();
    reveal();
    parallax();
    counters();
    backToTop();
    paintWish();
    initPDP();
    initCheckout();
    initWishlist();
    initSizeFinder();
    initCompare();
    initGiftGuide();
    initAccount();
    initOffer();

    ["#cart", "#mobilenav", "#searchbox", "#quickview", "#offer"].forEach((s) => setHidden($(s), true));

    const header = $("#header");
    if (header) {
      const onScroll = () => {
        header.classList.toggle("is-stuck", window.scrollY > 12);
        const h = document.documentElement.scrollHeight - window.innerHeight;
        const prog = $("#scrollProgress");
        if (prog) prog.style.width = (h > 0 ? (window.scrollY / h) * 100 : 0) + "%";
        const bg = $(".banner__bg");
        if (bg) {
          const r = bg.parentElement.getBoundingClientRect();
          if (r.top < window.innerHeight && r.bottom > 0) {
            bg.style.transform = `translateY(${r.top * -0.06}px) scale(1.06)`;
          }
        }
      };
      window.addEventListener("scroll", onScroll, { passive: true });
      onScroll();
    }

    document.addEventListener("click", (e) => {
      const t = e.target;
      const qv = t.closest("[data-quickview]");
      if (qv) { openQuickView(qv.dataset.quickview); closeSearch(); return; }
      const inc = t.closest("[data-inc]"); if (inc) return setQty(inc.dataset.inc, 1);
      const dec = t.closest("[data-dec]"); if (dec) return setQty(dec.dataset.dec, -1);
      const rm = t.closest("[data-rm]"); if (rm) return removeItem(rm.dataset.rm);

      const add = t.closest("[data-add]");
      if (add && !add.dataset.addDetail) { addToCart(add.dataset.add); return; }

      const qa = t.closest("[data-quickadd]");
      if (qa) {
        const p = PRODUCTS.find((x) => x.name === qa.dataset.quickadd);
        if (p) addToCart(p.id);
        return;
      }

      const wishBtn = t.closest("[data-wish]");
      if (wishBtn) { toggleWish(wishBtn.dataset.wish); return; }

      const chip = t.closest(".chip[data-filter]");
      if (chip) {
        const group = chip.closest(".filters") || document;
        $$(".chip[data-filter]", group).forEach((c) => c.classList.remove("is-active"));
        chip.classList.add("is-active");
        if ($("#products")) applyFilter(chip.dataset.filter);
        else filterReviews(chip.dataset.filter);
      }
      const s = t.closest(".chip[data-search]");
      if (s) { $("#searchInput").value = s.dataset.search; runSearch(s.dataset.search); }
    });

    const on = (sel, fn) => { const el = $(sel); if (el) el.onclick = fn; };
    on("#openCart", openCart);
    on("#closeCart", closeCart);
    on("#emptyShop", closeCart);
    on("#continueShop", closeCart);
    on("#scrim", () => { closeCart(); closeNav(); closeOffer(); });
    on("#burger", openNav);
    on("#closeNav", closeNav);
    on("#openSearch", openSearch);
    on("#closeSearch", closeSearch);

    const sort = $("#sortSelect");
    if (sort) sort.addEventListener("change", () => applySort(sort.value));

    const modal = $("#quickview");
    if (modal) modal.addEventListener("click", (e) => { if (e.target.id === "quickview") closeQuickView(); });

    document.addEventListener("keydown", (e) => {
      if (e.key !== "Escape") return;
      closeCart(); closeNav(); closeSearch(); closeQuickView(); closeOffer();
    });

    const searchInput = $("#searchInput");
    if (searchInput) searchInput.addEventListener("input", (e) => runSearch(e.target.value));

    const form = $("#newsletterForm");
    if (form) form.addEventListener("submit", (e) => {
      e.preventDefault();
      const email = $("#newsletterEmail").value.trim();
      const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
      const note = $("#newsletterNote");
      if (!ok) { note.textContent = "Please enter a valid email address."; note.style.color = "#E0A9A9"; return; }
      note.textContent = "You're in — check your inbox for the 10% code.";
      note.style.color = "var(--brass)";
      e.target.reset();
    });

    $$(".mobilenav__links a").forEach((a) => a.addEventListener("click", closeNav));
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
