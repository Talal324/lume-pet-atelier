# Image credits

Every photograph below is from Wikimedia Commons and is reused under the licence shown. Attribution is required for CC BY / CC BY-SA; keep this file with the site, or replace these images with your own photography.

## Product photographs

| File | Shows | Source | Author | Licence |
| --- | --- | --- | --- | --- |
| `bone-broth.jpg` | Slow Bone Broth | [Broth.jpg](https://commons.wikimedia.org/wiki/File:Broth.jpg) | Mariuszjbie | CC BY-SA 3.0 |
| `cat-bowl.jpg` | Wide Ceramic Cat Bowl | [A cat pauses over a bowl of food, 2011.jpg](https://commons.wikimedia.org/wiki/File:A_cat_pauses_over_a_bowl_of_food,_2011.jpg) | Linda Hosek | Public domain |
| `cat-cats.jpg` | Cats category card | [Sitting Cat 01.jpg](https://commons.wikimedia.org/wiki/File:Sitting_Cat_01.jpg) | Indrajit Das | CC BY-SA 4.0 |
| `cat-gift.jpg` | Gift card | [Open Pink Gifft Box with White Ribbon.JPG](https://commons.wikimedia.org/wiki/File:Open_Pink_Gifft_Box_with_White_Ribbon.JPG) | Jpquidores | CC BY-SA 3.0 |
| `cat-litter.jpg` | Covered Litter Tray | [My gorgeous Rosie has taken to having a lie down in the litter tray... (45759103172).jpg](https://commons.wikimedia.org/wiki/File:My_gorgeous_Rosie_has_taken_to_having_a_lie_down_in_the_litter_tray..._(45759103172).jpg) | alljengi from Leith, Edinburgh | CC BY-SA 2.0 |
| `cat-mouse.jpg` | Catnip Mouse Trio | [2020-04-14 — Cat playing with ball chaser toy.jpg](https://commons.wikimedia.org/wiki/File:2020-04-14_%E2%80%94_Cat_playing_with_ball_chaser_toy.jpg) | Jerry | CC BY-SA 2.0 |
| `cat-perch.jpg` | Window Perch | [Momma Cat looking out the bay window 2 (48757207613).jpg](https://commons.wikimedia.org/wiki/File:Momma_Cat_looking_out_the_bay_window_2_(48757207613).jpg) | James St. John | CC BY 2.0 |
| `cat-scratch.jpg` | Sisal Scratching Post | [Homemade scratching post.jpg](https://commons.wikimedia.org/wiki/File:Homemade_scratching_post.jpg) | Jess | CC BY-SA 2.0 |
| `cat-tree.jpg` | Climbing Tree Tower | [Momma Cat in the cat tree 2 (48763023117).jpg](https://commons.wikimedia.org/wiki/File:Momma_Cat_in_the_cat_tree_2_(48763023117).jpg) | James St. John | CC BY 2.0 |
| `dog-ball.jpg` | Sunday Fetch Ball | [Dog playing tennis ball.jpg](https://commons.wikimedia.org/wiki/File:Dog_playing_tennis_ball.jpg) | Ossewa | CC BY-SA 4.0 |
| `dog-brush.jpg` | Soft Grooming Brush | [TIKITA-TOILETTAGE-2.jpg](https://commons.wikimedia.org/wiki/File:TIKITA-TOILETTAGE-2.jpg) | Tikita-Lille | CC BY-SA 3.0 |
| `dog-coat.jpg` | Winter Quilted Coat | [Westiepoo wearing coat.jpg](https://commons.wikimedia.org/wiki/File:Westiepoo_wearing_coat.jpg) | Bassschlüssel | CC BY-SA 4.0 |
| `dog-crate.jpg` | Soft Travel Carrier | [Close-up of Plaid Pet Carrier Bag with Flower Charm.jpg](https://commons.wikimedia.org/wiki/File:Close-up_of_Plaid_Pet_Carrier_Bag_with_Flower_Charm.jpg) | ELTORO.VET | CC0 |
| `dog-harness.jpg` | Trail Harness | [A beagle wearing a harness standing in a park.jpg](https://commons.wikimedia.org/wiki/File:A_beagle_wearing_a_harness_standing_in_a_park.jpg) | Slyronit | CC BY-SA 4.0 |
| `dog-shampoo.jpg` | Calm Oatmeal Shampoo | [Washing a dog in a bath tub.jpg](https://commons.wikimedia.org/wiki/File:Washing_a_dog_in_a_bath_tub.jpg) | Andrew Vargas | CC BY 2.0 |
| `food-dental.jpg` | Daily Dental Chews | [Dreyfuss chews his rawhide bone.jpg](https://commons.wikimedia.org/wiki/File:Dreyfuss_chews_his_rawhide_bone.jpg) | Shane Adams | CC BY 2.0 |
| `food-kitten.jpg` | Kitten Formula | [Kitten Pair Eating 01.jpg](https://commons.wikimedia.org/wiki/File:Kitten_Pair_Eating_01.jpg) | Achat1999 | CC BY-SA 4.0 |
| `food-oil.jpg` | Wild Salmon Oil | [Super-fish-oil.jpg](https://commons.wikimedia.org/wiki/File:Super-fish-oil.jpg) | 些細な日常 | CC BY-SA 4.0 |
| `food-puppy.jpg` | Puppy Growth Formula | [A Beagle sitting next to dog food.jpg](https://commons.wikimedia.org/wiki/File:A_Beagle_sitting_next_to_dog_food.jpg) | Slyronit | CC BY-SA 4.0 |
| `food-raw.jpg` | Freeze-Dried Raw Medallions | [Raw beef.jpg](https://commons.wikimedia.org/wiki/File:Raw_beef.jpg) | Halima Waziri | CC BY-SA 4.0 |
| `food-wet.jpg` | Slow-Cooked Wet Food | [Dog food in a bowl.jpg](https://commons.wikimedia.org/wiki/File:Dog_food_in_a_bowl.jpg) | James Redekop | CC BY-SA 2.0 |
| `look-3.jpg` | Feeding ritual | [Dog eating carrot.jpg](https://commons.wikimedia.org/wiki/File:Dog_eating_carrot.jpg) | Sneha G Gupta | CC BY-SA 4.0 |
| `look-5.jpg` | Walkies | [Long Haired Australian Cattle Dog.jpg](https://commons.wikimedia.org/wiki/File:Long_Haired_Australian_Cattle_Dog.jpg) | MarkBuckawicki | CC0 |
| `p1.jpg` | Cloud Nine Orthopedic Bed | [Dog sleeping in a dog bed.JPG](https://commons.wikimedia.org/wiki/File:Dog_sleeping_in_a_dog_bed.JPG) | Tomwsulcer | CC0 |
| `p2.jpg` | Atelier Leather Collar | [Leather dog collar made by Les cuirs d'Agathe (DSC06406).jpg](https://commons.wikimedia.org/wiki/File:Leather_dog_collar_made_by_Les_cuirs_d%27Agathe_(DSC06406).jpg) | Trougnouf (Benoit Brummer) (photo), Les cuirs d'Agathe (collar) | CC BY 4.0 |
| `p3.jpg` | Ceramic Slow-Feed Bowl | [A Bowl Of Doggie Bone (18272371).jpeg](https://commons.wikimedia.org/wiki/File:A_Bowl_Of_Doggie_Bone_(18272371).jpeg) | Dono Pek Reynolds Ha | CC BY 3.0 |
| `p4.jpg` | Rope & Cotton Chew Set | [DOG with CHEW TOYS 30APR00.jpg](https://commons.wikimedia.org/wiki/File:DOG_with_CHEW_TOYS_30APR00.jpg) | Nancy Wong | CC BY-SA 4.0 |
| `p5.jpg` | Velvet Calm Cat Bed | [Cat-sleeping-curled-up.jpg](https://commons.wikimedia.org/wiki/File:Cat-sleeping-curled-up.jpg) | Sonkiki | CC0 |
| `p6.jpg` | Everyday Walking Lead | [Beagle wearing harness and leash.jpg](https://commons.wikimedia.org/wiki/File:Beagle_wearing_harness_and_leash.jpg) | Slyronit | CC BY-SA 4.0 |
| `p7.jpg` | Field & Farm Dry Recipe | [Dog Food (1).jpg](https://commons.wikimedia.org/wiki/File:Dog_Food_(1).jpg) | Alisha Vargas | CC BY 2.0 |
| `p8.jpg` | Feather Chase Cat Wand | [Ellie playing with her mouse. (19195686924).jpg](https://commons.wikimedia.org/wiki/File:Ellie_playing_with_her_mouse._(19195686924).jpg) | GPS 56 from New Zealand | CC BY 2.0 |
| `ritual-1.jpg` | Grooming ritual | [Yorkshire-Terrier-Fresh-Haircut.jpg](https://commons.wikimedia.org/wiki/File:Yorkshire-Terrier-Fresh-Haircut.jpg) | Zakattakk | CC BY-SA 4.0 |
| `ritual-2.jpg` | Feeding ritual | [Green Spiral Slow Feeder Dog Bowl.jpg](https://commons.wikimedia.org/wiki/File:Green_Spiral_Slow_Feeder_Dog_Bowl.jpg) | ELTORO.VET | CC0 |
| `ritual-3.jpg` | Play ritual | [Boston terrier with toy.jpg](https://commons.wikimedia.org/wiki/File:Boston_terrier_with_toy.jpg) | Sendai Blog | CC BY 2.0 |
| `small-cage.jpg` | Indoor Guinea Pig Hutch | [Guinea pig in hutch.jpg](https://commons.wikimedia.org/wiki/File:Guinea_pig_in_hutch.jpg) | Rex tremendae majestatis | CC BY-SA 4.0 |
| `small-chew.jpg` | Natural Wood Chew Blocks | [Guinea pigs eating lettuce.jpg](https://commons.wikimedia.org/wiki/File:Guinea_pigs_eating_lettuce.jpg) | Mittens666 | CC BY-SA 4.0 |
| `small-hay.jpg` | Organic Timothy Hay | [Guinea pig eating grass leaves.jpeg](https://commons.wikimedia.org/wiki/File:Guinea_pig_eating_grass_leaves.jpeg) | Jaspergeli | CC BY-SA 4.0 |
| `small-hut.jpg` | Wooden Hideaway Hut | [Home built enclosure for a Syrian Hamster.png](https://commons.wikimedia.org/wiki/File:Home_built_enclosure_for_a_Syrian_Hamster.png) | Jennifer Carlsson | CC BY-SA 4.0 |
| `small-water.jpg` | No-Drip Water Bottle | [Hamster water bottle (14727539599).jpg](https://commons.wikimedia.org/wiki/File:Hamster_water_bottle_(14727539599).jpg) | Tiia Heinonen from Suomi | CC BY 2.0 |
| `small-wheel.jpg` | Quiet Exercise Wheel | [Hamster standing in exercise wheel.jpg](https://commons.wikimedia.org/wiki/File:Hamster_standing_in_exercise_wheel.jpg) | Rlicul | CC BY-SA 3.0 |
| `training-treats.jpg` | Training Treats | [Bone Dog Treats (51049786016).jpg](https://commons.wikimedia.org/wiki/File:Bone_Dog_Treats_(51049786016).jpg) | Megan Marrs | CC BY 2.0 |

## Homepage images

| File | Source | Author | Licence |
| --- | --- | --- | --- |
| `banner.jpg` | [English Setter running through grass.jpg](https://commons.wikimedia.org/wiki/File:English_Setter_running_through_grass.jpg) | Rjgunn007 | CC BY-SA 3.0 |
| `cat-dogs.jpg` | [BORDER COLLIE, Simaro Million Dollar Baby (24290879465) 2.jpg](https://commons.wikimedia.org/wiki/File:BORDER_COLLIE,_Simaro_Million_Dollar_Baby_(24290879465)_2.jpg) | Svenska Mässan from Sweden | CC BY 4.0 |
| `cat-small.jpg` | [Caviidae Cavia porcellus 1.jpg](https://commons.wikimedia.org/wiki/File:Caviidae_Cavia_porcellus_1.jpg) | NasserHalaweh | CC BY-SA 4.0 |
| `hero-2.jpg` | [Cat November 2010-1a.jpg](https://commons.wikimedia.org/wiki/File:Cat_November_2010-1a.jpg) | Alvesgaspar | CC BY-SA 3.0 |
| `hero.jpg` | [Golden Retriever Hund Dog.JPG](https://commons.wikimedia.org/wiki/File:Golden_Retriever_Hund_Dog.JPG) | Kintaiyo | CC BY 3.0 |
| `look-1.jpg` | [Great Pyriness dog and labrador retriever (5).jpg](https://commons.wikimedia.org/wiki/File:Great_Pyriness_dog_and_labrador_retriever_(5).jpg) | Usernet123u | CC BY-SA 4.0 |
| `look-2.jpg` | [Tibetan terrier dog running outdoors with tongue sticking out.jpg](https://commons.wikimedia.org/wiki/File:Tibetan_terrier_dog_running_outdoors_with_tongue_sticking_out.jpg) | Slavica Stajic | CC BY-SA 4.0 |
| `look-4.jpg` | [Sleeping cat on her back.jpg](https://commons.wikimedia.org/wiki/File:Sleeping_cat_on_her_back.jpg) | Umberto Salvagnin | CC BY 2.0 |
| `story.jpg` | [Cats of KD's Home 20.jpg](https://commons.wikimedia.org/wiki/File:Cats_of_KD%27s_Home_20.jpg) | Kaushalkumar Hareshbhai Desai | CC BY-SA 4.0 |

## Lifestyle photographs

| File | Pool | Source | Author | Licence |
| --- | --- | --- | --- | --- |
| `life-cat-01.jpg` | cat | [20231125 housecat south meadows PD100306.jpg](https://commons.wikimedia.org/wiki/File:20231125_housecat_south_meadows_PD100306.jpg) | Paul Danese | CC BY-SA 4.0 |
| `life-cat-02.jpg` | cat | [Blue and white tabby cat–IMG 6442 02.jpg](https://commons.wikimedia.org/wiki/File:Blue_and_white_tabby_cat%E2%80%93IMG_6442_02.jpg) | Kızıl | CC BY-SA 4.0 |
| `life-cat-03.jpg` | cat | [Calico cat, - Assisi, Italy.jpg](https://commons.wikimedia.org/wiki/File:Calico_cat,_-_Assisi,_Italy.jpg) | Terragio67 | CC BY-SA 4.0 |
| `life-cat-04.jpg` | cat | [Cat Iran.jpg](https://commons.wikimedia.org/wiki/File:Cat_Iran.jpg) | درفش کاویانی | CC BY-SA 3.0 |
| `life-cat-05.jpg` | cat | [Cat November 2010-1a.jpg](https://commons.wikimedia.org/wiki/File:Cat_November_2010-1a.jpg) | Alvesgaspar | CC BY-SA 3.0 |
| `life-cat-06.jpg` | cat | [Cautious Tabby Red Cat.jpg](https://commons.wikimedia.org/wiki/File:Cautious_Tabby_Red_Cat.jpg) | Etaped | CC BY-SA 4.0 |
| `life-cat-07.jpg` | cat | [Domestic cat felis catus.jpg](https://commons.wikimedia.org/wiki/File:Domestic_cat_felis_catus.jpg) | Muhammad Mahdi Karim | GFDL |
| `life-cat-08.jpg` | cat | [Felis catus-cat on snow.jpg](https://commons.wikimedia.org/wiki/File:Felis_catus-cat_on_snow.jpg) | Von.grzanka | CC BY-SA 3.0 |
| `life-cat-09.jpg` | cat | [June odd-eyed-cat cropped.jpg](https://commons.wikimedia.org/wiki/File:June_odd-eyed-cat_cropped.jpg) | Keith Kissel | CC BY 2.0 |
| `life-cat-10.jpg` | cat | [Siam lilacpoint.jpg](https://commons.wikimedia.org/wiki/File:Siam_lilacpoint.jpg) | Karin Langner-Bahmann, upload von Martin Bahmann | CC BY-SA 3.0 |
| `life-cat-11.jpg` | cat | [Siamese cat HD.jpg](https://commons.wikimedia.org/wiki/File:Siamese_cat_HD.jpg) | Aquinassixthway | CC0 |
| `life-cat-12.jpg` | cat | [Siamese cat, modern-style.jpg](https://commons.wikimedia.org/wiki/File:Siamese_cat,_modern-style.jpg) | Felinlove | CC BY-SA 4.0 |
| `life-cat-13.jpg` | cat | [Siamese cat with oriental shorthair kitten.jpg](https://commons.wikimedia.org/wiki/File:Siamese_cat_with_oriental_shorthair_kitten.jpg) | Felinlove | CC BY-SA 4.0 |
| `life-cat-14.jpg` | cat | [Siamese cats.jpg](https://commons.wikimedia.org/wiki/File:Siamese_cats.jpg) | Francisco Baraglia | CC BY-SA 4.0 |
| `life-dog-01.jpg` | dog | [A Beagle sitting next to dog food.jpg](https://commons.wikimedia.org/wiki/File:A_Beagle_sitting_next_to_dog_food.jpg) | Slyronit | CC BY-SA 4.0 |
| `life-dog-02.jpg` | dog | [A Golden Retriever-9 (Barras).JPG](https://commons.wikimedia.org/wiki/File:A_Golden_Retriever-9_(Barras).JPG) | Barras | CC BY 3.0 |
| `life-dog-03.jpg` | dog | [A Golden Retriever sniffing a Beagle at the Dog Park.jpg](https://commons.wikimedia.org/wiki/File:A_Golden_Retriever_sniffing_a_Beagle_at_the_Dog_Park.jpg) | Slyronit | CC BY-SA 4.0 |
| `life-dog-04.jpg` | dog | [A Labrador Retriever in Aurora, Colorado.jpg](https://commons.wikimedia.org/wiki/File:A_Labrador_Retriever_in_Aurora,_Colorado.jpg) | Muldoonsamuel | CC0 |
| `life-dog-05.jpg` | dog | [A beagle standing in a dog park.jpg](https://commons.wikimedia.org/wiki/File:A_beagle_standing_in_a_dog_park.jpg) | Slyronit | CC BY-SA 4.0 |
| `life-dog-06.jpg` | dog | [Beagle Dog female.jpg](https://commons.wikimedia.org/wiki/File:Beagle_Dog_female.jpg) | Floodmfx | CC BY-SA 4.0 |
| `life-dog-07.jpg` | dog | [Beagle at Halloween themed dog park.jpg](https://commons.wikimedia.org/wiki/File:Beagle_at_Halloween_themed_dog_park.jpg) | Slyronit | CC BY-SA 4.0 |
| `life-dog-08.jpg` | dog | [Beagle at the dog park.jpg](https://commons.wikimedia.org/wiki/File:Beagle_at_the_dog_park.jpg) | Slyronit | CC BY-SA 4.0 |
| `life-dog-09.jpg` | dog | [Benasque - Anciles - Labrador Retriever.jpg](https://commons.wikimedia.org/wiki/File:Benasque_-_Anciles_-_Labrador_Retriever.jpg) | Basotxerri | CC BY-SA 4.0 |
| `life-dog-10.jpg` | dog | [Callie the golden retriever puppy.jpg](https://commons.wikimedia.org/wiki/File:Callie_the_golden_retriever_puppy.jpg) | MichaelMcPhee | CC BY 3.0 |
| `life-dog-11.jpg` | dog | [Dülmen, Hausdülmen, Golden Retriever -- 2022 -- 5530.jpg](https://commons.wikimedia.org/wiki/File:D%C3%BClmen,_Hausd%C3%BClmen,_Golden_Retriever_--_2022_--_5530.jpg) | Dietmar Rabich | CC BY-SA 4.0 |
| `life-dog-12.jpg` | dog | [Golden Retriever in a puddle (Barras).jpg](https://commons.wikimedia.org/wiki/File:Golden_Retriever_in_a_puddle_(Barras).jpg) | Barras | CC BY-SA 3.0 |
| `life-dog-13.jpg` | dog | [Golden Retriever with a stick (Barras).jpg](https://commons.wikimedia.org/wiki/File:Golden_Retriever_with_a_stick_(Barras).jpg) | Barras | CC BY-SA 3.0 |
| `life-dog-14.jpg` | dog | [Golden Retrievers Dog Show Ooty May25 A7CR 05589.jpg](https://commons.wikimedia.org/wiki/File:Golden_Retrievers_Dog_Show_Ooty_May25_A7CR_05589.jpg) | Timothy A. Gonsalves | CC BY-SA 4.0 |
| `life-dog-15.jpg` | dog | [Golden retriever gnawing at the farmer's market.jpg](https://commons.wikimedia.org/wiki/File:Golden_retriever_gnawing_at_the_farmer%27s_market.jpg) | Grendelkhan | CC BY-SA 3.0 |
| `life-dog-16.jpg` | dog | [Harmony - Labrador Retriever.jpg](https://commons.wikimedia.org/wiki/File:Harmony_-_Labrador_Retriever.jpg) | NowIsntItTime | CC BY-SA 4.0 |
| `life-dog-17.jpg` | dog | [Labrador Retriever (1210559).jpg](https://commons.wikimedia.org/wiki/File:Labrador_Retriever_(1210559).jpg) | https://pixabay.com/es/users/chiemsee2016-1892688/ | CC0 |
| `life-dog-18.jpg` | dog | [Labrador Retriever Chocolate puppy 01.jpg](https://commons.wikimedia.org/wiki/File:Labrador_Retriever_Chocolate_puppy_01.jpg) | Jacek Proszyk | CC0 |
| `life-dog-19.jpg` | dog | [Labrador Retriever - Yellow.JPG](https://commons.wikimedia.org/wiki/File:Labrador_Retriever_-_Yellow.JPG) | Skansken | CC BY 3.0 |
| `life-dog-20.jpg` | dog | [Labrador Retriever snow.jpg](https://commons.wikimedia.org/wiki/File:Labrador_Retriever_snow.jpg) | Original author Hand, edit by Pharaoh Hound | CC BY 2.5 |
| `life-food-01.jpg` | food | [A Dog biscuit.jpg](https://commons.wikimedia.org/wiki/File:A_Dog_biscuit.jpg) | germanny | CC BY-SA 2.0 |
| `life-food-02.jpg` | food | [A cat pauses over a bowl of food, 2011.jpg](https://commons.wikimedia.org/wiki/File:A_cat_pauses_over_a_bowl_of_food,_2011.jpg) | Linda Hosek | Public domain |
| `life-food-03.jpg` | food | [Beagle eating a dog cake.jpg](https://commons.wikimedia.org/wiki/File:Beagle_eating_a_dog_cake.jpg) | Slyronit | CC BY-SA 4.0 |
| `life-food-04.jpg` | food | [Blue Slow Feeder Dog Bowl with Raised Studs and Ridges.jpg](https://commons.wikimedia.org/wiki/File:Blue_Slow_Feeder_Dog_Bowl_with_Raised_Studs_and_Ridges.jpg) | ELTORO.VET | CC0 |
| `life-food-05.jpg` | food | [Bone Dog Treats (51049786016).jpg](https://commons.wikimedia.org/wiki/File:Bone_Dog_Treats_(51049786016).jpg) | Megan Marrs | CC BY 2.0 |
| `life-food-06.jpg` | food | [Bright Green Spiral Slow Feeder Dog Bowl (Top View).jpg](https://commons.wikimedia.org/wiki/File:Bright_Green_Spiral_Slow_Feeder_Dog_Bowl_(Top_View).jpg) | ELTORO.VET | CC0 |
| `life-food-07.jpg` | food | [Cat eating bulgur.jpg](https://commons.wikimedia.org/wiki/File:Cat_eating_bulgur.jpg) | VSerebrenikov | CC BY-SA 4.0 |
| `life-food-08.jpg` | food | [Cat eating from a bowl.jpg](https://commons.wikimedia.org/wiki/File:Cat_eating_from_a_bowl.jpg) | see source | CC BY 1.0 |
| `life-food-09.jpg` | food | [Charcoal dog biscuit.JPG](https://commons.wikimedia.org/wiki/File:Charcoal_dog_biscuit.JPG) | Linda Spashett Storye book | CC BY 3.0 |
| `life-food-10.jpg` | food | [Common Indian cat eating 03.jpg](https://commons.wikimedia.org/wiki/File:Common_Indian_cat_eating_03.jpg) | Pinakpani | CC BY-SA 4.0 |
| `life-food-11.jpg` | food | [Common Indian cat eating 05.jpg](https://commons.wikimedia.org/wiki/File:Common_Indian_cat_eating_05.jpg) | Pinakpani | CC BY-SA 4.0 |
| `life-food-12.jpg` | food | [Dog Food (208810939).jpg](https://commons.wikimedia.org/wiki/File:Dog_Food_(208810939).jpg) | chrismetcalfTV | CC BY 2.0 |
| `life-food-13.jpg` | food | [Dog Food 2 (6409002109).jpg](https://commons.wikimedia.org/wiki/File:Dog_Food_2_(6409002109).jpg) | Sh4rp_i | CC BY 2.0 |
| `life-food-14.jpg` | food | [Dog Treats (51049057473).jpg](https://commons.wikimedia.org/wiki/File:Dog_Treats_(51049057473).jpg) | Megan Marrs | CC BY 2.0 |
| `life-food-15.jpg` | food | [Dog-biscuit.jpg](https://commons.wikimedia.org/wiki/File:Dog-biscuit.jpg) | FiveRings | CC BY 3.0 |
| `life-food-16.jpg` | food | [Dog biscuits (14345200038).jpg](https://commons.wikimedia.org/wiki/File:Dog_biscuits_(14345200038).jpg) | Jacqui Brown | CC BY-SA 2.0 |
| `life-food-17.jpg` | food | [Dog eating bell pepper.jpg](https://commons.wikimedia.org/wiki/File:Dog_eating_bell_pepper.jpg) | Realmilk | CC BY-SA 4.0 |
| `life-food-18.jpg` | food | [Dog eating carrot.jpg](https://commons.wikimedia.org/wiki/File:Dog_eating_carrot.jpg) | Sneha G Gupta | CC BY-SA 4.0 |
| `life-food-19.jpg` | food | [Dog eating melon.jpg](https://commons.wikimedia.org/wiki/File:Dog_eating_melon.jpg) | Realmilk | CC BY-SA 4.0 |
| `life-food-20.jpg` | food | [Dog with treat.jpg](https://commons.wikimedia.org/wiki/File:Dog_with_treat.jpg) | https://www.flickr.com/photos/pbump/with/5637773582/ | CC BY-SA 2.0 |
| `life-food-21.jpg` | food | [Green Spiral Slow Feeder Dog Bowl.jpg](https://commons.wikimedia.org/wiki/File:Green_Spiral_Slow_Feeder_Dog_Bowl.jpg) | ELTORO.VET | CC0 |
| `life-food-22.jpg` | food | [Kibbles How Others See Me.jpg](https://commons.wikimedia.org/wiki/File:Kibbles_How_Others_See_Me.jpg) | carterse | CC BY-SA 2.0 |
| `life-small-01.jpg` | small | [Baby Hamster - 2 Weeks Old.jpg](https://commons.wikimedia.org/wiki/File:Baby_Hamster_-_2_Weeks_Old.jpg) | Augustus Binu : flickr : Instagram | CC BY-SA 3.0 |
| `life-small-02.jpg` | small | [Cavia porcellus - domestic guinea pig. 2025-09.jpg](https://commons.wikimedia.org/wiki/File:Cavia_porcellus_-_domestic_guinea_pig._2025-09.jpg) | Дарія Гавриленко | CC BY-SA 4.0 |
| `life-small-03.jpg` | small | [Caviidae Cavia porcellus 1.jpg](https://commons.wikimedia.org/wiki/File:Caviidae_Cavia_porcellus_1.jpg) | NasserHalaweh | CC BY-SA 4.0 |
| `life-small-04.jpg` | small | [Cochon d'Inde (Cavia porcellus) (1).jpg](https://commons.wikimedia.org/wiki/File:Cochon_d%27Inde_(Cavia_porcellus)_(1).jpg) | Gzen92 | CC BY-SA 4.0 |
| `life-small-05.jpg` | small | [Cochon d'Inde (Cavia porcellus) (3).jpg](https://commons.wikimedia.org/wiki/File:Cochon_d%27Inde_(Cavia_porcellus)_(3).jpg) | Gzen92 | CC BY-SA 4.0 |
| `life-small-06.jpg` | small | [Coconut the rabbit 07.jpg](https://commons.wikimedia.org/wiki/File:Coconut_the_rabbit_07.jpg) | KittensMittens2 | CC BY-SA 4.0 |
| `life-small-07.jpg` | small | [Guinea pig (Cavia porcellus).jpg](https://commons.wikimedia.org/wiki/File:Guinea_pig_(Cavia_porcellus).jpg) | Dandy1022 | CC BY-SA 3.0 |
| `life-small-08.jpg` | small | [Hamster in the yard.jpg](https://commons.wikimedia.org/wiki/File:Hamster_in_the_yard.jpg) | Lo | CC0 |
| `life-small-09.jpg` | small | [Juvenile Female Mesocricetus auratus in Pet Store enclosure, Illinois, USA.jpg](https://commons.wikimedia.org/wiki/File:Juvenile_Female_Mesocricetus_auratus_in_Pet_Store_enclosure,_Illinois,_USA.jpg) | Wschlitz | CC BY 4.0 |
| `life-small-10.jpg` | small | [Mesocricetus auratus -pet hamster-8a.jpg](https://commons.wikimedia.org/wiki/File:Mesocricetus_auratus_-pet_hamster-8a.jpg) | Dennis Blöte | CC BY-SA 2.0 |
| `life-small-11.jpg` | small | [Mustela putorius furo 0zz.jpg](https://commons.wikimedia.org/wiki/File:Mustela_putorius_furo_0zz.jpg) | Photo by David J. Stang | CC BY-SA 4.0 |
| `life-small-12.jpg` | small | [Mustela putorius furo - 18-10-2008.JPG](https://commons.wikimedia.org/wiki/File:Mustela_putorius_furo_-_18-10-2008.JPG) | This file was created and uploaded by User:Szater Ten plik został stworzony i dodany przez Wikipedystę:Szater




Szater


 Wikimedia Commons  Polska Wikipedia | CC BY-SA 3.0 |
